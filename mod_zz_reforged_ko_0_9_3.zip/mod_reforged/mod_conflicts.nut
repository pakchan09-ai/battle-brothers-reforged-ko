::Reforged.HooksMod.conflictWith([
	"mod_legends",
	// Better Fencing by LordMidas. https://www.nexusmods.com/battlebrothers/mods/369
	"mod_betterFencing [리포지드에 포함되거나 개선된 기능]",
	// Items and Recipes by Vazl. https://www.nexusmods.com/battlebrothers/mods/501
	"mod_items_recipes [A similar feature is included in Reforged]",
	// Tactical hit factors by MrBrut. https://www.nexusmods.com/battlebrothers/mods/283
	"mod_tactical_hit_factors [A similar feature is included in Reforged]",
	// Tactical tooltip by MrBrut. https://www.nexusmods.com/battlebrothers/mods/266
	"mod_tactical_tooltip [A similar feature is included in Reforged]",
	// New Champions by LeVilainJoueur https://www.nexusmods.com/battlebrothers/mods/69
	// It overwrites `tactical_entity_manager.setupEntity` and calls the base `actor` class's `makeMiniboss`
	// instead of calling the `makeMiniboss` defined in the entity's own file.
	// This breaks any custom implementation of `makeMiniboss` in entities.
	"tnf_newChampions [Breaks the implementation of champion enemies in Reforged]"
]);

// Some mods don't register with hooks, so we have to check for their existence by their filename
::Reforged.checkConflictWithFilename <- { function checkConflictWithFilename()
{
	local conflicts = {
		//"15 or 27 roster limit for all scenarios" by knowns. https://www.nexusmods.com/battlebrothers/mods/270
		// Overwrites starting scenario files and hasn't been updated in many years.
		"l_native scenarios to ": "15 or 27 roster limit for all scenarios는 기본 파일을 덮어써 리포지드와 호환되지 않는다. 대체 모드: https://www.nexusmods.com/battlebrothers/mods/445",
		// Better Combat Log by AllanniaBB. https://www.nexusmods.com/battlebrothers/mods/105.
		// Overwrites actor.onMovementFinish which breaks our onAnySkillExecutedFully scheduling system for switchEntities.
		"mod_better_combat_log": "Better Combat Log는 전투원 함수를 덮어써 리포지드와 충돌한다. 전투 기록에서 사기 판정을 보려면 MoraleCheck Log를 사용한다: https://www.nexusmods.com/battlebrothers/mods/663",
		// Detailed Status Effects by LiaAshborn. https://www.nexusmods.com/battlebrothers/mods/103
		// Incompatible because it overwrites getTooltip of actor and player and causes Reforged tactical tooltip to not work.
		"mod_detailed_status_effects": "자세한 상태 효과는 Reforged와 호환되지 않습니다. Reforged에는 중첩된 툴팁을 통해 자세한 정보를 보여주는 자체 전술 툴팁이 있습니다.",
		// This filename is used by two mods, both are incompatible for the same reason:
		// Numbers for text by lichtfield. https://www.nexusmods.com/battlebrothers/mods/316.
		// Number's Detailed by wyoian https://www.nexusmods.com/battlebrothers/mods/94.
		// Cause issues because they overwrite config/strings.
		"mod_numbers": "mod_numbers is incompatible with Reforged. Causes enemies to have wrong names. Use More Indirect Numeral Adjectives by UnauthorizedShell instead.",
		// Show Enemy Stats by LiaAshborn. https://www.nexusmods.com/battlebrothers/mods/98
		"mod_show_enemy_stats": "적 통계 표시는 Reforged와 호환되지 않습니다. 유사한 기능이 이미 Reforged에 포함되어 있습니다.",
		// Smart Recruiter by Leonionin. https://www.nexusmods.com/battlebrothers/mods/172
		// Conflicts on hiring screen and breaks our perk tree display there
		"mod_smart_recruiter": "Smart Recruiter는 Reforged와 호환되지 않습니다. 대신 Enduriel의 Clever Recruiter를 사용하세요.",
		// A variant file of Smart Recruiter on the same mod page as above.
		"mod_sr_alternative": "Smart Recruiter는 Reforged와 호환되지 않습니다. 대신 Enduriel의 Clever Recruiter를 사용하세요.",
		// Uncapped Levels and Perk Points by KillersToys https://www.nexusmods.com/battlebrothers/mods/260
		// Overwrites config/character.
		"mod_uncapped_levels": "무제한 레벨 및 특전 포인트는 Reforged와 호환되지 않습니다. Reforged에서는 최대 플레이어 레벨에 제한이 없습니다.",
		// Part of "Tweaks and Fixes" by LeVilainJoueur. https://www.nexusmods.com/battlebrothers/mods/69
		// Modifies hire screen causing the perk trees from Reforged to not appear there
		"tnf_tryout": "tnf_tryout is incompatible with Reforged. Use Clever Recruiter by Enduriel instead."
	};

	local coreCount = 0;
	local assetsCount = 0;
	foreach (filePath in ::IO.enumerateFiles("data/"))
	{
		if (filePath.find("data/mod_reforged_core") != null)
		{
			coreCount++;
		}
		else if (filePath.find("data/mod_reforged_assets") != null)
		{
			assetsCount++;
		}

		foreach (filename, reason in conflicts)
		{
			// Add "data/" because we don't want to check inside subfolders
			if (filePath.find("data/" + filename) != null)
			{
				::Hooks.errorAndQuit(reason);
			}
		}
	}

	if (coreCount > 1)
		::Hooks.errorAndQuit("데이터 폴더에 추가 Reforged 코어 파일이 있습니다. 불필요한 항목을 삭제하고 최신 버전만 유지하세요.");
	if (assetsCount > 1)
		::Hooks.errorAndQuit("데이터 폴더에 추가 Reforged 자산 파일이 있습니다. 불필요한 항목을 삭제하고 최신 버전만 유지하세요.");
}}.checkConflictWithFilename;
