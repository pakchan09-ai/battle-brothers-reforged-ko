::Reforged.Text <- {
	// Converts a given integer into a text which represents that number
	// e.g. 1: one, 51: fifty one, 1251: one thousand two hundred and fifty one
	// Supports language up to "million". Does not convert higher numbers to "billion" etc.
	// i.e. billion will be written as thousand million.
	function getNumberAsText( _number )
	{
		if (_number == 0)
			return "제로";

		local ret = "";
		local n = _number;
		if (n < 0)
		{
			ret = "부정적인 ";
			n = -n;
		}

		local units = ["", "하나", "두", "세", "네", "다섯", "여섯", "일곱", "여덟", "아홉", "10", "열한", "열두", "열셋", "열넷", "열다섯", "열여섯", "열일곱", "열여덟", "열아홉"];
		local tens = ["", "", "스물", "서른", "마흔", "오십", "예순", "칠십", "여든", "구십"];

		// Helper function to process groups of three digits (up to 999)
		local getPart = function( _n )
		{
			local str = "";
			if (_n >= 100)
			{
				str += units[_n / 100] + " 백";
				_n = _n % 100;
				if (_n > 0)
					str += " 그리고 ";
			}

			if (_n >= 20)
			{
				str += tens[_n / 10];
				if (_n % 10 > 0)
					str += " " + units[_n % 10];
			}
			else if (_n > 0)
			{
				str += units[_n];
			}
			return str;
		};

		if (n >= 1000000)
		{
			ret += getPart(n / 1000000) + " 백만";
			n = n % 1000000;
			if (n > 0)
				ret += (n < 100 ? " 그리고 " : " ");
		}

		if (n >= 1000)
		{
			ret += getPart(n / 1000) + " 천";
			n = n % 1000;
			if (n > 0)
				ret += (n < 100 ? " 그리고 " : " ");
		}

		if (n > 0)
		{
			ret += getPart(n);
		}

		return ret;
	}

	function getDayHourString( _seconds )
	{
		local days = ::Math.floor(_seconds / ::World.getTime().SecondsPerDay);
		local hours = ::Math.floor(_seconds / ::World.getTime().SecondsPerHour) % 24;
		local dayHourString = "";
		switch (days)
		{
			case 0:
				break;	// empty string
			case 1:
				dayHourString = "1일 및 ";
				break;
			default:
				dayHourString = days + " 일과 ";
		}
		dayHourString += (hours == 0) ? "" : hours + " 시간";
		return dayHourString;
	}

	function getDaysAndHalf( _seconds )
	{
		local doubleDays = ::Math.round(2.0 * (_seconds / ::World.getTime().SecondsPerDay));
		local daysAndHalf = (doubleDays / 2.0);
		if (daysAndHalf <= 1.0)
			return "하루"

		if (daysAndHalf == daysAndHalf.tointeger())
			return daysAndHalf + " 일";

		return this.getNumberAsText(daysAndHalf.tointeger()) + " 그리고 반나절";
	}

	function getDaysRemainingText( _numDays )
	{
		if (_numDays > 8)
			return "오랫동안";
		if (_numDays >= 6)
			return "일주일 정도 더";
		if (_numDays >= 4)
			return "며칠 더";
		if (_numDays >= 2)
			return "며칠 더";
		if (_numDays >= 1)
			return "또 하루 정도";

		return "하루 미만";
	}

	function getDaysAgoAsText( _numDays )
	{
		if (_numDays > 8)
			return "오래 전";
		if (_numDays >= 6)
			return "일주일쯤 전";
		if (_numDays >= 4)
			return "며칠 전";
		if (_numDays >= 2)
			return "며칠 전";
		if (_numDays == 1)
			return "어제";

		return "오늘";
	}
}
