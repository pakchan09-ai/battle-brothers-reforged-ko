{ // General page
	local generalPage = ::Reforged.Mod.ModSettings.addPage("General", "일반");

	generalPage.addTitle("General_Title_Misc", "기타");

	generalPage.addEnumSetting("CraftingBlueprintVisibility", "One Ingredient Available", ["Always", "One Ingredient Available", "All Ingredients Available", "Vanilla"], "청사진은 다음과 같은 경우에 표시됩니다.", "이 조건이 충족되면 박제사에서 제작 레시피가 표시됩니다.\n개별 블루프린트(예: 뱀 기름)에는 여전히 표시되지 않도록 하는 사용자 정의 규칙이 있을 수 있습니다.\n\n'바닐라'는 가시성 동작이 기본 게임에서 작동하는 방식과 동일하다는 것을 의미합니다.");
	generalPage.addBooleanSetting("ConfirmSkillUse", false, "스킬 사용 확인", "활성화하면 일반적으로 즉시 사용되는 스킬(예: Shieldwall, Rally)을 대신 캐릭터를 대상으로 지정해야 합니다. 이를 통해 액션 포인트 및 피로 비용과 다른 기술의 예상 경제성을 미리 볼 수 있습니다. '스킬 사용 확인' 키(기본 Ctrl)를 누르고 있으면 이를 우회하고 바로 스킬을 사용할 수 있습니다.\n\n비활성화되면 이러한 스킬은 바닐라처럼 즉시 사용되지만 키 바인딩을 사용하여 미리 보고 확인이 필요할 수 있습니다.");

	generalPage.addDivider("MiscDivider1");
	generalPage.addTitle("General_Title_Contracts", "계약");
	generalPage.addEnumSetting("SkipContractsToScreen", "Disabled", ["Disabled", "Negotiation", "Overview"], "다음으로 계약 건너뛰기", "정착지에서 계약을 열 때 특정 화면으로 건너뛰어 시간을 절약할 수 있습니다.\n\n비활성화됨: 바닐라와 동일한 동작으로 계약의 모든 화면을 클릭해야 합니다.\n\n협상: 소개 화면을 건너뛰고 바로 협상으로 넘어갑니다.\n\n개요: 계약을 수락하거나 거부할 수 있는 최종 화면으로 건너뜁니다. 이 옵션을 사용하면 더 이상 수동으로 계약을 협상할 수 없습니다.");
	generalPage.addRangeSetting("AutoNegotiateAttempts", 0, 0, 10, 1, "자동 협상 시도", "합의에서 계약을 클릭하면 추가 지불을 위해 여러 번 자동 협상됩니다. 이 프로세스는 고용주가 협상 시도를 거부하거나(예: 제안을 높이지 않음) 협상이 실패하는 즉시 중단됩니다.");
}
{ // Tooltips page
	local tooltipsPage = ::Reforged.Mod.ModSettings.addPage("Tooltips", "툴팁");

	tooltipsPage.addTitle("Tooltips_Title_CharacterScreen", "캐릭터 화면");

	tooltipsPage.addBooleanSetting("CharacterScreen_ShowAttributeProjection", true, "속성 투영 표시", "활성화하면 캐릭터 배경 툴팁에 투영된 속성 값이 표시되어 모든 레벨 업이 해당 속성에 투자되면 각 속성이 얼마나 성장할 수 있는지 추정합니다.");
	tooltipsPage.addBooleanSetting("CharacterScreen_ShowBaseAttributeRangesHiring", true, "기본 속성 범위 표시(고용)", "활성화된 경우 채용 중에 배경 아이콘 위로 마우스를 가져가면 모든 배경에 대한 최대 및 최소 기본 속성 범위가 표시됩니다.");
	tooltipsPage.addEnumSetting("CharacterScreen_ShowBaseAttributeRangesRegular", "Only New Recruits", ["Always", "Only New Recruits", "Never"], "기본 속성 범위 표시(일반)", "이 조건이 충족되면 툴팁을 볼 때 배경의 최소 및 최대 기본 속성 범위가 표시됩니다. '신입 모집자만'은 레벨 업을 1회 사용하면 정보 표시를 중지합니다.");

	tooltipsPage.addDivider("Tooltips_Divider1");
	tooltipsPage.addTitle("Tooltips_Title_TacticalTooltips", "전투 중인 캐릭터");

	tooltipsPage.addEnumSetting("TacticalTooltip_Values", "All", ["All", "AI Only", "Player Only", "None"], "값 표시", "몰입형 단어 대신 Hitpoints, Armor 등을 값으로 표시합니다.");
	tooltipsPage.addEnumSetting("TacticalTooltip_Attributes", "All", ["All", "AI Only", "Player Only", "None"], "속성 표시", "전술 도구 설명에 개체에 대한 근접 스킬, 근접 방어 등과 같은 속성을 표시합니다.");
	tooltipsPage.addEnumSetting("TacticalTooltip_Effects", "All", ["All", "AI Only", "Player Only", "None"], "효과 표시", "전술 도구 설명에 개체의 상태 효과를 표시합니다.");
	tooltipsPage.addEnumSetting("TacticalTooltip_Perks", "All", ["All", "AI Only", "Player Only", "None"], "특전 표시", "전술 도구 설명에 개체에 대한 특전을 표시합니다.");
	tooltipsPage.addEnumSetting("TacticalTooltip_EquippedItems", "All", ["All", "AI Only", "Player Only", "None"], "장착된 아이템 표시", "전술 도구 설명에 개체가 장착한 아이템이 표시됩니다.");
	tooltipsPage.addEnumSetting("TacticalTooltip_BagItems", "All", ["All", "AI Only", "Player Only", "None"], "가방 아이템 보기", "전술 도구 설명에 개체의 가방에 있는 항목을 표시합니다.");
	tooltipsPage.addEnumSetting("TacticalTooltip_ActiveSkills", "All", ["All", "AI Only", "Player Only", "None"], "액티브 스킬 표시", "전술 도구 설명에 개체에 사용할 수 있는 모든 활성 기술이 표시됩니다.");
	tooltipsPage.addRangeSetting("TacticalTooltip_CollapseEffectsWhenX", 5, 0, 20, 1, "축소 효과", "효과 수가 이 값보다 적으면 모든 효과는 해당 아이콘을 표시하고 별도의 줄을 사용합니다. 그렇지 않으면 공간을 절약하기 위해 단일 텍스트 블록으로 결합됩니다.");
	tooltipsPage.addRangeSetting("TacticalTooltip_CollapsePerksWhenX", 5, 0, 20, 1, "혜택 축소 시기", "특전 수가 이 값보다 적으면 모든 특전은 해당 아이콘을 표시하고 별도의 줄을 사용합니다. 그렇지 않으면 공간을 절약하기 위해 단일 텍스트 블록으로 결합됩니다.");
	tooltipsPage.addRangeSetting("TacticalTooltip_CollapseActivesWhenX", 5, 0, 20, 1, "활성 상태 축소:", "활성 스킬 수가 이 값보다 적으면 해당 아이콘이 표시되고 별도의 줄을 사용합니다. 그렇지 않으면 공간을 절약하기 위해 단일 텍스트 블록으로 결합됩니다.");
	tooltipsPage.addBooleanSetting("TacticalTooltip_CollapseAsText", false, "텍스트로 축소", "활성화되면 스킬은 이름을 텍스트로 사용하여 축소되고, 그렇지 않으면 아이콘을 사용하여 축소됩니다.");
	tooltipsPage.addBooleanSetting("TacticalTooltip_ShowStatusPerkAndEffect", true, "상태 특전 및 효과 표시", "일부 특전은 상태 효과이기도 합니다. 일반적으로 해당 효과는 특정 조건이 충족될 때까지 숨겨집니다. 이 설정이 활성화되면 이러한 특전은 효과 아래에 표시되는 경우에도(예: 효과가 활성화된 경우) 특전 카테고리에 표시됩니다. 비활성화된 경우 효과 아래에 표시되면 혜택 카테고리에서 숨겨집니다. 이렇게 하면 도구 설명 공간을 절약하는 데 도움이 됩니다.");
	tooltipsPage.addBooleanSetting("TacticalTooltip_HeaderForEmptyCategories", false, "빈 카테고리에 대한 헤더 표시");

	tooltipsPage.addDivider("Tooltips_Divider2");
	tooltipsPage.addTitle("Tooltips_Title_MovementPreview", "이동 미리보기");

	tooltipsPage.addEnumSetting("TacticalTooltip_MovementPreviewHitchances", "All", ["All", "AI Only", "Player Only", "None"], "예측된 장애 표시", "이동 미리보기 중에 호버링된 타일을 기반으로 예상 적중 확률과 적중 확률을 표시합니다.");
	tooltipsPage.addRangeSetting("TacticalTooltip_CollapseHitchanceThreshold", 5, 0, 100, 1, "장애 임계값 축소", "이동 미리보기 중에 예상되는 적중률이 이 이하인 상대는 단일 툴팁 항목으로 축소됩니다.");
}
{ // Debug page
	local debugPage = ::Reforged.Mod.ModSettings.addPage("Debug", "디버그 및 개발");
	debugPage.addBooleanSetting("Debug_onAnySkillExecutedFully", true, "onAnySkillExecutedFully", "onAnySkillExecutedFully 모듈의 디버그 로깅을 활성화합니다.").addBeforeChangeCallback(@( _newValue ) ::Reforged.Mod.Debug.setFlag(::Reforged.DebugFlag.onAnySkillExecutedFully, _newValue));
	debugPage.addBooleanSetting("Debug_AIAgentFixes", false, "AIAgentFixes", "AIAgentFixes 모듈의 디버그 로깅을 활성화합니다.").addBeforeChangeCallback(@( _newValue ) ::Reforged.Mod.Debug.setFlag(::Reforged.DebugFlag.AIAgentFixes, _newValue));

	debugPage.addTitle("Title_DevOptions", "개발 옵션");
	debugPage.addBooleanSetting("Dev_SpawnsInfo", false, "스폰 정보", "파티 비용/강도, 스폰 날짜 등 스폰에 관한 다양한 정보를 월드맵에 표시할 수 있습니다.");
}
{ // Keybinds
	::Reforged.Mod.Keybinds.addSQKeybind("Tactical_WaitRound", "h", ::MSU.Key.State.Tactical, function()
	{
		if (this.m.MenuStack.hasBacksteps() || this.isInputLocked() || this.isInCharacterScreen())
		{
			return false;
		}
		else
		{
			::Tactical.TurnSequenceBar.RF_onWaitTurnAllButtonPressed();
			return true;
		}
	}, "모든 캐릭터로 차례를 기다리세요");

	::Reforged.Mod.Keybinds.addSQKeybind("Tactical_PauseAI", "ctrl+space", ::MSU.Key.State.Tactical, function()
	{
		if (!::Tactical.isActive() || this.m.MenuStack.hasBacksteps() || this.isInCharacterScreen())
		{
			return false;
		}
		else
		{
			local activeEntity = ::Tactical.TurnSequenceBar.getActiveEntity();
			// We only allow pausing, while it is not the players turn, in order to prevent buffering inputs which can cause buggy behavior
			if (::Tactical.State.isPaused() || activeEntity == null || !activeEntity.isPlayerControlled())
			{
				::Tactical.State.setPause(!::Tactical.State.isPaused());
			}

			return true;
		}
	}, "전술적 전투 일시 중지");

	::Reforged.Mod.Keybinds.addSQKeybind("ConfirmSkillUseKeybind", "ctrl", ::MSU.Key.State.Tactical, @() true, "스킬 사용 확인", null, "일반적으로 즉시 사용되는 스킬(예: Shieldwall, Rally)에 대한 확인 요구 사항을 전환하는 데 사용됩니다. '스킬 사용 확인' 설정에 따라 액션 포인트와 피로 비용을 미리 보거나 확인을 우회할 수 있습니다.");

	::Reforged.Mod.Keybinds.addSQKeybind("ToggleReforgedDevMode", "ctrl+tab", ::MSU.Key.State.All, function() { ::Reforged.__toggleDevMode(); return true; }, "리포지드 개발 모드 전환", null, "Reforged의 개발 모드를 전환하는 데 사용됩니다. 이를 통해 다양한 Dev 모드 설정을 한 번에 활성화/비활성화할 수 있습니다.");
}
