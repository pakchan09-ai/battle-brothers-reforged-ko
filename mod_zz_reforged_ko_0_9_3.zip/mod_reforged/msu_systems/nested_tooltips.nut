local getThresholdForInjury = function( _script )
{
	foreach (entry in ::Const.Injury.All)
	{
		if (entry.Script == _script)
			return entry.Threshold * 100;
	}
}

// Apply nesting in events
{
	// World entities get assigned their labels during `updateStrength` when they spawn
	// during events or contracts. The label assigns their name by using getName(). We need
	// to return a name during this time that isn't nested with tooltip tags.
	::Reforged.HooksMod.hookTree("scripts/entity/world/world_entity", function(q) {
		q.updateStrength = @(__original) { function updateStrength()
		{
			local original_IsApplyingNestingForEvents = ::Reforged.NestedTooltips.__IsApplyingNestingForEvents;
			::Reforged.NestedTooltips.__IsApplyingNestingForEvents = 0;
			__original();
			::Reforged.NestedTooltips.__IsApplyingNestingForEvents = original_IsApplyingNestingForEvents;
		}}.updateStrength;
	});

	::Reforged.HooksMod.hookTree("scripts/entity/tactical/actor", function(q) {
		q.getName = @(__original) { function getName()
		{
			return ::Reforged.NestedTooltips.isApplyingNestingForEvents() ? ::Reforged.Mod.Tooltips.parseString(format("[%s|EventActor+%i]", ::Reforged.Mod.Tooltips.removeAllFromString(__original()), this.getID())) : __original();
		}}.getName;

		q.getNameOnly = @(__original) { function getNameOnly()
		{
			return ::Reforged.NestedTooltips.isApplyingNestingForEvents() ? ::Reforged.Mod.Tooltips.parseString(format("[%s|EventActor+%i]", ::Reforged.Mod.Tooltips.removeAllFromString(__original()), this.getID())) : __original();
		}}.getNameOnly;
	});

	::Reforged.HooksMod.hookTree("scripts/items/item", function(q) {
		q.getName = @(__original) { function getName()
		{
			return ::Reforged.NestedTooltips.isApplyingNestingForEvents() ? ::Reforged.Mod.Tooltips.parseString(format("[%s|Obj+%s,contentType:ui-item]", ::Reforged.Mod.Tooltips.removeAllFromString(__original()), ::Reforged.Mod.Tooltips.parseObject(this))) : __original();
		}}.getName;

		q.getIcon = @(__original) { function getIcon()
		{
			return ::Reforged.NestedTooltips.isApplyingNestingForEvents() ? ::Reforged.Mod.Tooltips.parseString(format("[Img/gfx/ui/items/%s|Obj+%s,contentType:ui-item]", ::Reforged.Mod.Tooltips.removeAllFromString(__original()), ::Reforged.Mod.Tooltips.parseObject(this))) : __original();
		}}.getIcon;
	});

	::Reforged.HooksMod.hookTree("scripts/skills/skill", function(q) {
		q.getName = @(__original) { function getName()
		{
			return ::Reforged.NestedTooltips.isApplyingNestingForEvents() ? ::Reforged.Mod.Tooltips.parseString(format("[%s|Skill+%s%s]", ::Reforged.Mod.Tooltips.removeAllFromString(__original()), this.ClassName, ::MSU.isNull(this.getContainer()) ? "" : ",entityId:" + this.getContainer().getActor().getID())) : __original();
		}}.getName;

		if (q.contains("getNameOnly"))
		{
			q.getNameOnly = @(__original) { function getNameOnly()
			{
				return ::Reforged.NestedTooltips.isApplyingNestingForEvents() ? ::Reforged.Mod.Tooltips.parseString(format("[%s|Skill+%s%s]", ::Reforged.Mod.Tooltips.removeAllFromString(__original()), this.ClassName, ::MSU.isNull(this.getContainer()) ? "" : ",entityId:" + this.getContainer().getActor().getID())) : __original();
			}}.getNameOnly;
		}

		q.getIcon = @(__original) { function getIcon()
		{
			return ::Reforged.NestedTooltips.isApplyingNestingForEvents() ? ::Reforged.Mod.Tooltips.parseString(format("[이미지/gfx/%s|Skill+%s%s]", ::Reforged.Mod.Tooltips.removeAllFromString(__original()), this.ClassName, ::MSU.isNull(this.getContainer()) ? "" : ",entityId:" + this.getContainer().getActor().getID())) : __original();
		}}.getIcon;

		q.getIconColored = @(__original) { function getIconColored()
		{
			return ::Reforged.NestedTooltips.isApplyingNestingForEvents() ? ::Reforged.Mod.Tooltips.parseString(format("[이미지/gfx/%s|Skill+%s%s]", ::Reforged.Mod.Tooltips.removeAllFromString(__original()), this.ClassName, ::MSU.isNull(this.getContainer()) ? "" : ",entityId:" + this.getContainer().getActor().getID())) : __original();
		}}.getIconColored;

		q.getIconDisabled = @(__original) { function getIconDisabled()
		{
			return ::Reforged.NestedTooltips.isApplyingNestingForEvents() ? ::Reforged.Mod.Tooltips.parseString(format("[이미지/gfx/%s|Skill+%s%s]", ::Reforged.Mod.Tooltips.removeAllFromString(__original()), this.ClassName, ::MSU.isNull(this.getContainer()) ? "" : ",entityId:" + this.getContainer().getActor().getID())) : __original();
		}}.getIconDisabled;
	});

	::Reforged.HooksMod.hookTree("scripts/factions/faction", function(q) {
		q.getName = @(__original) { function getName()
		{
			return ::Reforged.NestedTooltips.isApplyingNestingForEvents() ? ::Reforged.Mod.Tooltips.parseString(format("[%s|Faction+%i]", ::Reforged.Mod.Tooltips.removeAllFromString(__original()), this.getID())) : __original();
		}}.getName;

		// Some entities are spawned during event/contract `setScreen` while isApplyingNestingForEvents is true.
		// This causes the `_name` passed here to sometimes contain nested tooltip tags. So we have to clean up
		// the name otherwise the world map label for the entity ends up with the tooltip tags.
		// Note: An alternative would be to allow nested tooltips in name (so they appear in the tooltip of the entity)
		// but hook `updateStrength` to retroactively remove the tooltips from the name label.
		q.spawnEntity = @(__original) { function spawnEntity( _tile, _name, _uniqueName, _template, _resources, _minibossify = 0 )
		{
			if (::Reforged.NestedTooltips.isApplyingNestingForEvents())
			{
				_name = ::Reforged.Mod.Tooltips.removeAllFromString(_name);
			}
			return __original(_tile, _name, _uniqueName, _template, _resources, _minibossify);
		}}.spawnEntity;

		if (q.contains("getNameOnly"))
		{
			q.getNameOnly = @(__original) { function getNameOnly()
			{
				return ::Reforged.NestedTooltips.isApplyingNestingForEvents() ? ::Reforged.Mod.Tooltips.parseString(format("[%s|Faction+%i]", ::Reforged.Mod.Tooltips.removeAllFromString(__original()), this.getID())) : __original();
			}}.getNameOnly;
		}
	});

	::Reforged.HooksMod.hookTree("scripts/entity/world/world_entity", function(q) {
		q.getName = @(__original) { function getName()
		{
			return ::Reforged.NestedTooltips.isApplyingNestingForEvents() ? ::Reforged.Mod.Tooltips.parseString(format("[%s|WorldEntity+%i]", ::Reforged.Mod.Tooltips.removeAllFromString(__original()), this.getID())) : __original();
		}}.getName;
	});

	::Reforged.HooksMod.hookTree("scripts/entity/world/attached_location", function(q) {
		q.getRealName = @(__original) { function getRealName()
		{
			return ::Reforged.NestedTooltips.isApplyingNestingForEvents() ? ::Reforged.Mod.Tooltips.parseString(format("[%s|WorldEntity+%i]", ::Reforged.Mod.Tooltips.removeAllFromString(__original()), this.getID())) : __original();
		}}.getRealName;
	});

	::Reforged.QueueBucket.Late.push(function() {
		::Reforged.HooksMod.hook("scripts/statistics/statistics_manager", function(q) {
			q.addFallen = @(__original) { function addFallen( _fallen )
			{
				// Remove nested tooltip tags from the fallen data in case addFallen is called during events
				// e.g. from "hedgeknight_vs_hedgeknight_event" and "cultist_origin_sacrifice_event" so that
				// the name stored in the Obituary is without these tags.
				if (::Reforged.NestedTooltips.isApplyingNestingForEvents())
				{
					foreach (k, v in _fallen)
					{
						if (typeof v == "string")
						{
							_fallen[k] = ::Reforged.Mod.Tooltips.removeAllFromString(v);
						}
					}
				}

				__original(_fallen);
			}}.addFallen;
		});
	});
}

::Reforged.NestedTooltips <- {
	__IsApplyingNestingForEvents = 0,

	Tooltips = {
		Concept = {}
	},
	AutoConcepts = [
		"character-stats.ActionPoints",
		"character-stats.Hitpoints",
		"character-stats.Morale",
		"character-stats.Fatigue",
		"character-stats.MaximumFatigue",
		"character-stats.ArmorHead",
		"character-stats.ArmorBody",
		"character-stats.MeleeSkill",
		"character-stats.RangeSkill",
		"character-stats.MeleeDefense",
		"character-stats.RangeDefense",
		"character-stats.SightDistance",
		"character-stats.RegularDamage",
		"character-stats.CrushingDamage",
		"character-stats.ChanceToHitHead",
		"character-stats.Initiative",
		"character-stats.Bravery",
		"character-stats.Talent",
		"character-stats.SightDistance"

		"character-screen.left-panel-header-module.Experience",
		"character-screen.left-panel-header-module.Level",

		"assets.BusinessReputation",
		"assets.MoralReputation"
	],

	function setApplyNestingForEvents( _apply )
	{
		// Have to do it as a "stack" because functions which set this on/off
		// can be called from within themselves and we don't want to set it to
		// false in the middle of such a call stack.
		if (_apply)
			this.__IsApplyingNestingForEvents += 1;
		else if (this.__IsApplyingNestingForEvents > 0)
			this.__IsApplyingNestingForEvents -= 1;
	}

	function isApplyingNestingForEvents()
	{
		return this.__IsApplyingNestingForEvents != 0;
	}

	function getNestedPerkName( _obj, _extraData = null )
	{
		local perkDef = ::Const.Perks.findById(_obj.getID());
		return format("[%s|Perk+%s%s]", perkDef != null ? perkDef.Name : _obj.m.Name, _obj.ClassName, _extraData == null ? "" : "," + _extraData);
	}

	function getNestedPerkImage( _obj, _extraData = null )
	{
		local perkDef = ::Const.Perks.findById(_obj.getID());
		return format("[이미지/gfx/%s|Perk+%s%s,cssClass:rf-nested-skill-image]", perkDef != null ? perkDef.Icon : _obj.getIcon(), _obj.ClassName, _extraData == null ? "" : "," + _extraData);
	}

	function getNestedSkillName( _obj, _extraData = null, _getName = false )
	{
		// We use `.m.Name` instead of `getName()` because some skills (e.g. status effects)
		// modify the name during getName() e.g. to add info about the number of stacks
		return format("[%s|Skill+%s%s]", _getName ? _obj.getName() : _obj.m.Name, _obj.ClassName, _extraData == null ? "" : "," + _extraData);
	}

	function getNestedSkillImage( _obj, _extraData = null, _checkUsability = false )
	{
		local icon = !_checkUsability || _obj.isUsable() && _obj.isAffordable() ? _obj.getIconColored() : _obj.getIconDisabled();
		return format("[이미지/gfx/%s|Skill+%s%s,cssClass:rf-nested-skill-image]", icon, _obj.ClassName, _extraData == null ? "" : "," + _extraData);
	}

	function getNestedItemName( _obj, _extraData = null )
	{
		return format("[%s|Item+%s%s]", _obj.getName(), _obj.ClassName, _extraData == null ? "" : "," + _extraData);
	}

	function getNestedItemImage( _obj, _extraData = null )
	{
		return format("[Img/gfx/ui/items/%s|Item+%s%s]", _obj.getIcon(), _obj.ClassName, _extraData == null ? "" : "," + _extraData);
	}

	function getNestedEntityImage( _obj, _extraData = null )
	{
		return format("[Img/gfx/ui/orientation/%s.png|Entity+%i%s,cssClass:rf-nested-skill-image]", _obj.getOverlayImage(), _obj.getID(), _extraData == null ? "" : "," + _extraData);
	}

	function getNestedEntityName( _obj, _extraData = null )
	{
		return format("[%s|Entity+%i%s]", _obj.getName(), _obj.getID(), _extraData == null ? "" : "," + _extraData);
	}

	function getNestedWorldEntityName( _obj, _extraData = null )
	{
		return format("[%s|WorldEntity+%i%s]", _obj.getName(), _obj.getID(), _extraData == null ? "" : "," + _extraData);
	}

	function getNestedFactionName( _obj, _extraData = null )
	{
		return format("[%s|Faction+%i%s]", _obj.getName(), _obj.getID(), _extraData == null ? "" : "," + _extraData);
	}

	function getNestedObjectName( _obj, _extraData = null )
	{
		return format("[%s|Obj+%s%s]", _obj.getName(), ::Reforged.Mod.Tooltips.parseObject(_obj), _extraData == null ? "" : "," + _extraData);
	}
}

::Reforged.QueueBucket.FirstWorldInit.push(function() {
	foreach (concept in ::Reforged.NestedTooltips.AutoConcepts)
	{
		local c = concept;
		::Reforged.NestedTooltips.Tooltips.Concept[split(concept, ".").top()] <- ::MSU.Class.CustomTooltip(@(_) ::TooltipScreen.m.TooltipEvents.general_queryUIElementTooltipData(::MSU.getDummyPlayer().getID(), c, null));
	}

	::MSU.Table.merge(::Reforged.NestedTooltips.Tooltips.Concept, {
		Disabled = ::MSU.Class.BasicTooltip("행동 불능", ::Reforged.Mod.Tooltips.parseString("행동 불능 상태에서는 행동할 수 없어 [턴|Concept.Turn]을 건너뛴다.\n\n행동을 막는 [상태 효과|Concept.StatusEffect]로는 [$ $|Skill+stunned_effect], [$ $|Skill+sleeping_effect] 등이 있다.")),
		Rooted = ::MSU.Class.BasicTooltip("루팅됨", ::Reforged.Mod.Tooltips.parseString("루팅된 캐릭터는 제자리에 고정되어 움직일 수 없거나 해당 위치에서 이동할 수 없습니다.\n\n예 [효과|Concept.StatusEffect] 캐릭터가 루팅될 수 있습니다. [$ $|Skill+net_effect] 그리고 [$ $|Skill+web_effect].")),
		Wait = ::MSU.Class.BasicTooltip("잠깐", ::Reforged.Mod.Tooltips.parseString(format("당신이 마지막 캐릭터가 아닌 경우 [행동 순서|Concept.Turn] 에 [라운드|Concept.Round], 대기 작업을 사용할 수 있습니다. 그러면 현재의 끝으로 이동합니다. [행동 순서|Concept.Turn], 종료되기 전에 다시 작업을 수행할 수 있습니다. [라운드|Concept.Round].\n\n대기는 한 번만 사용할 수 있습니다. [턴|Concept.Turn].%s", ::Const.CharacterProperties.InitiativeAfterWaitMult == 1.0 ? "" : "\n\n대기를 사용하면 [행동 순서|Concept.Turn] 다음에는 [라운드|Concept.Round] 로 계산하다 " + ::MSU.Text.colorizeMult(::Const.CharacterProperties.InitiativeAfterWaitMult) + " " + (::Const.CharacterProperties.InitiativeAfterWaitMult > 1.0 ? "더" : "덜") + " [주도력|Concept.Initiative]."))),
		Perk = ::MSU.Class.BasicTooltip("특전", ::Reforged.Mod.Tooltips.parseString("캐릭터가 레벨을 높이면 강력한 특전을 잠금 해제하는 데 사용할 수 있는 특전 포인트가 잠금 해제됩니다. 특전은 캐릭터에게 영구적인 보너스를 부여하거나 사용할 수 있는 새로운 기술을 잠금 해제합니다. 캐릭터의 현재 [퍽 단계|Concept.PerkTier] 퍽 포인트를 사용할 때마다 1씩 증가합니다.")),
		StatusEffect = ::MSU.Class.BasicTooltip("상태 효과", ::Reforged.Mod.Tooltips.parseString("상태 효과는 캐릭터에 대한 긍정적이거나 부정적인 효과로, 대부분 일시적입니다. 상태 효과는 증가/감소에 이르기까지 다양한 효과를 가질 수 있습니다. [능력치|Concept.CharacterAttribute] 새로운 능력을 잠금 해제하는 것입니다.")),
		Injury = ::MSU.Class.BasicTooltip("부상", ::Reforged.Mod.Tooltips.parseString("충분한 피해를 입은 경우 [체력|Concept.Hitpoints] 전투 중에 캐릭터가 부상을 입을 수 있습니다. 부상은 [상태 효과|Concept.StatusEffect] 다양한 악의를 불러일으키는 것.\n\n전투 중 입은 부상은 다음과 같습니다. [일시적|Concept.InjuryTemporary], 시간이 지나면 치유됩니다. 이러한 부상은 더 빠른 치유를 위해 사원에서 치료할 수 있습니다.\n\n전투 중에 캐릭터가 죽으면 죽는 대신 쓰러질 확률이 있으며, 전투에서 살아남을 수 있습니다. [영구 부상|Concept.InjuryPermanent]"))
		InjuryTemporary = ::MSU.Class.BasicTooltip("일시적인 부상", ::Reforged.Mod.Tooltips.parseString("전투 중 일시적인 부상을 입는 경우 [체력|Concept.Hitpoints] 캐릭터가 받은 부상 기준이 초과되었습니다. 이러한 부상은 시간이 지나면 치유되지만 더 빠른 치유를 위해 사원에서 치료할 수 있습니다."))
		InjuryPermanent = ::MSU.Class.BasicTooltip("영구 부상", ::Reforged.Mod.Tooltips.parseString("전투 중 캐릭터가 죽는 대신 '쓰러져' 쓰러지면 영구적인 부상을 입습니다. 이러한 부상과 그에 따른 악의는 영원합니다.")),
		InjuryThreshold = ::MSU.Class.BasicTooltip("부상 임계값", ::Reforged.Mod.Tooltips.parseString("손해를 입은 경우 [체력|Concept.Hitpoints] 적어도 " + ::MSU.Text.colorNegative(::Const.Combat.InjuryMinDamage) + " 최대치의 특정 비율보다 큽니다. [체력|Concept.Hitpoints], 캐릭터는 [부상|Concept.InjuryTemporary]. 이 비율은 특정 사용자에 의해 수정될 수 있습니다. [퍽|Concept.Perk] 또는 공격자와 표적 모두의 특성.\n\n확실한 [부상|Concept.InjuryTemporary] 이 비율이 가해지기 전에 최소한 특정 값이 되어야 합니다. [부상|Concept.InjuryTemporary] 더 높은 비율이 필요합니다.\n\n예를 들어 [$ $|Skill+cut_arm_injury] 이다 " + ::MSU.Text.colorNegative(getThresholdForInjury("injury/cut_arm_injury") + "%") + " 그리고 그것은 [$ $|Skill+split_hand_injury] 이다 " + ::MSU.Text.colorNegative(getThresholdForInjury("injury/split_hand_injury") + "%") + ".")),
		Reach = ::MSU.Class.CustomTooltip(function(_data){
			local ret = [
			{
				id = 1,
				type = "title",
				text = "도달"
			},
			{
				id = 2,
				type = "description",
				text = ::Reforged.Mod.Tooltips.parseString("도달 범위는 캐릭터의 공격이 얼마나 멀리 도달할 수 있는지를 나타내며, 도달 범위가 더 짧은 대상에 대한 근접 전투를 더 쉽게 만듭니다.\n\n[근접 공격|Concept.MeleeSkill] 도달 거리가 짧은 상대를 공격하면 증가하고, 도달 거리가 긴 상대를 공격하면 감소합니다. 도달범위는 다음부터 시작하여 수익이 감소합니다. " + ::Reforged.Reach.BonusPerReach + " 1부터 최소 1까지 떨어집니다. 이는 당신과 대상 사이에 아무것도 없는 인접한 대상 또는 최대 2타일 떨어진 대상을 공격할 때만 적용됩니다.\n\n명중 성공 후 목표물의 [리치 우세|Concept.ReachAdvantage] 공격자가 기다리거나 자신의 차례를 끝낼 때까지 손실됩니다.\n\n방패는 대상의 일부 또는 전부를 무효화할 수 있습니다. [리치 우세|Concept.ReachAdvantage]. 루팅된 캐릭터는 도달 범위가 절반으로 줄어듭니다. 근접 공격이 없는 사람은 도달 범위가 없습니다.")
			}]
			if ("entityId" in _data && "TooltipEvents" in this.getroottable())
			{
				ret.extend(::TooltipEvents.getBaseAttributesTooltip( _data.entityId, _data.elementId, null));
			}
			return ret;
		}),
		ReachIgnoreOffensive = ::MSU.Class.BasicTooltip("공격 범위 무시", ::Reforged.Mod.Tooltips.parseString(@"이는 금액을 나타냅니다. [리치 열세|Concept.ReachDisadvantage] 캐릭터가 더 높은 대상을 공격할 때 무시할 수 있는 것 [리치|Concept.Reach].")),
		ReachIgnoreDefensive = ::MSU.Class.BasicTooltip("방어 범위 무시", ::Reforged.Mod.Tooltips.parseString(@"이는 금액을 나타냅니다. [리치 열세|Concept.ReachDisadvantage] 더 높은 공격자를 방어할 때 캐릭터가 무시할 수 있는 것 [리치|Concept.Reach].")),
		ReachAdvantage = ::MSU.Class.BasicTooltip("이점에 도달", ::Reforged.Mod.Tooltips.parseString("캐릭터가 다음과 같은 경우 도달 이점을 보유한 것으로 간주됩니다. [리치|Concept.Reach] 공격 시 다른 캐릭터보다 더 큽니다. 이 경우 도달 이점은 두 캐릭터의 차이를 나타냅니다. [리치|Concept.Reach] 가치.\n\n캐릭터가 방패를 장착한 경우, 방패는 공격자의 도달 이점을 무효화하는 데 도움이 될 수 있습니다. [$ $|Perk+perk_duelist] 특전은 또한 대상의 특전을 무효화하는 데 도움이 될 수 있습니다.")),
		ReachDisadvantage = ::MSU.Class.BasicTooltip("불리한 점에 도달", ::Reforged.Mod.Tooltips.parseString("캐릭터는 다음과 같은 경우 불이익에 도달한 것으로 간주됩니다. [리치|Concept.Reach] 공격 시 상대 캐릭터보다 낮은 수치입니다. 이 경우 Reach Disadvantage는 두 캐릭터의 차이를 나타냅니다. [리치|Concept.Reach] 가치.")),
		PerkTier = ::MSU.Class.BasicTooltip("특전 등급", ::Reforged.Mod.Tooltips.parseString("[퍽|Concept.Perk] 계층이라고 알려진 7개 행에 걸쳐 캐릭터의 특성 트리에 배포됩니다. 해당 계층의 특전을 이용하려면 캐릭터가 최소한 Tier-1만큼 많은 특전 포인트를 소비해야 합니다.")),
		StackMultiplicatively = ::MSU.Class.BasicTooltip("곱셈적으로 쌓기", ::Reforged.Mod.Tooltips.parseString("값은 곱셈적으로 쌓일 수 있습니다. [합산 방식으로|Concept.StackAdditively]. 곱셈적 쌓기는 값이 곱해지는 것을 의미합니다.\n\n예를 들어 값 100을 상상해 보세요. 이 값을 40% 증가시키고 곱셈적으로 스택하는 두 스킬은 값을 총 1.4 x 1.4 = 1.96배 증가시키므로 100 x 1.96 = 196이 됩니다. 40% 감소하고 곱셈적으로 스택하는 두 스킬은 (1.0 - 0.4) x (1.0 - 0.4) =만큼 감소합니다. 0.36배이므로 100 x 0.36 = 36이 됩니다.\n\n일반적으로, [합산 중첩|Concept.StackAdditively] 값을 줄이거나 값이 작을 때 더 강하고, 곱셈 쌓기는 값을 늘리거나 값이 클 때 더 강합니다.")),
		StackAdditively = ::MSU.Class.BasicTooltip("덧셈적으로 쌓기", ::Reforged.Mod.Tooltips.parseString("가치는 쌓일 수 있다 [곱연산으로|Concept.StackMultiplicatively] 또는 추가적으로. Additive Stacking은 값이 더해지는 것을 의미합니다.\n\n예를 들어 100이라는 값을 상상해 보세요. 이 값을 40% 증가시키고 추가로 중첩하는 두 스킬은 값을 총 1.0 + 0.4 + 0.4 = 1.8배 증가시키므로 100 x 1.8 = 180이 됩니다. 40% 감소하고 추가로 중첩하는 두 스킬은 1.0 - 0.4 - 0.4 = 0.2배로 감소하므로 100 x 0.2 = 20.\n\n일반적으로 Additive Stacking은 값을 줄이거나 값이 작을 때 더 강해집니다. [곱연산 중첩|Concept.StackMultiplicatively] 값을 높이거나 값이 클 때 더 강해집니다.")),
		CharacterAttribute = ::MSU.Class.BasicTooltip("캐릭터 속성", ::Reforged.Mod.Tooltips.parseString("Battle Brothers의 캐릭터는 특정 영역에서 캐릭터의 기술 및/또는 적성을 설명하는 다양한 속성을 가지고 있습니다. 속성은 다음과 같습니다: [체력|Concept.Hitpoints], [피로|Concept.Fatigue], [의지|Concept.Bravery], [주도력|Concept.Initiative] [근접 공격|Concept.MeleeSkill], [근접 방어|Concept.MeleeDefense], [원거리 공격|Concept.RangeSkill] 그리고 [원거리 방어|Concept.RangeDefense].\n\n캐릭터가 획득하면 [경험치|Concept.Experience] 그리고 [레벨 상승|Concept.Level] 속성을 높이고 잠금을 해제할 수 있습니다. [퍽|Concept.Perk].")),
		BaseAttribute = ::MSU.Class.BasicTooltip("기본 속성", ::Reforged.Mod.Tooltips.parseString("캐릭터의 [능력치|Concept.CharacterAttribute] 다양한 수단으로 수정될 수 있습니다. 특전, 특성, 상태 효과, 장비 등. 속성의 기본 값은 그러한 수정 전의 값입니다. 참조: [현재 능력치|Concept.CurrentAttribute].")),
		CurrentAttribute = ::MSU.Class.BasicTooltip("현재 속성", ::Reforged.Mod.Tooltips.parseString("캐릭터의 [능력치|Concept.CharacterAttribute] 다양한 수단으로 수정될 수 있습니다. 특전, 특성, 상태 효과, 장비 등. 속성의 현재 값은 그러한 수정 이후의 값입니다. 참조: [기본 능력치|Concept.BaseAttribute].")),
		Surrounding = ::MSU.Class.BasicTooltip("주변", ::Reforged.Mod.Tooltips.parseString("캐릭터가 여러 적대적인 캐릭터의 통제 구역에 있으면 포위된 것으로 간주됩니다. 근접 공격으로 둘러싸인 대상을 공격하는 캐릭터는 추가 적중 기회를 얻습니다. 다음과 같은 여러 특전이 있습니다. [$ $|Perk+perk_underdog], [$ $|Perk+perk_backstabber] 그리고 [$ $|Perk+perk_rf_long_reach] 주변 기계공과 상호작용하여 그 효과를 줄이거나 늘립니다.")),
		FatigueRecovery = ::MSU.Class.BasicTooltip("피로회복", ::Reforged.Mod.Tooltips.parseString("매 턴이 시작될 때마다 [피로|Concept.Fatigue] 캐릭터의 일정량만큼 감소됩니다. 이것을 피로 회복이라고 합니다.\n\n기본적으로 플레이어 캐릭터의 피로 회복은 15인 반면, 적 유형에 따라 적은 훨씬 더 높은 피로 회복을 가질 수 있습니다.\n\n피로 회복은 다음의 영향을 받을 수 있습니다. [퍽|Concept.Perk], [특성|Concept.Trait], [상태 효과|Concept.StatusEffect] 그리고 [부상|Concept.Injury].")),
		AOE = ::MSU.Class.BasicTooltip("효과 범위", ::Reforged.Mod.Tooltips.parseString("AOE(Area of Effect) 스킬은 단일 타일이 아닌 여러 타일을 대상으로 효과를 적용합니다.")),
		Fatality = ::MSU.Class.BasicTooltip("사망자", ::Reforged.Mod.Tooltips.parseString("사망자는 평범함을 넘어서는 어떤 끔찍함을 묘사하는 특별한 형태의 죽음입니다. 사망자는 다음과 같습니다:\n- 참수 - 대상의 머리를 제거합니다.\n- Disembowelment - 대상의 배를 열어 내장을 흘리게 합니다.\n- 스매싱(Smashing) - 대상의 머리를 산산조각으로 부수는 것입니다.")),
		Turn = ::MSU.Class.BasicTooltip("회전", ::Reforged.Mod.Tooltips.parseString("배틀 브라더스의 전투는 턴제입니다. 각 전투는 일련의 전투로 구성됩니다. [라운드|Concept.Round]. 라운드 동안 캐릭터는 차례로 행동합니다. 턴 순서에서 캐릭터의 위치는 캐릭터의 위치에 따라 결정됩니다. [주도력|Concept.Initiative] 다른 캐릭터에 비해\n\n[효과|Concept.StatusEffect] 특정 턴 수만큼 지속되는 것은 캐릭터가 해당 턴을 시작하거나 종료할 때까지 지속됩니다. [효과|Concept.StatusEffect] 각각 턴 시작 또는 종료 시 만료됩니다.")),
		Round = ::MSU.Class.BasicTooltip("라운드", ::Reforged.Mod.Tooltips.parseString("배틀 브라더스의 전투는 턴제입니다. 각 전투는 일련의 라운드로 구성됩니다. 라운드 동안 캐릭터는 다음과 같이 행동합니다. [턴|Concept.Turn]. 모든 캐릭터가 게임을 마치면 라운드가 종료됩니다. [턴|Concept.Turn].")),
		ZoneOfControl = ::MSU.Class.BasicTooltip("통제 구역", ::Reforged.Mod.Tooltips.parseString("대부분의 근접 캐릭터는 주변 타일에 통제 구역을 행사합니다. 적의 통제 구역 밖으로 이동하려고 하면 첫 번째 공격이 적중하거나 모든 공격이 실패할 때까지 제어하는 ​​각 적으로부터 한 번의 무료 공격이 발동됩니다. 히트하면 이동이 취소됩니다.")),
		BagSlots = ::MSU.Class.BasicTooltip("가방 슬롯", ::Reforged.Mod.Tooltips.parseString("가방 슬롯은 전투 중에 사용할 추가 무기나 유틸리티 아이템을 보관하는 데 사용할 수 있습니다. 모든 캐릭터가 가지고 있는 " + ::new("scripts/items/item_container").getUnlockedBagSlots() + " 가방 슬롯은 기본적으로 최대 개수입니다. " + ::Const.ItemSlotSpaces[::Const.ItemSlot.Bag] + ".")),
		HybridWeapon = ::MSU.Class.BasicTooltip("하이브리드 무기", ::Reforged.Mod.Tooltips.parseString("하이브리드 무기는 두 가지 이상의 무기 유형을 갖춘 무기입니다. 비하이브리드 무기에는 무기 유형이 하나만 있습니다.")),
		Trait = ::MSU.Class.BasicTooltip("특성", ::Reforged.Mod.Tooltips.parseString("캐릭터는 반영구적이며 성격의 측면을 나타내는 여러 특성을 가질 수 있습니다. 특성은 다음과 다릅니다. [퍽|Concept.Perk] 그리고 통해 배울 수 없습니다 [경험치|Concept.Experience] 또는 [레벨 상승|Concept.Level]. 특성은 다양한 보너스나 악의를 줄 수 있습니다. 예를 들면 다음과 같습니다. [$ $|Skill+huge_trait] 그리고 [$ $|Skill+tiny_trait]."))
	});

	::Reforged.Mod.Tooltips.setTooltips(::Reforged.NestedTooltips.Tooltips);
});
