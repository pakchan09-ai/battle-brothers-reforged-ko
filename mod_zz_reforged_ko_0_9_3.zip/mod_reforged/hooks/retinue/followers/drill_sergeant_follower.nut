::Reforged.HooksMod.hook("scripts/retinue/followers/drill_sergeant_follower", function(q) {
	q.create = @(__original) function ()
	{
		__original();
		this.m.Effects[0] = "당신의 부하들이 레벨 1에서 40% 더 많은 경험치를 얻도록 하며, 다음 레벨에서는 4%씩 감소합니다."
		this.m.Requirements.clear()		// We remove all Requirements, atleast up until the Retinue Rework
	}

	// Overwrite the vanilla function because it tries to access this.m.Requirements[0] but we already cleared that array so it throws an exception
	q.onEvaluate = @() { function onEvaluate()
	{
	}}.onEvaluate;
});
