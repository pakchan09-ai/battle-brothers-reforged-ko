// This is a testing module for MSU to add a new skill event `onAnySkillExecutedFully` which is triggered
// after all the delayed effects inside a skill execution e.g. scheduleEvent, teleport, switchEntities are complete.

// This class handles keeping track of how many delayed events (e.g. scheduleEvent, teleport) have been
// queued for a skill and how many have been completed. Once all are completed this class triggers
// the onAnySkillExecutedFully event for the container this skill belonged to and then deletes the key from ScheduledSkills.
// Note: It holds a strong reference to the skill, so the skill can never become null while this is keeping track of it.
// Each schedule instance is granted an ID. This helps in the debug logging to see the progression of schedules.
local scheduleID = 0;
::Reforged.SkillSchedule <- class {
	Container = null;
	TargetTile = null;
	TargetEntity = null;
	ForFree = false;
	RegisteredCallbacks = null;

	Count = 0;
	WasScheduled = false;

	ID = null;

	constructor( _skill, _targetTile, _targetEntity, _forFree )
	{
		this.ID = scheduleID++;
		this.Container = ::MSU.asWeakTableRef(_skill.getContainer());
		this.TargetTile = _targetTile;
		this.TargetEntity = _targetEntity;
		this.ForFree = _forFree;
		this.RegisteredCallbacks = [];
	}

	function onScheduleComplete( _info )
	{
		if (this.WasScheduled)
			::Reforged.Mod.Debug.printLog(format("발신자: %s.%s (%s : %i), 콜백: %s, 개수: %i, 일정 ID: %i", _info.Skill.ClassName, _info.Func, _info.Src, _info.Line, _info.Callback, this.Count, this.ID), ::Reforged.DebugFlag.onAnySkillExecutedFully);
		else
			::Reforged.Mod.Debug.printLog(format("발신자: %s, 개수: %i -- 예정된 것이 없습니다. (일반 스킬)", _info.Skill.ClassName, this.Count), ::Reforged.DebugFlag.onAnySkillExecutedFully);
		// Check for <= 0 because when we call this manually, this.Count will be 0 and will drop to -1
		if (--this.Count <= 0)
		{
			if (this.WasScheduled)
				::Reforged.Mod.Debug.printLog(format("일정 완료 -- 발신자: %s.%s (%s : %i), 콜백: %s, 개수: %i, 일정 ID: %i", _info.Skill.ClassName, _info.Func, _info.Src, _info.Line, _info.Callback, this.Count, this.ID), ::Reforged.DebugFlag.onAnySkillExecutedFully);
			else
				::Reforged.Mod.Debug.printLog(format("일정 완료 -- 클래스 이름: %s, 개수: %i, 일정 ID: %i -- 예정된 것이 없습니다. (일반 스킬)", _info.Skill.ClassName, this.Count, this.ID), ::Reforged.DebugFlag.onAnySkillExecutedFully);

			if (!::MSU.isNull(this.Container))
				this.Container.onAnySkillExecutedFully(_info.Skill, this.TargetTile, this.TargetEntity, this.ForFree);

			::MSU.Array.removeByValue(_info.Skill.m.RF_Schedules, this);
		}
	}

	function addCount( _num = 1 )
	{
		this.Count += _num;
		this.WasScheduled = true;
	}
};

// Looks through the stackinfos and returns the skill which called a scheduling function e.g. ::Time.scheduleEvent.
local function getSchedulerInfo()
{
	// 0 = "getstackinfos"; 1 = "getSchedulerInfo"; 2 = scheduler function e.g. ::Time.scheduleEvent which wants to know the skill that called it
	local level = 3;
	local infos = ::getstackinfos(level);

	do
	{
		// We skip native functions, this includes calls from .call or .acall etc.
		if (infos.src == "NATIVE")
		{
			infos = ::getstackinfos(++level);
			continue;
		}

		local caller = infos.locals["this"];

		// If some other mod hooks ::Time.scheduleEvent or ::TacticalNavigator.teleport or switchEntities
		// after our hook, then we want to go further up the chain to find the scheduler.
		if (caller == ::Time || caller instanceof ::TacticalNavigator)
		{
			infos = ::getstackinfos(++level);
			continue;
		}

		// if (::isKindOf(caller, "skill") && caller.m.RF_Schedule != null)
		// {
			// Technically we only need to return `caller` but we return the function name as well for debug logging
			return {
				Skill = caller,
				Func = infos.func,
				Src = infos.src,
				Line = infos.line
			};
		// }

		return null;
	}
	while(infos != null);

	return null;
}

// This is a stack. We push the last wrapped callback from a scheduled function here while it is being called
// and pop it afterward. This helps ensure that scheduling done from callbacks of scheduled events are added
// to their appropriate instance of the SkillSchedule.
::Reforged.LastCallback <- [];

// Returns a wrapped callback function for schedule functions e.g. ::Time.scheduleEvent. The callback
// is wrapped to trigger the onScheduleComplete() function for the schedule.
// Also increments the schedule Count of the relevant skill.
// Note: _countBump is necessary as a param because ::Tactical.switchEntities needs to increase
// count by 2 on every call as its callback is triggered twice: once for each entity being switched.
local function getWrapper( _info, _func, _numArgs, _type = "scheduleEvent", _countBump = 1 )
{
	local schedule;
	foreach (s in _info.Skill.m.RF_Schedules)
	{
		if (s.RegisteredCallbacks.find(::Reforged.LastCallback.top()) != null)
		{
			schedule = s;
			break;
		}
	}
	if (schedule == null)
	{
		schedule = _info.Skill.m.RF_Schedules.top();
	}
	schedule.addCount(_countBump);
	_info.Schedule <- schedule;

	if (_func != null)
		schedule.RegisteredCallbacks.push(_func);

	if (_numArgs == 1)
	{
		return function( _arg1 )
		{
			::Reforged.Mod.Debug.printLog(format("트리거링 %s 콜백 - 발신자: %s.%s (%s : %i), 콜백: %s, 일정 ID: %i", _type, "ClassName" in _info.Skill ? _info.Skill.ClassName : split(_info.Src, "/").top(), _info.Func, _info.Src, _info.Line, _info.Callback, _info.Schedule.ID), ::Reforged.DebugFlag.onAnySkillExecutedFully);
			if (_func != null)
			{
				::Reforged.LastCallback.push(_func);
				_func(_arg1);
				::Reforged.LastCallback.pop();
			}
			schedule.onScheduleComplete(_info);
		}
	}
	else
	{
		return function( _arg1, _arg2 )
		{
			::Reforged.Mod.Debug.printLog(format("트리거링 %s 콜백 - 발신자: %s.%s (%s : %i), 콜백: %s, 일정 ID: %i", _type, "ClassName" in _info.Skill ? _info.Skill.ClassName : split(_info.Src, "/").top(), _info.Func, _info.Src, _info.Line, _info.Callback, _info.Schedule.ID), ::Reforged.DebugFlag.onAnySkillExecutedFully);
			if (_func != null)
			{
				::Reforged.LastCallback.push(_func);
				_func(_arg1, _arg2);
				::Reforged.LastCallback.pop();
			}
			schedule.onScheduleComplete(_info);
		}
	}
}

// We hook the schedule functions in VeryLate bucket because our behavior is meant to be a wrapper
// on the entire scheduled function. Otherwise, our wrapper will trigger a schedule completion
// before the functionality from hooks on these functions from other mods has run.
::Reforged.QueueBucket.VeryLate.push(function() {
	// We overwrite the three functions `scheduleEvent`, `teleport` and `switchEntities` to add a custom callback function
	// that triggers the onScheduleComplete event inside ScheduledSkill class.
	local scheduleEvent = ::Time.scheduleEvent;
	::Time.scheduleEvent = { function scheduleEvent( _timeUnit, _time, _func, _data )
	{
		if (_timeUnit != ::TimeUnit.Virtual)
		{
			scheduleEvent(_timeUnit, _time, _func, _data);
			return;
		}

		local info = getSchedulerInfo();
		if (info == null)
		{
			scheduleEvent(_timeUnit, _time, _func, _data);
			return;
		}

		// This is just put in there for debug printing
		info.Callback <- _func == null ? "null" : (_func.getinfos().name == null ? "unknown" : _func.getinfos().name);

		if (!::isKindOf(info.Skill, "skill") || info.Skill.m.RF_Schedules.len() == 0)
		{
			::Reforged.Mod.Debug.printLog(format("기타 -- 발신자: %s.%s (%s : %i), 콜백: %s", "ClassName" in info.Skill ? info.Skill.ClassName : split(info.Src, "/").top(), info.Func, info.Src, info.Line, info.Callback), ::Reforged.DebugFlag.onAnySkillExecutedFully);
			local function wrapper( _arg )
			{
				::Reforged.Mod.Debug.printLog(format("OTHER -- ScheduleEvent 콜백 실행 - 호출자: %s.%s (%s : %i), 콜백: %s", "ClassName" in info.Skill ? info.Skill.ClassName : split(info.Src, "/").top(), info.Func, info.Src, info.Line, info.Callback), ::Reforged.DebugFlag.onAnySkillExecutedFully);
				if (_func != null)
				{
					_func(_arg);
				}
			}
			scheduleEvent(_timeUnit, _time, wrapper, _data);
			return;
		}

		scheduleEvent(_timeUnit, _time, getWrapper(info, _func, 1), _data);
		::Reforged.Mod.Debug.printLog(format("발신자: %s.%s (%s : %i), 콜백: %s, 개수: %i, 일정 ID: %i", info.Skill.ClassName, info.Func, info.Src, info.Line, info.Callback, info.Schedule.Count, info.Schedule.ID), ::Reforged.DebugFlag.onAnySkillExecutedFully);
	}}.scheduleEvent;

	local teleport_6 = ::TacticalNavigator["__sqrat_ol_ 순간이동_6"];
	::TacticalNavigator["__sqrat_ol_ 순간이동_6"] <- { function teleport( _user, _targetTile, _func, _data, _bool, _float )
	{
		local info = getSchedulerInfo();
		if (info == null)
		{
			teleport_6(_user, _targetTile, _func, _data, _bool, _float);
			return;
		}

		// This is just put in there for debug printing
		info.Callback <- _func == null ? "null" : (_func.getinfos().name == null ? "unknown" : _func.getinfos().name);

		if (::Tactical.getNavigator().IsTravelling || !_targetTile.IsEmpty)
		{
			if (::Reforged.Mod.Debug.isEnabled(::Reforged.DebugFlag.onAnySkillExecutedFully))
			{
				local prefix = !::isKindOf(info.Skill, "skill") || info.Skill.m.RF_Schedules.len() == 0 ? "기타 -- " : "";
				local reason = !_targetTile.IsEmpty ? "대상 타일이 비어 있지 않음" : "네비게이터는 이미 여행 중입니다";
				::Reforged.Mod.Debug.printWarning(format("%s일정이 잡혀있지 않아서 %s -- 발신자: %s.%s (%s : %i), 콜백: %s", prefix, reason, "ClassName" in info.Skill ? info.Skill.ClassName : split(info.Src, "/").top(), info.Func, info.Src, info.Line, info.Callback), ::Reforged.DebugFlag.onAnySkillExecutedFully);
			}
			teleport_6(_user, _targetTile, _func, _data, _bool, _float);
			return;
		}

		if (!::isKindOf(info.Skill, "skill") || info.Skill.m.RF_Schedules.len() == 0)
		{
			::Reforged.Mod.Debug.printLog(format("기타 -- 발신자: %s.%s (%s : %i), 콜백: %s", "ClassName" in info.Skill ? info.Skill.ClassName : split(info.Src, "/").top(), info.Func, info.Src, info.Line, info.Callback), ::Reforged.DebugFlag.onAnySkillExecutedFully);
			local function wrapper( _arg1, _arg2 )
			{
				::Reforged.Mod.Debug.printLog(format("기타 -- 텔레포트 콜백 실행 - 발신자: %s.%s (%s : %i), 콜백: %s", "ClassName" in info.Skill ? info.Skill.ClassName : split(info.Src, "/").top(), info.Func, info.Src, info.Line, info.Callback), ::Reforged.DebugFlag.onAnySkillExecutedFully);
				if (_func != null)
				{
					_func(_arg1, _arg2);
				}
			}
			teleport_6(_user, _targetTile, wrapper, _data, _bool, _float);
			return;
		}

		teleport_6(_user, _targetTile, getWrapper(info, _func, 2, "teleport"), _data, _bool, _float);
		::Reforged.Mod.Debug.printLog(format("발신자: %s.%s (%s : %i), 콜백: %s, 개수: %i, 일정 ID: %i", info.Skill.ClassName, info.Func, info.Src, info.Line, info.Callback, info.Schedule.Count, info.Schedule.ID), ::Reforged.DebugFlag.onAnySkillExecutedFully);
	}}.teleport;

	local teleport_5 = ::TacticalNavigator["__sqrat_ol_ 순간이동_5"];
	::TacticalNavigator["__sqrat_ol_ 순간이동_5"] <- { function teleport( _user, _targetTile, _func, _data, _bool )
	{
		local info = getSchedulerInfo();
		if (info == null)
		{
			teleport_5(_user, _targetTile, _func, _data, _bool);
			return;
		}

		// This is just put in there for debug printing
		info.Callback <- _func == null ? "null" : (_func.getinfos().name == null ? "unknown" : _func.getinfos().name);

		if (::Tactical.getNavigator().IsTravelling || !_targetTile.IsEmpty)
		{
			if (::Reforged.Mod.Debug.isEnabled(::Reforged.DebugFlag.onAnySkillExecutedFully))
			{
				local prefix = !::isKindOf(info.Skill, "skill") || info.Skill.m.RF_Schedules.len() == 0 ? "기타 -- " : "";
				local reason = !_targetTile.IsEmpty ? "대상 타일이 비어 있지 않음" : "네비게이터는 이미 여행 중입니다";
				::Reforged.Mod.Debug.printWarning(format("%s일정이 잡혀있지 않아서 %s -- 발신자: %s.%s (%s : %i), 콜백: %s", prefix, reason, "ClassName" in info.Skill ? info.Skill.ClassName : split(info.Src, "/").top(), info.Func, info.Src, info.Line, info.Callback), ::Reforged.DebugFlag.onAnySkillExecutedFully);
			}
			teleport_5(_user, _targetTile, _func, _data, _bool);
			return;
		}

		if (!::isKindOf(info.Skill, "skill") || info.Skill.m.RF_Schedules.len() == 0)
		{
			::Reforged.Mod.Debug.printLog(format("기타 -- 발신자: %s.%s (%s : %i), 콜백: %s", "ClassName" in info.Skill ? info.Skill.ClassName : split(info.Src, "/").top(), info.Func, info.Src, info.Line, info.Callback), ::Reforged.DebugFlag.onAnySkillExecutedFully);
			local function wrapper( _arg1, _arg2 )
			{
				::Reforged.Mod.Debug.printLog(format("기타 -- 텔레포트 콜백 실행 - 발신자: %s.%s (%s : %i), 콜백: %s", "ClassName" in info.Skill ? info.Skill.ClassName : split(info.Src, "/").top(), info.Func, info.Src, info.Line, info.Callback), ::Reforged.DebugFlag.onAnySkillExecutedFully);
				if (_func != null)
				{
					_func(_arg1, _arg2);
				}
			}
			teleport_5(_user, _targetTile, wrapper, _data, _bool);
			return;
		}

		teleport_5(_user, _targetTile, getWrapper(info, _func, 2, "teleport"), _data, _bool);
		::Reforged.Mod.Debug.printLog(format("발신자: %s.%s (%s : %i), 콜백: %s, 개수: %i, 일정 ID: %i", info.Skill.ClassName, info.Func, info.Src, info.Line, info.Callback, info.Schedule.Count, info.Schedule.ID), ::Reforged.DebugFlag.onAnySkillExecutedFully);
	}}.teleport;

	local switchEntities = ::TacticalNavigator.switchEntities;
	::TacticalNavigator.switchEntities <- { function switchEntities( _user, _targetEntity, _func, _data, _float )
	{
		local info = getSchedulerInfo();
		if (info == null)
		{
			switchEntities(_user, _targetEntity, _func, _data, _float);
			return;
		}

		// This is just put in there for debug printing
		info.Callback <- _func == null ? "null" : (_func.getinfos().name == null ? "unknown" : _func.getinfos().name);

		if (::Tactical.getNavigator().IsTravelling)
		{
			if (::Reforged.Mod.Debug.isEnabled(::Reforged.DebugFlag.onAnySkillExecutedFully))
			{
				local prefix = !::isKindOf(info.Skill, "skill") || info.Skill.m.RF_Schedules.len() == 0 ? "기타 -- " : "";
				::Reforged.Mod.Debug.printWarning(format("%s내비게이터가 이미 여행 중이어서 예약할 수 없음 -- 발신자: %s.%s (%s : %i), 콜백: %s", prefix, reason, "ClassName" in info.Skill ? info.Skill.ClassName : split(info.Src, "/").top(), info.Func, info.Src, info.Line, info.Callback), ::Reforged.DebugFlag.onAnySkillExecutedFully);
			}
			switchEntities(_user, _targetEntity, _func, _data, _float);
			return;
		}

		if (!::isKindOf(info.Skill, "skill") || info.Skill.m.RF_Schedules.len() == 0)
		{
			::Reforged.Mod.Debug.printLog(format("기타 -- 발신자: %s.%s (%s : %i), 콜백: %s", "ClassName" in info.Skill ? info.Skill.ClassName : split(info.Src, "/").top(), info.Func, info.Src, info.Line, info.Callback), ::Reforged.DebugFlag.onAnySkillExecutedFully);
			local function wrapper( _arg1, _arg2 )
			{
				::Reforged.Mod.Debug.printLog(format("OTHER -- switchEntities 콜백 트리거 - 발신자: %s.%s (%s : %i), 콜백: %s", "ClassName" in info.Skill ? info.Skill.ClassName : split(info.Src, "/").top(), info.Func, info.Src, info.Line, info.Callback), ::Reforged.DebugFlag.onAnySkillExecutedFully);
				if (_func != null)
				{
					_func(_arg1, _arg2);
				}
			}
			switchEntities(_user, _targetEntity, wrapper, _data, _float);
			return;
		}

		// Increase count by 2 because the callback is called for both entities
		local cbEntry = [getWrapper(info, _func, 2, "switchEntities", 2), _data];

		::Reforged.Mod.Debug.printLog(format("발신자: %s.%s (%s : %i), 콜백: %s, 개수: %i, 일정 ID: %i", info.Skill.ClassName, info.Func, info.Src, info.Line, info.Callback, info.Schedule.Count, info.Schedule.ID), ::Reforged.DebugFlag.onAnySkillExecutedFully);

		// Vanilla has a bug where switchEntities callbacks don't trigger when outside player vision
		// so we trigger them manually during actor.onMovementFinish instead and set the native callback to null
		_user.m.RF_switchEntitiesCallbacks.push(cbEntry);
		_targetEntity.m.RF_switchEntitiesCallbacks.push(cbEntry);

		switchEntities(_user, _targetEntity, null, null, _float);
	}}.switchEntities;
});


::Reforged.HooksMod.hook("scripts/skills/skill_container", function(q) {
	q.onAnySkillExecutedFully <- { function onAnySkillExecutedFully( _skill, _targetTile, _targetEntity, _forFree )
	{
		local actor = this.getActor();
		// Don't update if using a skill that sets Tile to ID 0 e.g. Rotation because this leads
		// to crashes if any skill tries to access the current tile in its onUpdate
		// function as the tile at this point is not a valid tile.

		this.callSkillsFunctionWhenAlive("onAnySkillExecutedFully", [
			_skill,
			_targetTile,
			_targetEntity,
			_forFree
		], actor.isPlacedOnMap());

		actor.setDirty(true);
	}}.onAnySkillExecutedFully;
});

::Reforged.HooksMod.hook("scripts/skills/skill", function(q) {
	q.m.RF_Schedules <- [];

	q.onAnySkillExecutedFully <- { function onAnySkillExecutedFully( _skill, _targetTile, _targetEntity, _forFree )
	{
	}}.onAnySkillExecutedFully;

	q.RF_isExecuting <- { function RF_isExecuting()
	{
		return this.m.RF_Schedules.len() != 0;
	}}.RF_isExecuting;

	q.use = @(__original) { function use( _targetTile, _forFree = false )
	{
		if (this.m.RF_Schedules.len() != 0)
		{
			::logWarning("Executing skill " + this.getID() + " while it already has an executing schedule.");
			::MSU.Log.printStackTrace();
		}
		local schedule = ::Reforged.SkillSchedule(this, _targetTile, _targetTile.IsOccupiedByActor ? _targetTile.getEntity() : null, _forFree);
		this.m.RF_Schedules.push(schedule);

		// Push anything here so that any scheduleEvent calls that happen during the `use` of this skill
		// are properly attributed to the new schedule instantiated above.
		::Reforged.LastCallback.push(this.use);

		// The original MSU events of onBeforeAnySkillExecuted and onAnySkilLExecuted will trigger here`
		local ret = __original(_targetTile, _forFree);

		::Reforged.LastCallback.pop();

		// If no delayed event was scheduled we trigger the onAnySkillExecutedFully manually
		// Note: We can't just check for .Count == 0 because in fog of war teleport/switchEntities
		// happens immediately without delay, so Count will be 0 here even if those happened and the
		// event would have already been properly handled leading to errors when calling it manually again.
		if (schedule != null && !schedule.WasScheduled)
		{
			schedule.onScheduleComplete({Skill = this});
		}

		return ret;
	}}.use;
});

local hasShownPopup = false;

// This is for debugging only - show a popup to the user to send us the log in cases where the skill schedule
// was not completed.
::Reforged.QueueBucket.VeryLate.push(function() {
	local funcs = [
		"onTurnStart",
		// "onTurnEnd" // Commented out because in vanilla next turn is force initialized when current entity dies even when events are scheduled. So, we don't show the error popup to prevent spam to user.
	];

	::Reforged.HooksMod.hookTree("scripts/skills/skill", function(q) {
		foreach (func in funcs)
		{
			q[func] = @(__original) function()
			{
				__original();
				if (this.m.RF_Schedules.len() != 0)
				{
					::logError("Schedules not finished for " + this.ClassName);
					if (!hasShownPopup)
					{
						hasShownPopup = true;
						::Reforged.Mod.Debug.addPopupMessage("게임 로그에는 중요한 디버깅 정보가 있습니다. 디버깅을 위해 개발자에게 log.html을 보내주세요. 파일은 Reforged Discord 서버에서 공유할 수 있습니다. log.html은 C:\\\\Users\\\\YourName\\\\Documents\\\\Battle Brothers\\\\log.html에 있습니다.", ::MSU.Popup.State.Full);
					}
				}
			}
		}
	});

	::Reforged.HooksMod.hook("scripts/entity/tactical/actor", function(q) {
		// Vanilla has a bug where switchEntities callbacks don't trigger when outside player vision
		// so we trigger them manually during onMovementFinish instead.
		// We use an array because one callback may trigger another and we to support a stack of those.
		q.m.RF_switchEntitiesCallbacks <- [];

		q.onMovementFinish = @(__original) { function onMovementFinish( _tile )
		{
			__original(_tile);
			// Call the switchEntities callbacks from last to first as expected.
			while (this.m.RF_switchEntitiesCallbacks.len() != 0)
			{
				local entry = this.m.RF_switchEntitiesCallbacks.pop();
				entry[0](this, entry[1]);
			}
		}}.onMovementFinish;
	});
});

::Reforged.HooksMod.hook("scripts/states/tactical_state", function(q) {
	q.RF_canExecuteSkill <- { function RF_canExecuteSkill()
	{
		return !::Time.hasEventScheduled(::TimeUnit.Virtual) && !::Tactical.getNavigator().IsTravelling;
	}}.RF_canExecuteSkill;

	q.executeEntitySkill = @(__original) { function executeEntitySkill( _activeEntity, _targetTile )
	{
		// Prevent executing a skill while the previously executed skill has not fully finished executing
		// including all its delayed effects
		if (!this.RF_canExecuteSkill())
		{
			::Tactical.EventLog.log(::MSU.Text.colorNegative("이미 스킬을 실행하고 있습니다!"));
			return;
		}

		__original(_activeEntity, _targetTile);
	}}.executeEntitySkill;
});

// TODO: Vanilla force initializes next turn upon death of current entity even if there are scheduled events.
// In an ideal world we should prevent this to have a complete and robust skill schedule system (vanilla also
// does not initialize next turn under normal circumstances if there are scheduled events). However, the current
// fix below causes cases where the game freezes when killing the current entity via riposte. At some point
// this should be again investigated and implemented.
// ::Reforged.QueueBucket.VeryLate.push(function() {
// 	::Reforged.HooksMod.hook("scripts/ui/screens/tactical/modules/turn_sequence_bar/turn_sequence_bar", function(q) {
// 		// We store the ID of the last active entity i.e. CurrentEntities[0] here during initNextTurn
// 		// when we prevent the force initialization of next turn. This is important because if the entity
// 		// died, then the ID may become bad i.e. 1936941420 by the time the next call to initNextTurn happens.
// 		q.m.RF_LastActiveEntityID <- 0;

// 		q.create = @(__original) { function create()
// 		{
// 			__original();

// 			local self = this;
// 			// Custom JSHandle to "fix" the last active entity id after we change `initNextTurn(true)` to false.
// 			// When the active entity dies, and we don't force initialize the next turn immediately, the entity's
// 			// getID() can return 1936941420. This causes the `removeEntity` call on the JS side to not be able to
// 			// remove the current entity causing the game to freeze. We fix this by storing the first entity's ID
// 			// in a member variable and changing the id being passed to the JS side to that stored id.
// 			this.m.__RF_JSHandle <- {
// 				__JSHandle = null,
// 				function __call( _async, _funcName, _args )
// 				{
// 					if (_funcName == "removeEntity" && self.m.RF_LastActiveEntityID != 0)
// 					{
// 						if (_args[0] == 1936941420) // all dead actors return this number from getID()
// 						{
// 							::Reforged.Mod.Debug.printWarning(format("Reforged: Sending last entity id as %i instead of the bad id %i", self.m.RF_LastActiveEntityID, _args[0]), ::Reforged.DebugFlag.onAnySkillExecutedFully);
// 							_args[0] = self.m.RF_LastActiveEntityID;
// 							// ::Reforged.Mod.Debug.addPopupMessage("Got an issue where active entity id had to be fixed. Check your log.", ::MSU.Popup.State.Full);
// 						}
// 						self.m.RF_LastActiveEntityID = 0;
// 					}

// 					switch (_args.len())
// 					{
// 						case 0:
// 							_async ? this.__JSHandle.asyncCall(_funcName) : this.__JSHandle.call(_funcName);
// 							break;
// 						case 1:
// 							_async ? this.__JSHandle.asyncCall(_funcName, _args[0]) : this.__JSHandle.call(_funcName, _args[0]);
// 							break;
// 						case 2:
// 							_async ? this.__JSHandle.asyncCall(_funcName, _args[0], _args[1]) : this.__JSHandle.call(_funcName, _args[0], _args[1]);
// 							break;
// 						case 3:
// 							_async ? this.__JSHandle.asyncCall(_funcName, _args[0], _args[1], _args[2]) : this.__JSHandle.call(_funcName, _args[0], _args[1], _args[2]);
// 							break;
// 						case 4:
// 							_async ? this.__JSHandle.asyncCall(_funcName, _args[0], _args[1], _args[2], _args[3]) : this.__JSHandle.call(_funcName, _args[0], _args[1], _args[2], _args[3]);
// 							break;
// 						default:
// 							_args.insert(0, _funcName);
// 							_args.insert(0, this);
// 							// For some reason this throws an error. No idea why, even though I've done it
// 							// similar to how MSU does it and there it doesn't error. - Midas.
// 							_async ? this.__JSHandle.asyncCall.acall(_args) : this.__JSHandle.call.acall(_args);
// 							break;
// 					}
// 				}

// 				function asyncCall( _funcName, ... )
// 				{
// 					this.__call(true, _funcName, vargv);
// 				}

// 				function call( _funcName, ... )
// 				{
// 					this.__call(false, _funcName, vargv);
// 				}
// 			}

// 			this.m.__RF_JSHandle.setdelegate({
// 				function _get( _key )
// 				{
// 					if (_key in this.__JSHandle)
// 						return this.__JSHandle[_key];
// 					throw null;
// 				}
// 			});
// 		}}.create;

// 		// Vanilla does not initialize next turn while TimeUnit.Virtual events are scheduled.
// 		// However, when the active entity is removed from the map (`turn_sequence_bar::removeEntity`),
// 		// vanilla passes `true` for the `_force` parameter here which initializes the next turn despite
// 		// having scheduled events. We must prevent vanilla from initializing the next turn while
// 		// TimeUnit.Virtual events are scheduled otherwise we get errors (e.g. in kraken_ensnare_skill)
// 		// where `onTurnEnd` triggers during the scheduled event. Similarly we get situations where
// 		// activeEntity is killed via Riposte and events are scheduled from the riposte attack,
// 		// but immediately the next turn starts.
// 		q.initNextTurn = @(__original) { function initNextTurn( _force = false )
// 		{
// 			if (_force && ::Time.hasEventScheduled(::TimeUnit.Virtual))
// 			{
// 				_force = false;
// 				this.m.RF_LastActiveEntityID = this.m.CurrentEntities[0].getID();
// 				local activeEntity = this.m.CurrentEntities[0];
// 				::Reforged.Mod.Debug.printWarning(format("Reforged: initNextTurn changing _force from true to false because of scheduled event. At this time CurrentEntities[0] is: -- typeof: %s, getID: %i, isAlive: %s, isDying: %s, isPlacedOnMap: %s, getName: %s", typeof activeEntity, activeEntity.getID(), activeEntity.isAlive() + "", activeEntity.isDying() + "", activeEntity.isPlacedOnMap() + "", activeEntity.getName() + ""), ::Reforged.DebugFlag.onAnySkillExecutedFully);
// 			}

// 			if (this.m.__RF_JSHandle.__JSHandle == null)
// 			{
// 				// If we haven't saved the original already, we save the most up-to-date original JSHandle
// 				// This prevents overwriting the JSHandle due to calls to `initNextTurn` before the first call ends.
// 				this.m.__RF_JSHandle.__JSHandle = this.m.JSHandle;
// 			}

// 			this.m.JSHandle = this.m.__RF_JSHandle;
// 			__original(_force);

// 			if (this.m.__RF_JSHandle.__JSHandle != null)
// 			{
// 				// If we still have the original JSHandle saved at this point, we restore it
// 				// These checks are necessary because another call of initNextTurn can happen
// 				// while the first call of initNextTurn has not completed yet.
// 				this.m.JSHandle = this.m.__RF_JSHandle.__JSHandle;
// 				this.m.__RF_JSHandle.__JSHandle = null;
// 			}
// 		}}.initNextTurn;
// 	});
// });
