::Reforged.HooksMod.hook("scripts/skills/effects/iron_will_effect", function(q) {
	q.getTooltip = @(__original) { function getTooltip()
	{
		local ret = __original();

		foreach (entry in ret)
		{
			if (entry.id == 11)
			{
				entry.text = ::Reforged.Mod.Tooltips.parseString("영향을 받지 않으며 받을 수 없습니다. [일시적 부상|Concept.InjuryTemporary]");
				break;
			}
		}

		return ret;
	}}.getTooltip;
});
