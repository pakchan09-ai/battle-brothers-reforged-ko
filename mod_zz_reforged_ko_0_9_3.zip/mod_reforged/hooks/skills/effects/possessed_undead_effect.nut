::Reforged.HooksMod.hook("scripts/skills/effects/possessed_undead_effect", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		this.m.Description = ::Reforged.Mod.Tooltips.parseString("이 캐릭터는 게임이 끝날 때까지 보유됩니다. [턴|Concept.Turn].")
	}}.create;

	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getTooltip();
		ret.extend([
			{
				id = 10,
				type = "text",
				icon = "ui/icons/action_points.png",
				text = ::Reforged.Mod.Tooltips.parseString("최대 [행동력|Concept.ActionPoints] 로 설정되어 있습니다 " + ::MSU.Text.colorPositive("12"))
			},
			{
				id = 11,
				type = "text",
				icon = "ui/icons/melee_skill.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorPositive("+15") + " [근접 공격|Concept.MeleeSkill]")
			},
			{
				id = 12,
				type = "text",
				icon = "ui/icons/melee_defense.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorPositive("+10") + " [근접 방어|Concept.MeleeDefense]")
			},
			{
				id = 13,
				type = "text",
				icon = "ui/icons/ranged_defense.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorPositive("+10") + " [원거리 방어|Concept.RangeDefense]")
			},
			{
				id = 15,
				type = "text",
				icon = "ui/icons/initiative.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorPositive("+50") + " [주도력|Concept.Initiative]")
			},
			{
				id = 16,
				type = "text",
				icon = "ui/icons/special.png",
				text = "받는 모든 피해는 다음과 같이 감소합니다. " + ::MSU.Text.colorNegative("25%")
			}
		]);
		return ret;
	}}.getTooltip;
});
