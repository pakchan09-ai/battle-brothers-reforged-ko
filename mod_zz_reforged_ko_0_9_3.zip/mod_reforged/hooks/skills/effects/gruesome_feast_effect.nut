::Reforged.HooksMod.hook("scripts/skills/effects/gruesome_feast_effect", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "시체를 포식한 이 몬스터는 더 크고 강력해졌습니다.";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getTooltip();

		local size = this.getContainer().getActor().getSize();
		if (size == 2)
		{
			ret.push({
				id = 10,
				type = "text",
				icon = "ui/icons/health.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorPositive("+120") + " [체력|Concept.Hitpoints]")
			});
			ret.push({
				id = 11,
				type = "text",
				icon = "ui/icons/melee_skill.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorPositive("+10") + " [근접 공격|Concept.MeleeSkill]")
			});
			ret.push({
				id = 12,
				type = "text",
				icon = "ui/icons/melee_defense.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorPositive("+5") + " [근접 방어|Concept.MeleeDefense]")
			});
			ret.push({
				id = 13,
				type = "text",
				icon = "ui/icons/ranged_defense.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorNegative("-5") + " [원거리 방어|Concept.RangeDefense]")
			});
			ret.push({
				id = 14,
				type = "text",
				icon = "ui/icons/bravery.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorPositive("+30") + " [의지|Concept.Bravery]")
			});
			ret.push({
				id = 15,
				type = "text",
				icon = "ui/icons/regular_damage.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorPositive("+15") + " 최소 피해")
			});
			ret.push({
				id = 16,
				type = "text",
				icon = "ui/icons/regular_damage.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorPositive("+20") + " 최대 데미지")
			});
			ret.push({
				id = 17,
				type = "text",
				icon = "ui/icons/initiative.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorNegative("-15") + " [주도력|Concept.Initiative]")
			});
		}
		else if (size == 3)
		{
			ret.push({
				id = 10,
				type = "text",
				icon = "ui/icons/health.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorPositive("+300") + " [체력|Concept.Hitpoints]")
			});
			ret.push({
				id = 11,
				type = "text",
				icon = "ui/icons/melee_skill.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorPositive("+20") + " [근접 공격|Concept.MeleeSkill]")
			});
			ret.push({
				id = 12,
				type = "text",
				icon = "ui/icons/melee_defense.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorPositive("+10") + " [근접 방어|Concept.MeleeDefense]")
			});
			ret.push({
				id = 13,
				type = "text",
				icon = "ui/icons/ranged_defense.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorNegative("-10") + " [원거리 방어|Concept.RangeDefense]")
			});
			ret.push({
				id = 14,
				type = "text",
				icon = "ui/icons/bravery.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorPositive("+60") + " [의지|Concept.Bravery]")
			});
			ret.push({
				id = 15,
				type = "text",
				icon = "ui/icons/regular_damage.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorPositive("+30") + " 최소 피해")
			});
			ret.push({
				id = 16,
				type = "text",
				icon = "ui/icons/regular_damage.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorPositive("+40") + " 최대 데미지")
			});
			ret.push({
				id = 17,
				type = "text",
				icon = "ui/icons/initiative.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorNegative("-30") + " [주도력|Concept.Initiative]")
			});
		}

		return ret;
	}}.getTooltip;
});
