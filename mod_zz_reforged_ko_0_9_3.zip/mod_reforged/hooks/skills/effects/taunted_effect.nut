::Reforged.HooksMod.hook("scripts/skills/effects/taunted_effect", function(q) {
	q.m.DefenseModifier <- 0;

	q.create = @(__original) { function create()
	{
		__original();
		this.m.Description = "이 캐릭터는 다른 캐릭터에 의해 조롱당하고 교전하고 공격할 가능성이 훨씬 더 높습니다.";
	}}.create;

	q.isHidden = @() { function isHidden()
	{
		return ::MSU.isNull(this.getTauntSource());
	}}.isHidden;

	q.getTooltip = @(__original) { function getTooltip()
	{
		local ret = __original();

		if (::MSU.isEqual(this.getContainer().getActor(), ::MSU.getDummyPlayer()))
		{
			local resolveFraction = ::new("scripts/skills/actives/taunt").m.DefenseModifierFraction;
			if (resolveFraction != 0)
			{
				ret.push({
					id = 10,
					type = "text",
					icon = "ui/icons/melee_defense.png",
					text = ::Reforged.Mod.Tooltips.parseString("[근접|Concept.MeleeDefense] 그리고 [원거리|Concept.RangeDefense] 방어력이 감소합니다. " + ::MSU.Text.colorizePct(resolveFraction) + " ~의 [$ $|Skill+taunt] [의지|Concept.Bravery]")
				});
			}
		}
		else
		{
			if (!::MSU.isNull(this.getTauntSource()))
			{
				ret.push({
					id = 9,
					type = "text",
					icon = "ui/icons/special.png",
					text = "이 캐릭터는 조롱당했습니다. " + ::MSU.Text.colorNegative(this.getTauntSource().getName())
				});
				if (this.getMeleeDefenseModifier() != 0)
				{
					ret.push({
						id = 10,
						type = "text",
						icon = "ui/icons/melee_defense.png",
						text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorizeValue(this.getMeleeDefenseModifier(), {AddSign = true}) + " [근접 방어|Concept.MeleeDefense]")
					});
				}
				if (this.getRangedDefenseModifier() != 0)
				{
					ret.push({
						id = 11,
						type = "text",
						icon = "ui/icons/ranged_defense.png",
						text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorizeValue(this.getRangedDefenseModifier(), {AddSign = true}) + " [원거리 방어|Concept.RangeDefense]")
					});
				}
			}
		}

		return ret;
	}}.getTooltip;

	q.onUpdate = @(__original) { function onUpdate( _properties )
	{
		__original(_properties);

		if (this.getTauntSource() != null)
		{
			_properties.MeleeDefense += this.getMeleeDefenseModifier();
			_properties.RangedDefense += this.getRangedDefenseModifier();
		}
	}}.onUpdate;

// New Functions
	q.getTauntSource <- { function getTauntSource()
	{
		local ret = this.getContainer().getActor().getAIAgent().getForcedOpponent();
		return !::MSU.isNull(ret) && ret.isAlive() ? ret : null;
	}}.getTauntSource;

	q.getMeleeDefenseModifier <- { function getMeleeDefenseModifier()
	{
		return this.m.DefenseModifier;
	}}.getMeleeDefenseModifier;

	q.getRangedDefenseModifier <- { function getRangedDefenseModifier()
	{
		return this.m.DefenseModifier;
	}}.getRangedDefenseModifier;
});
