::Reforged.HooksMod.hook("scripts/skills/effects/spearwall_effect", function(q) {
	q.getTooltip = @(__original) { function getTooltip()
	{
		local ret = __original();

		local crowded = this.getContainer().getSkillByID("special.rf_polearm_adjacency");
		if (crowded != null)
		{
			ret.push({
				id = 10,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString(format("공격은 피해를 입지 않습니다. %s 당신의 것이 아닐 때 [턴|Concept.Turn]", ::Reforged.NestedTooltips.getNestedSkillName(crowded)))
			});
		}

		return ret;
	}}.getTooltip;

	q.onUpdate = @(__original) { function onUpdate( _properties )
	{
		__original(_properties);
		if (::Tactical.isActive() && !::Tactical.TurnSequenceBar.isActiveEntity(this.getContainer().getActor()))
		{
			local crowded = this.getContainer().getSkillByID("special.rf_polearm_adjacency");
			if (crowded != null)
			{
				crowded.m.NumEnemiesToIgnore = 99;
				crowded.m.NumAlliesToIgnore = 99;
			}
		}
	}}.onUpdate;
});
