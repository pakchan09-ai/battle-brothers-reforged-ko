::Reforged.HooksMod.hook("scripts/skills/effects/swallowed_whole_effect", function(q) {
	q.m.TargetName <- "";

	q.create = @(__original) { function create()
	{
		__original();
		this.m.Name = "배 가득";	 // New more descriptive Name
		this.m.Description = "이 캐릭터가 다른 캐릭터를 삼켰습니다. 그들을 풀어줄 유일한 방법은 이 캐릭터를 죽이고 배를 자르는 것입니다.";
	}}.create;

	// The vanilla function overwrites the original 'this.m.Name' which we don't want. Instead we save that name in a separate variable
	q.setName = @() { function setName( _name )
	{
		this.m.TargetName = _name;
	}}.setName;

	// Overwrite to change vanilla formatting slightly
	q.getName = @() { function getName()
	{
		return this.m.Name + " (" + this.m.TargetName + ")";
	}}.getName;
});
