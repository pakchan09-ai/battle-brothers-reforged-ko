::Reforged.HooksMod.hook("scripts/skills/effects/drums_of_war_effect", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "이 캐릭터는 동료들의 전쟁 북의 격렬한 리듬 덕분에 더욱 활력이 넘치는 느낌을 줍니다."
		// In vanilla it is hidden but we reveal it because we have custom description and tooltip for it.
		this.m.IsHidden = false;
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @(__original) { function getTooltip()
	{
		local ret = __original();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/fatigue.png",
			text = ::Reforged.Mod.Tooltips.parseString("내장 [피로|Concept.Fatigue] 에 의해 감소된다 " + ::MSU.Text.colorPositive("15") + " 이 효과를 받았을 때")
		});
		ret.push({
			id = 20,
			type = "text",
			icon = "ui/icons/warning.png",
			text = ::Reforged.Mod.Tooltips.parseString("이 효과는 1회 이상 받을 수 없습니다. [턴|Concept.Turn]")
		});

		return ret;
	}}.getTooltip;
});
