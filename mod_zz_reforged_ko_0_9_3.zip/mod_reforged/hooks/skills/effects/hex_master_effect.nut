::Reforged.HooksMod.hook("scripts/skills/effects/hex_master_effect", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "이 캐릭터는 피해자가 이 캐릭터에게 가해지는 모든 고통을 겪도록 저주했습니다. 이는 적대적인 의도를 가진 사람들에 대한 강력한 억제력입니다.";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getTooltip();

		if (!::MSU.isNull(this.m.Slave) && !::MSU.isNull(this.m.Slave.getContainer()))
		{
			local victim = this.m.Slave.getContainer().getActor();
			if (this.m.Slave.isAlive())
			{
				ret.push({
					id = 10,
					type = "text",
					icon = ::Reforged.Mod.Tooltips.parseString(::Reforged.NestedTooltips.getNestedEntityImage(victim)),
					text = "Victim: " + ::Reforged.Mod.Tooltips.parseString(::Reforged.NestedTooltips.getNestedEntityName(victim)),
				});
			}
		}

		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("모든 수신 [체력|Concept.Hitpoints] 피해는 피해자에게도 전액 가해진다.")
		});
		ret.push({
			id = 20,
			type = "text",
			icon = "ui/icons/warning.png",
			text = ::Reforged.Mod.Tooltips.parseString("만료일: " + ::MSU.Text.colorNegative(this.m.TurnsLeft) + " [턴|Concept.Turn]")
		});

		return ret;
	}}.getTooltip;
});
