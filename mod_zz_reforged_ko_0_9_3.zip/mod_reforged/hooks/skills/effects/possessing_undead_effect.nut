::Reforged.HooksMod.hook("scripts/skills/effects/possessing_undead_effect", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "이 캐릭터는 이상하게도 위더갱어를 직접 조종하게 되었습니다.";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getTooltip();

		if (!::MSU.isNull(this.m.Possessed) && this.m.Possessed.isAlive())
		{
			ret.push({
				id = 10,
				type = "text",
				icon = ::Reforged.Mod.Tooltips.parseString(::Reforged.NestedTooltips.getNestedEntityImage(this.m.Possessed)),
				text = "소유 " + ::Reforged.Mod.Tooltips.parseString(::Reforged.NestedTooltips.getNestedEntityName(this.m.Possessed)),
			});
		}

		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/warning.png",
			text = ::Reforged.Mod.Tooltips.parseString("수신 시 손실됩니다. " + ::MSU.Text.colorDamage(::Const.Combat.InjuryMinDamage) + " 손상 [체력|Concept.Hitpoints] 또는 빙의된 캐릭터가 사망한 경우")
		});

		return ret;
	}}.getTooltip;
});
