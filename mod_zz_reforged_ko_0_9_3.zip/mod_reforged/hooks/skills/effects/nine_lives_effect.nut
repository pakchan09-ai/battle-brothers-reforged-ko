::Reforged.HooksMod.hook("scripts/skills/effects/nine_lives_effect", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// We change the name of this effect so you don't confuse it with the perk 'Nine Lives' which now also displays under StatusEffects
		this.m.Name = "강화된 반사 신경(나인 라이브)";
		this.m.Icon = "skills/rf_nine_lives_effect.png";
		this.m.IconMini = "rf_nine_lives_effect_mini";
	}}.create;
});
