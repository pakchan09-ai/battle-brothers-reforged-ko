::Reforged.HooksMod.hook("scripts/skills/effects/berserker_rage_effect", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		this.m.Description = "이 캐릭터는 광포한 분노를 느끼고 있습니다."
	}}.create;

	q.getDescription = @(__original) { function getDescription()	// Vanilla overwrote this returning "TODO" so we need to fix that
	{
		return this.skill.getDescription();
	}}.getDescription;

	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getTooltip();
		ret.extend([
			{
				id = 10,
				type = "text",
				icon = "ui/icons/special.png",
				text = "받는 모든 피해는 다음과 같이 감소합니다. " + ::MSU.Text.colorNegative((100.0 - (this.calcDamageTakenMult() * 100.0)) + "%")
			},
			{
				id = 11,
				type = "text",
				icon = "ui/icons/regular_damage.png",
				text = ::MSU.Text.colorPositive("+" + this.m.RageStacks) + " Damage"
			},
			{
				id = 12,
				type = "text",
				icon = "ui/icons/bravery.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorPositive("+" + this.m.RageStacks) + " [의지|Concept.Bravery]")
			},
			{
				id = 13,
				type = "text",
				icon = "ui/icons/initiative.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorPositive("+" + this.m.RageStacks) + " [주도력|Concept.Initiative]")
			}
		]);
		return ret;
	}}.getTooltip;

	// New function replicating the current hard-coded vanilla calculation. Changing this will currently only affect the tooltip
	q.calcDamageTakenMult <- { function calcDamageTakenMult()
	{
		return ::Math.maxf(0.3, 1.0 - 0.02 * this.m.RageStacks);
	}}.calcDamageTakenMult;
});
