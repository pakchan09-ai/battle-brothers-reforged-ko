::Reforged.HooksMod.hook("scripts/skills/effects/fake_charmed_effect", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// We change the name from vanilla "Charmed" to differentiate it from the real "Charmed" effect that players get
		this.m.Name = "매료되다";
		// Vanilla is missing a description for this skill
		this.m.Description = "이 캐릭터는 매료되었습니다. 그들은 더 이상 자신의 행동을 통제할 수 없으며 주인에게 복종할 수밖에 없는 꼭두각시가 됩니다.";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/bravery.png",
			text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorPositive("+20") + " [의지|Concept.Bravery]")
		});
		return ret;
	}}.getTooltip;
});
