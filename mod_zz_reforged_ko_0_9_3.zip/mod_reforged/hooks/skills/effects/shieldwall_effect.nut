::Reforged.HooksMod.hook("scripts/skills/effects/shieldwall_effect", function(q) {
	// Part of perk_rf_shield_sergeant functionality
	q.onTurnStart = @(__original) { function onTurnStart()
	{
		__original();

		local actor = this.getContainer().getActor();
		local hasPerk = this.getContainer().hasSkill("perk.rf_shield_sergeant");

		foreach (ally in ::Tactical.Entities.getFactionActors(actor.getFaction(), actor.getTile(), 1, true))
		{
			if (::Math.abs(ally.getTile().Level - actor.getTile().Level) <= 1 && ally.getSkills().hasSkill("actives.shieldwall") && (hasPerk || ally.getSkills().hasSkill("perk.rf_shield_sergeant")))
			{
				this.m.IsGarbage = false;
				if (!actor.isHiddenToPlayer())
				{
					::Tactical.EventLog.log(::Const.UI.getColorizedEntityName(actor) + " 다음으로 인해 Shieldwall을 유지합니다. " + ::Const.UI.getColorizedEntityName(hasPerk ? actor : ally) + "방패 상사 특전");
				}
				return;
			}
		}
	}}.onTurnStart;
});
