::Reforged.HooksMod.hook("scripts/skills/racial/golem_racial", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		this.m.Name = "골렘";
		this.m.Icon = "ui/orientation/sand_golem_orientation.png";
		this.m.IsHidden = false;
		this.addType(::Const.SkillType.StatusEffect);	// We now want this effect to show up on the enemies
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getTooltip();
		ret.extend([
			{
				id = 10,
				type = "text",
				icon = "ui/icons/melee_defense.png",
				text = ::MSU.Text.colorNegative("50%") + " 받는 근접 관통 피해가 감소했습니다."
			},
			{
				id = 11,
				type = "text",
				icon = "ui/icons/ranged_defense.png",
				text = ::MSU.Text.colorNegative("66%") + " 원거리 관통 및 원거리 둔기 피해가 감소했습니다."
			},
			{
				id = 12,
				type = "text",
				icon = "ui/icons/campfire.png",
				text = ::MSU.Text.colorNegative("90%") + " 받는 화염 피해 감소"
			},
			{
				id = 21,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("영향을 받지 않으며 받을 수 없습니다. [일시적 부상|Concept.InjuryTemporary]")
			},
			{
				id = 22,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("면역 [$ $|Skill+bleeding_effect]")
			},
			{
				id = 23,
				type = "text",
				icon = "ui/icons/special.png",
				text = "독에 면역"
			},
			{
				id = 24,
				type = "text",
				icon = "ui/icons/special.png",
				text = "밀쳐지거나 붙잡히는 것에 면역"
			},
			{
				id = 25,
				type = "text",
				icon = "ui/icons/special.png",
				text = "불에 면역"
			},
			{
				id = 26,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("존재에 면역 [$ $|Skill+disarmed_effect]")
			},
			{
				id = 27,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("존재에 면역 [$ $|Skill+stunned_effect]")
			},
			{
				id = 28,
				type = "text",
				icon = "ui/icons/morale.png",
				text = ::Reforged.Mod.Tooltips.parseString("영향을 받지 않음 [사기|Concept.Morale]")
			},
			{
				id = 29,
				type = "text",
				icon = "ui/icons/special.png",
				text = "머리에 맞은 타격을 받을 수 없음"
			}
		]);
		return ret;
	}}.getTooltip;

	q.onAdded = @() { function onAdded()
	{
		local actor = this.getContainer().getActor();
		actor.m.MoraleState = ::Const.MoraleState.Ignore;

		local baseProperties = actor.getBaseProperties();
		baseProperties.IsAffectedByInjuries = false;
		baseProperties.IsAffectedByNight = false;
		baseProperties.IsImmuneToBleeding = true;
		baseProperties.IsImmuneToDisarm = true;
		baseProperties.IsImmuneToFire = true;
		baseProperties.IsImmuneToHeadshots = true;
		baseProperties.IsImmuneToPoison = true;
		baseProperties.IsImmuneToStun = true;
	}}.onAdded;

	q.onBeforeDamageReceived = @() { function onBeforeDamageReceived( _attacker, _skill, _hitInfo, _properties )
	{
		if (_skill != null && _skill.getID() == "actives.throw_golem")
		{
			_properties.DamageReceivedTotalMult = 0.0;
			return;
		}

		switch (_hitInfo.DamageType)
		{
			case null:
				break;

			case ::Const.Damage.DamageType.Burning:
				_properties.DamageReceivedRegularMult *= 0.1;
				break;

			case ::Const.Damage.DamageType.Blunt:
				if (_skill != null)
				{
					if (_skill.isRanged())	// In Vanilla this reduction only exists for slinging of stones. Here it expands to bolas and potential future blunt ranged attacks
					{
						_properties.DamageReceivedRegularMult *= 0.33;
					}
				}
				break;

			case ::Const.Damage.DamageType.Piercing:
				if (_skill == null)
				{
					_properties.DamageReceivedRegularMult *= 0.5;
				}
				else
				{
					if (_skill.isRanged())
					{
						_properties.DamageReceivedRegularMult *= 0.33;
						/* This streamlines the following differences in vanilla:
							Arrows dealing only 10% damage
							javelins and handgonne dealing only 25% damage
							one-use throwing spear dealing 100% damage
						*/
					}
					else
					{
						_properties.DamageReceivedRegularMult *= 0.5;
					}
				}
				break;
		}
	}}.onBeforeDamageReceived;
});
