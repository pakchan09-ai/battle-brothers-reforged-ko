::Reforged.HooksMod.hook("scripts/skills/racial/flesh_golem_racial", function(q) {
	q.m.InjuryThresholdMult <- 0.7;
	q.m.MovementAPCostModifier <- 2;

	q.create = @(__original) { function create()
	{
		__original();
		this.m.Name = "육체 골렘";
		this.m.Icon = "ui/orientation/flesh_golem_orientation.png";
		this.m.IsHidden = false;
		if (this.isType(::Const.SkillType.Perk))
			this.removeType(::Const.SkillType.Perk);	// This effect having the type 'Perk' serves no purpose and only causes issues in modding
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getTooltip();
		ret.extend([
			{
				id = 10,
				type = "text",
				icon = "ui/icons/asset_medicine.png",	// This is not an ideal icon but more unique than special, and at least closely related
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorizeMultWithText(this.m.InjuryThresholdMult) + " [부상 한계치|Concept.InjuryThreshold]")
			},
			{
				id = 11,
				type = "text",
				icon = "ui/icons/action_points.png",
				text = "이사 비용 " + ::MSU.Text.colorizeValue(this.m.MovementAPCostModifier, {AddSign = true, InvertColor = true}) + ::Reforged.Mod.Tooltips.parseString(" [행동력|Concept.ActionPoints] 타일당")
			}
		]);
		return ret;
	}}.getTooltip;

	// Overwrite vanilla function to use our member variables to apply the changes
	q.onUpdate = @() { function onUpdate( _properties )
	{
		_properties.ThresholdToReceiveInjuryMult *= this.m.InjuryThresholdMult;
		_properties.MovementAPCostAdditional += this.m.MovementAPCostModifier;
	}}.onUpdate;
});
