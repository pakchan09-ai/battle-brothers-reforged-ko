::Reforged.HooksMod.hook("scripts/skills/racial/lindwurm_racial", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		this.m.Name = "린드부름";
		this.m.Description = "";	// Vanilla has "TODO" written here. We don't want that to display
		this.m.Icon = "ui/orientation/lindwurm_orientation.png";
		this.m.IsHidden = false;
		this.addType(::Const.SkillType.StatusEffect);	// We now want this effect to show up on the enemies
		if (this.isType(::Const.SkillType.Perk))
			this.removeType(::Const.SkillType.Perk);	// This effect having the type 'Perk' serves no purpose and only causes issues in modding
	}}.create;

	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getTooltip();
		ret.extend([
			{
				id = 10,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("인접한 적으로부터 최소한의 피해를 입힌 경우 " + ::MSU.Text.colorPositive("11") + " 손상 [체력|Concept.Hitpoints], 신청하다 [$ $|Skill+lindwurm_acid_effect] 그들에게")
			},
			{
				id = 20,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("영향을 받지 않음 [$ $|Skill+night_effect]")
			},
			{
				id = 24,
				type = "text",
				icon = "ui/icons/special.png",
				text = "밀쳐지거나 붙잡히는 것에 면역"
			},
			{
				id = 26,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("존재에 면역 [$ $|Skill+disarmed_effect]")
			},
			{
				id = 27,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("존재에 면역 [속박|Concept.Rooted]")
			}
			{
				id = 28,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("존재에 면역 [$ $|Skill+stunned_effect]")
			}
		]);
		return ret;
	}}.getTooltip;

	q.onAdded = @() { function onAdded()
	{
		local baseProperties = this.getContainer().getActor().getBaseProperties();

		baseProperties.IsAffectedByNight = false;
		baseProperties.IsImmuneToDisarm = true;
		baseProperties.IsImmuneToKnockBackAndGrab = true;
		baseProperties.IsImmuneToStun = true;
		baseProperties.IsImmuneToRoot = true;
	}}.onAdded;
});
