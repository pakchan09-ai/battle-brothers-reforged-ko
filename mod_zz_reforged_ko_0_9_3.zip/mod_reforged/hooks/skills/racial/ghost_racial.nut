::Reforged.HooksMod.hook("scripts/skills/racial/ghost_racial", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		this.m.Name = "유령";
		this.m.Icon = "ui/orientation/ghost_01_orientation.png";
		this.m.IsHidden = false;
		if (this.isType(::Const.SkillType.Perk))
			this.removeType(::Const.SkillType.Perk);	// This effect having the type 'Perk' serves no purpose and only causes issues in modding
	}}.create;

	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getTooltip();
		ret.extend([
			{
				id = 10,
				type = "text",
				icon = "ui/icons/melee_defense.png",
				text = ::Reforged.Mod.Tooltips.parseString("공격당하면 이득을 얻습니다. " + ::MSU.Text.colorPositive("+10") + " [근접 방어|Concept.MeleeDefense] 그리고 [원거리 방어|Concept.RangeDefense] 당신과 공격자 사이의 각 타일마다")
			},
			{
				id = 20,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("영향을 받지 않음 [$ $|Skill+night_effect]")
			},
			{
				id = 21,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("영향을 받지 않으며 받을 수 없습니다. [일시적 부상|Concept.InjuryTemporary]")
			},
			{
				id = 22,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("면역 [$ $|Skill+bleeding_effect]")
			},
			{
				id = 23,
				type = "text",
				icon = "ui/icons/special.png",
				text = "독에 면역"
			},
			{
				id = 24,
				type = "text",
				icon = "ui/icons/special.png",
				text = "밀쳐지거나 붙잡히는 것에 면역"
			},
			{
				id = 25,
				type = "text",
				icon = "ui/icons/special.png",
				text = "불에 면역"
			},
			{
				id = 26,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("존재에 면역 [$ $|Skill+disarmed_effect]")
			},

			{
				id = 27,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("존재에 면역 [속박|Concept.Rooted]")
			},
			{
				id = 28,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("존재에 면역 [$ $|Skill+stunned_effect]")
			},
			{
				id = 29,
				type = "text",
				icon = "ui/icons/morale.png",
				text = ::Reforged.Mod.Tooltips.parseString("영향을 받지 않음 [사기|Concept.Morale]")
			}
		]);
		return ret;
	}}.getTooltip;

	q.onAdded = @() { function onAdded()
	{
		local actor = this.getContainer().getActor();
		actor.m.MoraleState = ::Const.MoraleState.Ignore;

		local baseProperties = actor.getBaseProperties();
		baseProperties.IsAffectedByInjuries = false;
		baseProperties.IsAffectedByNight = false;
		baseProperties.IsImmuneToBleeding = true;
		baseProperties.IsImmuneToDisarm = true;
		baseProperties.IsImmuneToFire = true;
		baseProperties.IsImmuneToKnockBackAndGrab = true;
		baseProperties.IsImmuneToPoison = true;
		baseProperties.IsImmuneToRoot = true;
		baseProperties.IsImmuneToStun = true;

		// This is purely a setting for AI decisions:
		baseProperties.IsIgnoringArmorOnAttack = true;
	}}.onAdded;
});
