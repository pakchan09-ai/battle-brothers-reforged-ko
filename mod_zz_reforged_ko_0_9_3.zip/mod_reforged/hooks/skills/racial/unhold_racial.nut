::Reforged.HooksMod.hook("scripts/skills/racial/unhold_racial", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		this.m.Name = "보류 해제";
		this.m.Icon = "ui/orientation/unhold_01_orientation.png";
		this.m.IsHidden = false;
		this.addType(::Const.SkillType.StatusEffect);	// We now want this effect to show up on the enemies
	}}.create;

	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/health.png",
			text = ::Reforged.Mod.Tooltips.parseString("각각의 시작에는 [턴|Concept.Turn], 이 캐릭터는 다음과 같은 방법으로 치유됩니다. " + ::MSU.Text.colorPositive("15%") + " 최대 [체력|Concept.Hitpoints]")
		});

		// This is about the vanila behavior coded in this skill's `onUpdate` function.
		// We show it here in the absence of a better UI that shows turn order initiative in addition to regular initiative.
		local actor = this.getContainer().getActor();
		if (::MSU.isKindOf(actor, "unhold_armored") || ::MSU.isKindOf(actor, "unhold_frost_armored") || ::MSU.isEqual(actor, ::MSU.getDummyPlayer()))
		{
			local roundsForInitiativeBonus = ::Tactical.isActive() ? (::Tactical.State.isScenarioMode() ? 3 : 2) : "few";
			ret.push({
				id = 11,
				type = "text",
				icon = "ui/icons/initiative.png",
				text = ::Reforged.Mod.Tooltips.parseString("[턴|Concept.Turn] 순서는 다음과 같이 결정됩니다. " + ::MSU.Text.colorPositive("+40") + " [주도력|Concept.Initiative] 첫 번째 동안 " + roundsForInitiativeBonus + " [라운드|Concept.Round]")
			});
		}

		ret.push({
			id = 20,
			type = "text",
			icon = "ui/icons/special.png",
			text = "무장 해제에 면역"
		})
		ret.push({
			id = 21,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("존재에 면역 [$ $|Skill+rotation]")
		});

		return ret;
	}}.getTooltip;

	q.onAdded = @() { function onAdded()
	{
		local actor = this.getContainer().getActor();
		local baseProperties = actor.getBaseProperties();

		baseProperties.IsImmuneToDisarm = true;
		baseProperties.IsImmuneToRotation = true;

		if (::MSU.isKindOf(actor, "unhold_armored") || ::MSU.isKindOf(actor, "unhold_frost_armored"))
		{
			this.m.Name = "기갑 " + this.m.Name;
		}
	}}.onAdded;

	q.onTurnStart = @(__original) { function onTurnStart()
	{
		__original();
		local bleed = this.getContainer().getSkillByID("effects.bleeding");
		if (bleed != null)
		{
			bleed.m.Stacks /= 2;
			if (bleed.m.Stacks == 0)
				bleed.removeSelf();
			::Tactical.EventLog.log(::Const.UI.getColorizedEntityName(this.getContainer().getActor()) + " 그의 출혈 상처 중 일부가 가까이에 있었어");
		}
	}}.onTurnStart;
});
