::Reforged.HooksMod.hook("scripts/skills/racial/spider_racial", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		this.m.Name = "거미";
		this.m.Description = "";	// Vanilla has "TODO" written here. We don't want that to display
		this.m.Icon = "ui/orientation/spider_01_orientation.png";
		this.m.IsHidden = false;
		this.addType(::Const.SkillType.StatusEffect);	// We now want this effect to show up on the enemies
		if (this.isType(::Const.SkillType.Perk))
			this.removeType(::Const.SkillType.Perk);	// This effect having the type 'Perk' serves no purpose and only causes issues in modding
	}}.create;

	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getTooltip();
		ret.extend([
			{
				id = 10,
				type = "text",
				icon = "ui/icons/bravery.png",
				text = ::Reforged.Mod.Tooltips.parseString("[의지|Concept.Bravery] 에 의해 증가된다 " + ::MSU.Text.colorPositive("+3") + " 같은 진영의 전장에 있는 다른 모든 동맹국에 대해")
			},
			{
				id = 11,
				type = "text",
				icon = "ui/icons/direct_damage.png",
				text = ::Reforged.Mod.Tooltips.parseString("공격할 때 [$ $|Skill+web_effect] 대상의 방어력을 무시하는 데미지가 증가합니다. " + ::MSU.Text.colorPositive("100%"))
			},
			{
				id = 20,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("영향을 받지 않음 [$ $|Skill+night_effect]")
			},
			{
				id = 21,
				type = "text",
				icon = "ui/icons/special.png",
				text = "독에 면역"
			},
			{
				id = 23,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("존재에 면역 [$ $|Skill+disarmed_effect]")
			}
		]);
		return ret;
	}}.getTooltip;

	q.onAdded = @() { function onAdded()
	{
		local baseProperties = this.getContainer().getActor().getBaseProperties();

		baseProperties.IsAffectedByNight = false;
		baseProperties.IsImmuneToDisarm = true;
		baseProperties.IsImmuneToPoison = true;
	}}.onAdded;
});
