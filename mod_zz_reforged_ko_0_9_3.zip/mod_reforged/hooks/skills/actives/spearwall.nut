::Reforged.HooksMod.hook("scripts/skills/actives/spearwall", function(q) {
	q.getTooltip = @(__original) { function getTooltip()
	{
		local ret = __original();

		local crowded = this.getContainer().getSkillByID("special.rf_polearm_adjacency");
		if (crowded != null)
		{
			ret.push({
				id = 10,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString(format("공격은 피해를 입지 않습니다. %s 당신의 것이 아닐 때 [턴|Concept.Turn]", ::Reforged.NestedTooltips.getNestedSkillName(crowded)))
			});
		}

		return ret;
	}}.getTooltip;
});
