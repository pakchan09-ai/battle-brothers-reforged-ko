::Reforged.HooksMod.hook("scripts/skills/actives/sweep_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "주먹을 크게 휘두르며 시계 반대 방향으로 최대 3명의 인접한 캐릭터를 공격합니다!";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("까지 칠 수 있다 " + ::MSU.Text.colorPositive(3) + " targets")
		});
		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("밀쳐지거나 속박당하는 것에 면역이 아닌 대상을 밀쳐냅니다. 밀쳐진 대상은 다음 효과를 잃습니다. [$ $|Skill+shieldwall_effect], [$ $|Skill+spearwall_effect] 그리고 [$ $|Skill+riposte_effect] 효과")
		});
		ret.push({
			id = 12,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("밀쳐지거나 속박되지 않는 대상은 다음과 같습니다. [$ $|Skill+staggered_effect] 대신")
		});
		return ret;
	}}.getTooltip;
});
