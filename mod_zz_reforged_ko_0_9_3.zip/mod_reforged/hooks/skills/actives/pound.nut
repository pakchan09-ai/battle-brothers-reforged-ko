::Reforged.HooksMod.hook("scripts/skills/actives/pound", function(q) {
	q.getTooltip = @(__original) { function getTooltip()
	{
		local ret = __original();

		foreach (entry in ret)
		{
			// Improve the vanilla entry about ignoring Shields to also mention Shieldwall
			if (entry.id == 8)
			{
				entry.text = ::Reforged.Mod.Tooltips.parseString(format("보너스를 무시합니다. [근접 방어|Concept.MeleeDefense] 방패로 부여되지만 방패로는 부여되지 않음 [$ $|Skill+shieldwall_effect]"));
				break;
			}
		}

		return ret;
	}}.getTooltip;
});
