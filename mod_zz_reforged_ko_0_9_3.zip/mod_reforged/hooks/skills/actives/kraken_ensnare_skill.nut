::Reforged.HooksMod.hook("scripts/skills/actives/kraken_ensnare_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "거대한 촉수를 사용하여 대상을 가두어 천천히 당신 쪽으로 끌어당깁니다!";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("대상은 다음을 얻습니다. [$ $|Skill+kraken_ensnare_effect] 효과")
		});
		return ret;
	}}.getTooltip;
});
