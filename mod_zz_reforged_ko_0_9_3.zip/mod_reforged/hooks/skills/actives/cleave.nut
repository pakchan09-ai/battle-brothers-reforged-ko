::Reforged.HooksMod.hook("scripts/skills/actives/cleave", function(q) {
	q.getTooltip = @(__original) { function getTooltip()
	{
		local ret = __original();
		foreach (entry in ret)
		{
			if (entry.id == 8 && entry.text.find("턴당 출혈 피해") != null)
			{
				entry.text = ::Reforged.Mod.Tooltips.parseString("스태킹을 가함 [$ $|Skill+bleeding_effect] 추가 피해를 위해");
				break;
			}
		}
		return ret;
	}}.getTooltip;
});
