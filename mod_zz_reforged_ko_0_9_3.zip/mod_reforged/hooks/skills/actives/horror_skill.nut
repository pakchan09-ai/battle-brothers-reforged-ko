::Reforged.HooksMod.hook("scripts/skills/actives/horror_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "대상의 가장 깊은 두려움을 유발하여 공포에 질려 얼어붙게 만듭니다!";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/bravery.png",
			text = ::Reforged.Mod.Tooltips.parseString("대상은 부정적인 멘탈을 받는다 [사기 판정|Concept.Morale] 와 " + ::MSU.Text.colorNegative(-15) + " 페널티 [의지|Concept.Bravery]")
		});
		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/bravery.png",
			text = ::Reforged.Mod.Tooltips.parseString("대상은 정신력을 추가로 받습니다. [사기 판정|Concept.Morale] 와 " + ::MSU.Text.colorNegative(-5) + " 페널티 [의지|Concept.Bravery]. 만약 이 [사기 판정|Concept.MoraleCheck] 성공하면 대상은 [$ $|Skill+horrified_effect] 효과")
		});
		return ret;
	}}.getTooltip;
});
