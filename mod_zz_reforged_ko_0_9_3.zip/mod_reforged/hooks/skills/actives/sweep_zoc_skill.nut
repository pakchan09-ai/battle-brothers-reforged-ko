::Reforged.HooksMod.hook("scripts/skills/actives/sweep_zoc_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = ::Reforged.Mod.Tooltips.parseString("움직이려는 캐릭터에게 주먹을 휘두르세요 [멀리|Concept.ZoneOfControl] 당신에게서.");
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("윌 [비틀거리다|Skill+staggered_effect] 명중한 대상")
		});
		return ret;
	}}.getTooltip;
});
