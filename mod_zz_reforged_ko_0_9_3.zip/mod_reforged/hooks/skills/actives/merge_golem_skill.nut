::Reforged.HooksMod.hook("scripts/skills/actives/merge_golem_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "주변의 살아있는 모래와 돌을 모아 더 크게 성장하세요!";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("모두를 완전히 치유합니다 [체력|Concept.Hitpoints]")
		});

		local entityType = ::MSU.isEqual(this.getContainer().getActor(), ::MSU.getDummyPlayer()) ? ::Const.EntityType.SandGolem : this.getContainer().getActor().getType();
		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("인접 2개 소모 " + ::Const.Strings.EntityNamePlural[entityType] + " 그리고 당신을 만든다 [$ $|Skill+golem_racial] 더 큰")
		});
		return ret;
	}}.getTooltip;
});
