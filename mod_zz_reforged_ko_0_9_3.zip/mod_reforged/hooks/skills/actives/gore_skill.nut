::Reforged.HooksMod.hook("scripts/skills/actives/gore_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "부자연스러운 영적 에너지로 전진하여 거대한 뿔로 적을 공격하세요.";
	}}.create;

	// Vanilla getTooltip for this skill only has name, description and cost string
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("윌 [비틀거리다|Skill+staggered_effect] 대상 타일 주변의 모든 대상을 밀어냅니다.")
		});
		return ret;
	}}.getTooltip;
});
