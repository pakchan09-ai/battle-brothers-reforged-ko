::Reforged.HooksMod.hook("scripts/skills/actives/grow_shield_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "가장 취약한 부분을 보호하기 위해 방패를 다시 키워보세요!";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("이득 [$ $|Item+schrat_shield]")
		});
		return ret;
	}}.getTooltip;
});
