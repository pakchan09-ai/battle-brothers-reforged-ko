::Reforged.HooksMod.hook("scripts/skills/actives/adrenaline_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		this.m.AIBehaviorID = ::Const.AI.Behavior.ID.Adrenaline;
	}}.create;

	q.getTooltip = @(__original) { function getTooltip()
	{
		local ret = __original();

		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("영향을 받지 않으며 받을 수 없습니다. [일시적 부상|Concept.InjuryTemporary] 활동하는 동안")
		});

		return ret;
	}}.getTooltip;
});
