::Reforged.HooksMod.hook("scripts/skills/actives/teleport_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "이 차원의 다른 위치에 나타나기 위해 평면 사이를 여행합니다.";
	}}.create;

	// Vanilla getTooltip for this skill doesn't mention the terrain transformation
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("순간이동 시작과 끝 부분의 지형을 눈으로 변환합니다.")
		});
		return ret;
	}}.getTooltip;
});
