::Reforged.HooksMod.hook("scripts/skills/actives/grant_night_vision_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "동료들에게 어둠 속에서도 선명하게 볼 수 있는 능력을 부여하세요!";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("대상과 대상에 인접한 아군은 더 이상 다음의 영향을 받지 않습니다. [$ $|Skill+night_effect] 이 전투가 진행되는 동안")
		});
		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/vision.png",
			text = "다양한 범위를 가지고 있습니다 " + ::MSU.Text.colorizeValue(this.getMaxRange()) + " tiles"
		});
		return ret;
	}}.getTooltip;
});
