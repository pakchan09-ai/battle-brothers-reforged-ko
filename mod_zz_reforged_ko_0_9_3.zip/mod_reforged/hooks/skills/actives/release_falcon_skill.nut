::Reforged.HooksMod.hook("scripts/skills/actives/release_falcon_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		this.m.Order = ::Const.SkillOrder.BeforeLast + 5;	// We want release-ables to be listed after break-free skills (which are BeforeLast)
	}}.create;

	q.getTooltip = @(__original) { function getTooltip()
	{
		local ret = __original();
		local effect = ::new("scripts/skills/effects/rf_falcon_released_effect");
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString(format("그렇지 않은 동맹국 [$ $|Skill+stunned_effect], 루팅 또는 [도주 중|Concept.Morale] 획득하다 %s 효과", ::Reforged.NestedTooltips.getNestedSkillName(effect))),
			children = effect.getTooltip().slice(2) // slice 2 to remove name and description
		});
		return ret;
	}}.getTooltip;

	q.onUse = @(__original) { function onUse( _user, _targetTile )
	{
		local ret = __original(_user, _targetTile);

		if (ret)
		{
			foreach (ally in ::Tactical.Entities.getAlliedActors(_user.getFaction()))
			{
				if (ally.getCurrentProperties().IsStunned || ally.getCurrentProperties().IsRooted || ally.getMoraleState() == ::Const.MoraleState.Fleeing)
				{
					continue;
				}

				ally.getSkills().add(::new("scripts/skills/effects/rf_falcon_released_effect"));
			}
		}

		return ret;
	}}.onUse;
});
