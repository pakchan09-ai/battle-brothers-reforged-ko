::Reforged.HooksMod.hook("scripts/skills/actives/unstoppable_charge_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "막을 수 없는 힘으로 타일에 돌진하여 해당 지역에 큰 피해를 입힙니다!";
	}}.create;

	// Vanilla has a getTooltip function defined for this skill but it doesn't provide all the details
	// so we overwrite it to produce a better tooltip overall
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.getDefaultUtilityTooltip();
		ret.extend([
			{
				id = 10,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("당신을 대상 타일로 무작위로 이동시킵니다. [기절시키다|Skill+stunned_effect], 또는 [비틀거리다|Skill+staggered_effect] 타일 주변의 적들을 밀쳐냅니다.")
			},
			{
				id = 11,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("넉백된 대상은 [$ $|Skill+shieldwall_effect], [$ $|Skill+spearwall_effect] 그리고 [$ $|Skill+riposte_effect] 효과")
			},
			{
				id = 12,
				type = "text",
				icon = "ui/icons/vision.png",
				text = "다양한 범위를 가지고 있습니다 " + ::MSU.Text.colorizeValue(this.getMaxRange()) + " tiles"
			}
		]);
		return ret;
	}}.getTooltip;
});
