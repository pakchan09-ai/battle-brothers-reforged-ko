::Reforged.HooksMod.hook("scripts/skills/actives/miasma_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "대상 지역에 독성 장기를 소환하여 살아 있고 숨쉬는 모든 것에 피해를 줍니다!";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("대상 타일은 지속되는 장기를 얻습니다. " + ::MSU.Text.colorPositive(3) + " [라운드|Concept.Round]")
		});
		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("언데드를 제외한 모든 캐릭터가 받습니다. " + ::MSU.Text.colorNegative(5) + " - " + ::MSU.Text.colorNegative(10) + " 그들이 종료할 때 피해를 입는다 [턴|Concept.Turn] 미아즈마 속에서")
		});
		ret.push({
			id = 12,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("화재 또는 연기와 같은 기존 타일 효과를 날려버립니다.")
		});
		ret.push({
			id = 13,
			type = "text",
			icon = "ui/icons/vision.png",
			text = "다양한 범위를 가지고 있습니다 " + ::MSU.Text.colorizeValue(this.getMaxRange()) + " tiles"
		});
		return ret;
	}}.getTooltip;
});
