::Reforged.HooksMod.hook("scripts/skills/actives/greater_flesh_golem_attack_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = ::Reforged.Mod.Tooltips.parseString("무겁고 둔기 같은 근접 공격 [기절시키다|Skill+stunned_effect] 적중 시 대상.");
	}}.create;

	// Overwrite, because Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		return this.skill.getDefaultTooltip();
	}}.getTooltip;
});
