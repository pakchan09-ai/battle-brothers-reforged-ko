::Reforged.HooksMod.hook("scripts/skills/actives/fling_back_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "캐릭터를 뒤로 던지고 해당 위치로 이동하세요!";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/fatigue.png",
			text = ::Reforged.Mod.Tooltips.parseString("대상 빌드 " + ::MSU.Text.colorNegative("10") + " [피로|Concept.Fatigue]")
		});
		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/regular_damage.png",
			text = ::Reforged.Mod.Tooltips.parseString("대상은 뒤로 던져지며 착지 시 피해를 입습니다.")
		});
		ret.push({
			id = 12,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("대상은 다음과 같은 효과를 잃습니다. [$ $|Skill+shieldwall_effect], [$ $|Skill+spearwall_effect] 그리고 [$ $|Skill+riposte_effect]")
		});
		ret.push({
			id = 13,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("무시하고 대상 타일로 이동합니다. [통제 구역|Concept.ZoneOfControl]")
		});
		return ret;
	}}.getTooltip;

	// We delay the onFollow of this skill by another 100ms because otherwise the entity doesn't follow through with this function properly when at very high speeds using some faster combat speed mods
	q.onFollow = @(__original) { function onFollow( _tag )
	{
		if (::Time.getVirtualSpeed() > 2)
		{
			::Time.scheduleEvent(::TimeUnit.Virtual, 100, __original, _tag);
		}
		else
		{
			__original(_tag);
		}
	}}.onFollow;
});
