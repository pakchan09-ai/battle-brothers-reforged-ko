::Reforged.HooksMod.hook("scripts/skills/actives/fire_mortar_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "폭발적인 충격으로 땅으로 돌아올 때 공중에 높이 포탄을 발사하여 큰 피해를 입힙니다.";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("이 캐릭터의 다음 번에 영향을 미칠 타일과 주변 타일을 표시합니다. [턴|Concept.Turn]. 충격을 받으면 타일 안의 캐릭터는 피해를 입고 [$ $|Skill+shellshocked_effect]")
		});
		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/vision.png",
			text = "다양한 범위를 가지고 있습니다 " + ::MSU.Text.colorizeValue(this.getMaxRange()) + " tiles"
		});
		ret.push({
			id = 20,
			type = "text",
			icon = "ui/icons/warning.png",
			text = ::Reforged.Mod.Tooltips.parseString("마다 한 번만 사용할 수 있습니다. " + ::MSU.Text.colorNegative(this.m.Cooldown) + " [턴|Concept.Turn]")
		});
		return ret;
	}}.getTooltip;
});
