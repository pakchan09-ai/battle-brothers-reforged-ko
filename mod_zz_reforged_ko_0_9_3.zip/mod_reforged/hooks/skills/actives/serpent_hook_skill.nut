::Reforged.HooksMod.hook("scripts/skills/actives/serpent_hook_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "대상 주위에 몸을 감싸고 더 취약한 위치로 끌어당깁니다!";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("대상을 잡고 옆 타일로 끌어당깁니다.")
		});
		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("목표는 된다 [$ $|Skill+staggered_effect]")
		});
		ret.push({
			id = 12,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("대상은 패배한다 [$ $|Skill+shieldwall_effect], [$ $|Skill+spearwall_effect] 그리고 [$ $|Skill+riposte_effect] 효과")
		});
		ret.push({
			id = 13,
			type = "text",
			icon = "ui/icons/regular_damage.png",
			text = ::Reforged.Mod.Tooltips.parseString("대상이 낮은 고도로 끌려가면 피해를 입습니다.")
		});
		ret.push({
			id = 14,
			type = "text",
			icon = "ui/icons/vision.png",
			text = "다양한 범위를 가지고 있습니다 " + ::MSU.Text.colorizeValue(this.getMaxRange()) + " tiles"
		});
		return ret;
	}}.getTooltip;
});
