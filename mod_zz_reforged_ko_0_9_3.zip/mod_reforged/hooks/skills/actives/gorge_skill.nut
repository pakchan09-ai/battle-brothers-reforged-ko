::Reforged.HooksMod.hook("scripts/skills/actives/gorge_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "대상을 부수고 갈기갈기 찢어버릴 듯한 강력한 물어뜯기!";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		return this.skill.getDefaultTooltip();
	}}.getTooltip;
});
