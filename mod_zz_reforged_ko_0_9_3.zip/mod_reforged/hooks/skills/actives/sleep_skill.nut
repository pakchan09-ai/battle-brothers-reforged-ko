::Reforged.HooksMod.hook("scripts/skills/actives/sleep_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "적을 잠들게 하여 영혼을 깨뜨리는 악몽에 취약하게 만드세요!";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("대상은 정신적인 영향을 받습니다. [사기 판정|Concept.Morale] 더 큰 처벌로 [의지|Concept.Bravery] 그들이 당신에게 더 가까이 있을수록. 성공하면 목표는 떨어진다 [$ $|Skill+sleeping_effect]")
		});
		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/vision.png",
			text = "다양한 범위를 가지고 있습니다 " + ::MSU.Text.colorizeValue(this.getMaxRange()) + " tiles"
		});
		return ret;
	}}.getTooltip;
});
