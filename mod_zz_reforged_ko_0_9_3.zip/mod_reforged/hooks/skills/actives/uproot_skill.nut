::Reforged.HooksMod.hook("scripts/skills/actives/uproot_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "땅에서 커다란 가시뿌리를 뽑아 여러 대상을 부수고 꿰뚫습니다.";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.getDefaultTooltip();
		ret.extend([
			{
				id = 10,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("까지 공격할 예정 " + ::MSU.Text.colorPositive(3) + " 직선으로 목표물")
			},
			{
				id = 11,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("목표는 [$ $|Skill+staggered_effect] 히트에")
			},
			{
				id = 12,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("다른 Schrats에 손상을 주거나 영향을 주지 않습니다.")
			}
		]);
		return ret;
	}}.getTooltip;
});
