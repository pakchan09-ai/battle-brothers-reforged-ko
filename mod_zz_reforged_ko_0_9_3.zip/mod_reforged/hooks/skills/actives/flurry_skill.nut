::Reforged.HooksMod.hook("scripts/skills/actives/flurry_skill", function(q) {
	q.m.NumAttacks <- 6;

	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = ::Reforged.Mod.Tooltips.parseString("6회 공격하는 예측할 수 없는 근접 둔기 공격으로, 인접한 모든 적에게 타격을 고르게 분산시킵니다.");
	}}.create;

	// Overwrite, because Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		return this.skill.getDefaultTooltip();
	}}.getTooltip;

	// Rewrite the vanilla function so that the user will always perform the full number of attacks
	// and won't waste scheduled attacks for entities that die during the flurry.
	q.onUse = @() { function onUse( _user, _targetTile )
	{
		::Sound.play(::MSU.Array.rand(this.m.SoundOnHit), 1.0, _targetTile.Pos);
		::Tactical.EventLog.log(::Const.UI.getColorizedEntityName(_user) + " 주위에 엄청난 타격을 가합니다.");
		local ownTile = _user.getTile();

		// Vanilla hardcodes 1 for level difference in the onUse function. We use the skill's member variable for easier submodding.
		local maxLevelDifference = this.m.MaxLevelDifference;
		local tag = {
			User = _user,
			TargetEntities = ::MSU.Tile.getNeighbors(ownTile).filter(@(_, _t) _t.IsOccupiedByActor && ::Math.abs(_t.Level - ownTile.Level) <= maxLevelDifference && !_user.isAlliedWith(_t.getEntity())).map(@(_t) _t.getEntity()),
			CurrentIndex = 0,
			NumAttacks = this.m.NumAttacks,
			Callback = this.RF_doFlurry.bindenv(this)
		};

		this.getContainer().setBusy(true);
		this.RF_doFlurry(tag);
		return true;
	}}.onUse;

	// New function. Used as callback from onUse.
	// Performs an attack and schedules the next attack on the next target.
	q.RF_doFlurry <- { function doFlurry( _tag )
	{
		if (!_tag.User.isAlive())
			return;

		local targetEntity = _tag.TargetEntities[_tag.CurrentIndex];
		if (!targetEntity.isAlive() || !targetEntity.isAttackable())
		{
			// The array will shrink due to removal, so decrement the index so our order stays correct.
			_tag.TargetEntities.remove(_tag.CurrentIndex--);
		}
		else
		{
			this.spawnAttackEffect(targetEntity.getTile(), ::Const.Tactical.AttackEffectChop);
			this.attackEntity(_tag.User, targetEntity);
			_tag.NumAttacks--;
		}

		if (_tag.NumAttacks == 0 || _tag.TargetEntities.len() == 0)
		{
			this.getContainer().setBusy(false);
		}
		else
		{
			if (++_tag.CurrentIndex >= _tag.TargetEntities.len())
			{
				_tag.CurrentIndex = 0;
			}
			::Time.scheduleEvent(::TimeUnit.Virtual, 200, _tag.Callback, _tag);
		}
	}}.doFlurry;
});
