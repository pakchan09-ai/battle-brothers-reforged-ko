::Reforged.HooksMod.hook("scripts/skills/actives/crack_the_whip_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "야생 애완동물이 순종하도록 채찍을 휘두르세요.";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("동물이 다음 번에 야생으로 나가는 것을 방지합니다. [턴|Concept.Turn]")
		});
		return ret;
	}}.getTooltip;
});
