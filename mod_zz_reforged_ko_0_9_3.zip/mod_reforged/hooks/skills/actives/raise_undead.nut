::Reforged.HooksMod.hook("scripts/skills/actives/raise_undead", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "당신의 명령을 따르기 위해 시체를 되살리세요!";
		this.m.IconDisabled = "skills/active_26_sw.png";	// Vanilla uses a wrong icon here
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/warning.png",
			text = ::Reforged.Mod.Tooltips.parseString("목표로 삼은 부활 가능한 시체를 위더갱어로 일으킵니다.")
		});
		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/vision.png",
			text = "다양한 범위를 가지고 있습니다 " + ::MSU.Text.colorizeValue(this.getMaxRange()) + " tiles"
		});
		return ret;
	}}.getTooltip;
});
