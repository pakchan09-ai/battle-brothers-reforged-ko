::Reforged.HooksMod.hook("scripts/skills/actives/gash_skill", function(q) {
	q.m.BleedStacks <- 3;
	q.m.MeleeSkillAdd <- 5;

	// MSU Function
	// Add IsIgnooredAsAOO to softReset so that our adjustment to it
	// in perk_rf_en_garde works correctly.
	q.softReset = @(__original) { function softReset()
	{
		__original();
		this.resetField("IsIgnoredAsAOO");
	}}.softReset;

	q.create = @(__original) { function create()
	{
		__original();
		this.m.AIBehaviorID = ::Const.AI.Behavior.ID.Gash;
	}}.create;

	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.getDefaultTooltip();

		if (this.m.MeleeSkillAdd != 0)
		{
			ret.push({
				id = 6,
				type = "text",
				icon = "ui/icons/hitchance.png",
				text = "있다 " + ::MSU.Text.colorizeValue(this.m.MeleeSkillAdd, {AddSign = true, AddPercent = true}) + " 칠 기회"
			});
		}

		if (this.getContainer().getActor().getCurrentProperties().IsSpecializedInSwords)
		{
			ret.push({
				id = 6,
				type = "text",
				icon = "ui/icons/hitchance.png",
				text = ::Reforged.Mod.Tooltips.parseString("있다 " + ::MSU.Text.colorNegative("50%") + " 더 낮은 [한계치|Concept.InjuryThreshold] 가하다 [부상|Concept.InjuryTemporary]")
			});
		}
		else
		{
			ret.push({
				id = 6,
				type = "text",
				icon = "ui/icons/hitchance.png",
				text = ::Reforged.Mod.Tooltips.parseString("있다 " + ::MSU.Text.colorNegative("33%") + " 더 낮은 [한계치|Concept.InjuryThreshold] 가하다 [부상|Concept.InjuryTemporary]")
			});
		}

		if (this.m.BleedStacks != 0)
		{
			ret.push({
				id = 7,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("Applies " + ::MSU.Text.colorPositive(this.m.BleedStacks) + " 스택 [$ $|Skill+bleeding_effect] 적어도 피해를 입힐 때 " + ::MSU.Text.color(::Const.UI.Color.DamageValue, ::Const.Combat.MinDamageToApplyBleeding) + " 손상 [체력|Concept.Hitpoints]")
			});
		}

		return ret;
	}}.getTooltip;

	q.onAnySkillUsed = @() { function onAnySkillUsed( _skill, _targetEntity, _properties )
	{
		if (_skill == this)
		{
			_properties.MeleeSkill += this.m.MeleeSkillAdd;
			// this.m.HitChanceBonus is set by Modular Vanilla based on changes to _properties.MeleeSkill
		}
	}}.onAnySkillUsed;

	q.onTargetHit = @(__original) { function onTargetHit( _skill, _targetEntity, _bodyPart, _damageInflictedHitpoints, _damageInflictedArmor )
	{
		__original(_skill, _targetEntity, _bodyPart, _damageInflictedHitpoints, _damageInflictedArmor);
		if (_skill == this && _targetEntity.isAlive() && _damageInflictedHitpoints >= ::Const.Combat.MinDamageToApplyBleeding && !_targetEntity.getCurrentProperties().IsImmuneToBleeding)
		{
			for (local i = 0; i < this.m.BleedStacks; i++)
			{
				_targetEntity.getSkills().add(::new("scripts/skills/effects/bleeding_effect"));
			}
		}
	}}.onTargetHit;
});
