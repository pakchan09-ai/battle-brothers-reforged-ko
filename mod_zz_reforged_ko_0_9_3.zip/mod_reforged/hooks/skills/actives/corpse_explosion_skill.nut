::Reforged.HooksMod.hook("scripts/skills/actives/corpse_explosion_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = ::Reforged.Mod.Tooltips.parseString("시체나 육체 요람을 폭파하여 끔찍한 폭발로 파괴합니다. 폭발은 시체 위에 서 있는 모든 대상과 인접한 모든 적에게 피해를 입히고 영향을 받은 모든 타일에 지속적인 독기를 남깁니다.");
	}}.create;

	// Overwrite, because Vanilla uses a hard-coded implementation, instead of using getDefaultUtilityTooltip
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();

		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/vision.png",
			text = "다양한 범위를 가지고 있습니다 " + ::MSU.Text.colorizeValue(this.getMaxRange()) + " tiles"
		});

		return ret;
	}}.getTooltip;
});
