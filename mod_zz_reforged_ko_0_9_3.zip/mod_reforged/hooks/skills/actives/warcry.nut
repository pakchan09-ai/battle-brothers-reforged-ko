::Reforged.HooksMod.hook("scripts/skills/actives/warcry", function(q) {
	q.create = @(__original) { function create()
	{
		__original();

		// VanillaFix: vanilla uses the wrong icon active_41
		this.m.Icon = "skills/active_49.png";
		this.m.IconDisabled = "skills/active_49_sw.png";

		// Vanilla is missing a description for this skill
		this.m.Description = ::Reforged.Mod.Tooltips.parseString("힘을 실어주기 위해 큰 소리로 외친다. [사기|Concept.Morale] 적에게 주는 동시에 아군에게 [망설임|Concept.Morale]!");
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.getDefaultUtilityTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("모든 아군과 적군은 긍정적인 것과 부정적인 것을 받습니다. [사기 판정|Concept.Morale] 각각, 당신과 더 가까운 사람들이 더 강한 수표를 받게 됩니다.")
		});

		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/fatigue.png",
			text = ::Reforged.Mod.Tooltips.parseString("전장에 있는 모든 아군이 회복됩니다. " + ::MSU.Text.colorPositive(20) + " [피로|Concept.Fatigue]")
		});

		return ret;
	}}.getTooltip;
});
