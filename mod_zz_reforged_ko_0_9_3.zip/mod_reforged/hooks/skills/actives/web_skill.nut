::Reforged.HooksMod.hook("scripts/skills/actives/web_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "대상 주위에 거미줄을 회전시켜 대상을 제자리에 가두어 전투 및 방어 능력을 방해합니다.";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.getDefaultUtilityTooltip();
		ret.extend([
			{
				id = 10,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("목표는 된다 [$ $|Skill+web_effect]")
			},
			{
				id = 11,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("마다 한 번만 사용할 수 있습니다. " + ::MSU.Text.colorNegative(3) + " turns")
			}
		]);
		return ret;
	}}.getTooltip;
});
