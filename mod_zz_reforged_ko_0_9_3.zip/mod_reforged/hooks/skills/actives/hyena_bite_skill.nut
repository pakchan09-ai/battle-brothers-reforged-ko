::Reforged.HooksMod.hook("scripts/skills/actives/hyena_bite_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "갑옷을 꿰뚫고 그 아래의 살갗까지 파고드는 것이 능숙한 공격!";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("가하다 [$ $|Skill+bleeding_effect] 적어도 거래할 때 " + ::MSU.Text.colorNegative(::Const.Combat.MinDamageToApplyBleeding) + " 손상 [체력|Concept.Hitpoints]")
		});
		return ret;
	}}.getTooltip;
});
