::Reforged.HooksMod.hook("scripts/skills/actives/charm_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = ::Reforged.Mod.Tooltips.parseString("캐릭터를 매혹하여 그가 동료를 공격하고 대신 당신에게 복종하도록 강요하십시오. 캐릭터의 레벨이 높을수록 [의지|Concept.Bravery], 매혹에 저항할 확률이 높아집니다.");
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("트리거됩니다 " + ::MSU.Text.colorNegative("2") + " [사기 판정|Concept.Morale] 목표에 도달하고 둘 다 성공하면 목표는 다음을 얻습니다. [$ $|Skill+charmed_effect] 효과")
		});
		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/vision.png",
			text = "다양한 범위를 가지고 있습니다 " + ::MSU.Text.colorizeValue(this.getMaxRange()) + " tiles"
		});
		return ret;
	}}.getTooltip;
});
