::Reforged.HooksMod.hook("scripts/skills/actives/lesser_flesh_golem_attack_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = ::Reforged.Mod.Tooltips.parseString("무뚝뚝한 근접 공격 [$ $|Skill+dazed_effect] 적중 대상이 면역이 아닌 경우 [$ $|Skill+stunned_effect].");
	}}.create;

	// Overwrite, because Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		return this.skill.getDefaultTooltip();
	}}.getTooltip;
});
