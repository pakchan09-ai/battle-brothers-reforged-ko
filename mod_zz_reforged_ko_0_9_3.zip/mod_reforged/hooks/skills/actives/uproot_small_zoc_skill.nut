::Reforged.HooksMod.hook("scripts/skills/actives/uproot_small_zoc_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = ::Reforged.Mod.Tooltips.parseString("땅에서 가시뿌리를 뽑아 움직이려는 사람을 공격합니다. [멀리|Concept.ZoneOfControl] 너에게서!");
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.getDefaultTooltip();
		ret.extend([
			{
				id = 10,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("목표는 된다 [$ $|Skill+staggered_effect] 히트에")
			},
			{
				id = 11,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("다른 Schrats에 손상을 주거나 영향을 주지 않습니다.")
			}
		]);
		return ret;
	}}.getTooltip;
});
