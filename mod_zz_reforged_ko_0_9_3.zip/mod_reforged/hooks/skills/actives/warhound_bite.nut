::Reforged.HooksMod.hook("scripts/skills/actives/warhound_bite", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "큰 주둥이로 그들을 후려갈겨 살을 물어뜯고 찢습니다.";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		return this.getDefaultTooltip();
	}}.getTooltip;
});
