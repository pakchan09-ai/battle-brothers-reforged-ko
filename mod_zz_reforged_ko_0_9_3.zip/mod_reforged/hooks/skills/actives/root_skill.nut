::Reforged.HooksMod.hook("scripts/skills/actives/root_skill", function(q) {
	q.m.Cooldown <- 0;
	q.m.TurnsRemaining <- 0;

	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "땅에서 두꺼운 덩굴을 일으켜 적을 제자리에 가두어 이동 및 방어 능력을 방해합니다.";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("대상과 인접한 모든 적들은 [$ $|Skill+rooted_effect] 효과")
		});
		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/vision.png",
			text = "다양한 범위를 가지고 있습니다 " + ::MSU.Text.colorizeValue(this.getMaxRange()) + " tiles"
		});
		return ret;
	}}.getTooltip;

	q.onUse = @(__original) { function onUse( _user, _targetTile )
	{
		this.m.TurnsRemaining = this.m.Cooldown;
		return __original(_user, _targetTile);
	}}.onUse;

	q.isUsable = @() { function isUsable()
	{
		return this.skill.isUsable() && this.m.TurnsRemaining == 0;
	}}.isUsable;

	q.onTurnEnd = @() { function onTurnEnd()
	{
		this.m.TurnsRemaining = ::Math.max(0, this.m.TurnsRemaining - 1);
	}}.onTurnEnd;
});
