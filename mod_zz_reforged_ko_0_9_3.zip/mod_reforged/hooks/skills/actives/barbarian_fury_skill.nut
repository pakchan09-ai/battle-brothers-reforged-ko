::Reforged.HooksMod.hook("scripts/skills/actives/barbarian_fury_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		this.m.Icon = "skills/active_175.png";
		this.m.IconDisabled = "skills/active_175_sw.png";
		// Vanilla is missing a description for this skill
		this.m.Description = ::Reforged.Mod.Tooltips.parseString("당신이나 동맹국 모두가 아닌 경우 인접한 동맹국과 위치를 바꿉니다. [$ $|Skill+stunned_effect] 또는 뿌리를 내렸습니다. 전투 라인을 회전시켜 새로운 병력을 전방에 유지하세요!");
	}}.create;

	q.getTooltip = @() { function getTooltip()
	{
		return this.skill.getDefaultUtilityTooltip();
	}}.getTooltip;

	q.getCursorForTile = @() { function getCursorForTile( _tile )
	{
		return ::Const.UI.Cursor.Rotation;
	}}.getCursorForTile;
});
