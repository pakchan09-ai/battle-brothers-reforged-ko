::Reforged.HooksMod.hook("scripts/skills/actives/move_tail_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "어디를 가든 꼬리를 가지고 다니세요!";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("무시하고 꼬리를 옆으로 가져옵니다. [통제 구역|Concept.ZoneOfControl]")
		});
		return ret;
	}}.getTooltip;
});
