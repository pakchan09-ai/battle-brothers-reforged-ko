::Reforged.HooksMod.hook("scripts/skills/actives/throw_golem_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "모래와 돌로 이루어진 바위를 목표물에 던져서 자신을 더 작은 생명체로 나누세요!";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.getDefaultTooltip();
		local entityType = ::MSU.isEqual(this.getContainer().getActor(), ::MSU.getDummyPlayer()) ? ::Const.EntityType.SandGolem : this.getContainer().getActor().getType();
		ret.extend([
			{
				id = 10,
				type = "text",
				icon = "ui/icons/special.png",
				text = format("생성됩니다 %s%목표물과 인접해 있다", ::Const.Strings.getArticle(::Const.Strings.EntityName[entityType]), ::Const.Strings.EntityName[entityType])
			},
			{
				id = 11,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("크기가 줄어들고 두 개가 생성됩니다. " + ::Const.Strings.EntityNamePlural[entityType] + " 당신 옆에 이 정도 크기의")
			},
			{
				id = 12,
				type = "text",
				icon = "ui/icons/vision.png",
				text = "다양한 범위를 가지고 있습니다 " + ::MSU.Text.colorizeValue(this.getMaxRange()) + " tiles"
			}
		]);
		return ret;
	}}.getTooltip;
});
