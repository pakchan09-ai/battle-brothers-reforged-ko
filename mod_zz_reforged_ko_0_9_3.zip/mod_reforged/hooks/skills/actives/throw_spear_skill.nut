::Reforged.HooksMod.hook("scripts/skills/actives/throw_spear_skill", function(q) {
	q.m.AdditionalAccuracy <- 20;
	q.m.AdditionalHitChance <- -15;
	q.m.FatigueDamage <- 40;

	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultTooltip();

		local damage = this.getContainer().getActor().getItems().getItemAtSlot(::Const.ItemSlot.Mainhand).getShieldDamage();
		if (damage != 0)
		{
			ret.push({
				id = 10,
				type = "text",
				icon = "ui/icons/shield_damage.png",
				text = "가하다 " + ::MSU.Text.colorDamage(damage) + " 방패의 손상"
			});
		}

		if (this.m.FatigueDamage != 0)
		{
			ret.push({
				id = 11,
				type = "text",
				icon = "ui/icons/fatigue.png",
				text = ::Reforged.Mod.Tooltips.parseString("Inflicts " + ::MSU.Text.colorDamage(this.m.FatigueDamage) + " [피로|Concept.Fatigue] 방패에 맞았을 때")
			});
		}

		ret.extend(this.getRangedTooltip());

		if (this.getContainer().getActor().isEngagedInMelee())
		{
			ret.push({
				id = 20,
				type = "text",
				icon = "ui/tooltips/warning.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorNegative("이 캐릭터는 다음과 같으므로 사용할 수 없습니다. [교전 중|Concept.ZoneOfControl] 근접전에서"))
			});
		}

		return ret;
	}}.getTooltip;

	// Same as vanilla except we use the custom AdditionalAccuracy and AdditionalHitChance instead of hard-coded ones
	q.onAnySkillUsed = @() { function onAnySkillUsed( _skill, _targetEntity, _properties )
	{
		if (_skill == this)
		{
			_properties.RangedSkill += this.m.AdditionalAccuracy;
			_properties.HitChanceAdditionalWithEachTile += this.m.AdditionalHitChance;

			if (_targetEntity != null)
			{
				local shield = _targetEntity.getOffhandItem();

				if (shield != null && shield.isItemType(::Const.Items.ItemType.Shield))
				{
					this.m.IsUsingHitchance = false;
				}
				else
				{
					this.m.IsUsingHitchance = true;
				}
			}
			else
			{
				this.m.IsUsingHitchance = true;
			}
		}
	}}.onAnySkillUsed;

	q.onApplyShieldDamage = @(__original) { function onApplyShieldDamage( _tag )
	{
		if (this.m.FatigueDamage != 0)
		{
			local targetEntity = _tag.TargetTile.getEntity();
			local hitInfo = clone ::Const.Tactical.HitInfo;
			hitInfo.MV_PropertiesForBeingHit = targetEntity.getCurrentProperties();
			hitInfo.DamageFatigue = this.m.FatigueDamage;
			targetEntity.setFatigue(::Math.min(targetEntity.getFatigueMax(), targetEntity.getFatigue() + targetEntity.MV_calcFatigueDamageReceived(this, hitInfo)));
		}

		return __original(_tag);
	}}.onApplyShieldDamage;
});
