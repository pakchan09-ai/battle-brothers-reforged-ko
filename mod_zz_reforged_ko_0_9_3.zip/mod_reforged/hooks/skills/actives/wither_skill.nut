::Reforged.HooksMod.hook("scripts/skills/actives/wither_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "대상에게 저주를 걸어 몸을 시들게 만듭니다.";
		this.m.AIBehaviorID = ::Const.AI.Behavior.ID.Wither;
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.getDefaultUtilityTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("목표는 된다 [$ $|Skill+withered_effect]")
		});
		return ret;
	}}.getTooltip;
});
