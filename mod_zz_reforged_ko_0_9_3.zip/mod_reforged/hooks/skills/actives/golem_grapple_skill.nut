::Reforged.HooksMod.hook("scripts/skills/actives/golem_grapple_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = ::Reforged.Mod.Tooltips.parseString("피해를 입히지 않지만 근접 공격을 합니다. [무장해제하다|Skill+disarmed_effect] 명중 시 대상.");
	}}.create;

	// Overwrite, because Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		return this.skill.getDefaultTooltip();
	}}.getTooltip;
});
