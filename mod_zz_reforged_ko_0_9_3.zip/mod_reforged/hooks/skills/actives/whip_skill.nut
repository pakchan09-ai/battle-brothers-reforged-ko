::Reforged.HooksMod.hook("scripts/skills/actives/whip_skill", function(q) {
	q.getTooltip = @(__original) { function getTooltip()
	{
		local ret = __original();
		foreach (entry in ret)
		{
			// Replace vanilla tooltip about bleeding to conform to Reforged bleeding mechanic
			if (entry.id == 8)
			{
				entry.text = ::Reforged.Mod.Tooltips.parseString("가하다 [$ $|Skill+bleeding_effect] 적어도 거래할 때 " + ::MSU.Text.colorDamage(::Const.Combat.MinDamageToApplyBleeding) + " 손상 [체력|Concept.Hitpoints]")
				break;
			}
		}
		return ret;
	}}.getTooltip;
});
