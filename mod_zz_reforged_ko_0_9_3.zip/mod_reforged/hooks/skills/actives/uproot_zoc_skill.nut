::Reforged.HooksMod.hook("scripts/skills/actives/uproot_zoc_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		this.m.SoundOnHitHitpoints = [
			"sounds/combat/break_free_roots_00.wav",
			"sounds/combat/break_free_roots_01.wav",
			"sounds/combat/break_free_roots_02.wav",
			"sounds/combat/break_free_roots_03.wav"
		];
		// Vanilla is missing a description for this skill
		this.m.Description = ::Reforged.Mod.Tooltips.parseString("땅에서 커다란 가시뿌리를 뽑아 움직이려는 사람을 공격합니다. [멀리|Concept.ZoneOfControl] 너에게서!");
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.getDefaultTooltip();
		ret.extend([
			{
				id = 10,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("목표는 된다 [$ $|Skill+staggered_effect] 그리고 [$ $|Skill+rooted_effect] 히트에")
			},
			{
				id = 11,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("다른 Schrats에 손상을 주거나 영향을 주지 않습니다.")
			}
		]);
		return ret;
	}}.getTooltip;

	q.onTargetHit = @() { function onTargetHit( _skill, _targetEntity, _bodyPart, _damageInflictedHitpoints, _damageInflictedArmor )
	{
		if (_skill == this && _targetEntity.isAlive() && _targetEntity.getType() != ::Const.EntityType.Schrat && _targetEntity.getType() != ::Const.EntityType.SchratSmall)
		{
			_targetEntity.getSkills().add(::new("scripts/skills/effects/rooted_effect"));

			local breakFree = ::new("scripts/skills/actives/break_free_skill");
			breakFree.setDecal("roots_destroyed");
			breakFree.m.Icon = "skills/active_75.png";
			breakFree.m.IconDisabled = "skills/active_75_sw.png";
			breakFree.m.Overlay = "active_75";
			breakFree.m.SoundOnUse = this.m.SoundOnHitHitpoints;

			_targetEntity.getSkills().add(breakFree);

			_targetEntity.raiseRootsFromGround("bust_roots", "bust_roots_back");
		}
	}}.onTargetHit;

	q.onQueryTooltip = @(__original) { function onQueryTooltip( _skill, _tooltip )
	{
		// The ZOC skill is not shown in the actor's tactical tooltip in Reforged. So we add the "rooting" behavior to the tooltip of the active uproot skill.
		if (_skill.getID() == "actives.uproot")
		{
			_tooltip.push({
				id = 100,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("윌 [$ $|Skill+rooted_effect] 성공 시 목표 [기회 공격|Concept.ZoneOfControl]")
			});
		}
	}}.onQueryTooltip;
});
