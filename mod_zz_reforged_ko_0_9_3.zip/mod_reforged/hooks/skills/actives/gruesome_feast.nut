::Reforged.HooksMod.hook("scripts/skills/actives/gruesome_feast", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "시체를 마음껏 먹어서 자신을 치유하고 더 크게 성장하세요!";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/health.png",
			text = ::Reforged.Mod.Tooltips.parseString("모두 [체력|Concept.Hitpoints] 그리고 [부상|Concept.InjuryTemporary] 완전히 치유되었습니다")
		});
		ret.push({
			id = 12,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("이득 [$ $|Skill+gruesome_feast_effect] 효과")
		});
		return ret;
	}}.getTooltip;
});
