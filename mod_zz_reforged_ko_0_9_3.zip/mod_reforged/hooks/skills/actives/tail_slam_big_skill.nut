::Reforged.HooksMod.hook("scripts/skills/actives/tail_slam_big_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla has the name Tail Slam for this skill which is the same as the name for tail_slam_skill
		// We give it a unique name to help differentiate the two skills
		this.m.Name = "꼬리 쓰레쉬";
		// Vanilla is missing a description for this skill
		this.m.Description = "꼬리를 무모하게 휘둘러 친구와 적 모두 주변의 모든 목표를 타작하세요!";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.getDefaultTooltip();
		ret.extend([
			{
				id = 10,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("무작위로 [멍해짐|Skill+dazed_effect], [기절시키다|Skill+stunned_effect] 아니면 목표물을 밀어내거나")
			}
		]);
		return ret;
	}}.getTooltip;
});
