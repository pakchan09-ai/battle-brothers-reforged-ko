::Reforged.HooksMod.hook("scripts/skills/actives/alp_teleport_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		this.m.Description = "알프스가 공격을 받으면 무작위 타일로 순간이동합니다."; // Vanilla is missing a description for this skill
		// Vanilla is missing icons for this skill
		this.m.Icon = "skills/rf_alp_teleport_skill.png";
		this.m.IconDisabled = "skills/rf_alp_teleport_skill_sw.png";
	}}.create;
});
