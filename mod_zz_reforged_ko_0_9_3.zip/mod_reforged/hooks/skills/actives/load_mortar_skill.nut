::Reforged.HooksMod.hook("scripts/skills/actives/load_mortar_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "인접한 박격포에 대형 포탄을 장전합니다.";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();
		ret.push({
			id = 20,
			type = "text",
			icon = "ui/icons/warning.png",
			text = ::Reforged.Mod.Tooltips.parseString("마다 한 번만 사용할 수 있습니다. " + ::MSU.Text.colorNegative(this.m.Cooldown) + " [턴|Concept.Turn]")
		});
		if (this.getContainer().getActor().isEngagedInMelee())
		{
			ret.push({
				id = 21,
				type = "text",
				icon = "ui/icons/warning.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorNegative("이 캐릭터는 다음과 같으므로 사용할 수 없습니다. [교전 중|Concept.ZoneOfControl] 근접전에서"))
			});
		}
		return ret;
	}}.getTooltip;
});
