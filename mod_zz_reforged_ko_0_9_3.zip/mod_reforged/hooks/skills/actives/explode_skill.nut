::Reforged.HooksMod.hook("scripts/skills/actives/explode_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "폭발하여 옆에 있는 모든 사람에게 피해를 주는 뼈 파편을 생성합니다.";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("인접한 타일에 있는 모든 사람에게 약간의 피해를 줍니다.")
		});
		return ret;
	}}.getTooltip;
});
