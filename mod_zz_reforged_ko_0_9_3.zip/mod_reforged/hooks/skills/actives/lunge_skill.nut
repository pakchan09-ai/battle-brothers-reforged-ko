::Reforged.HooksMod.hook("scripts/skills/actives/lunge_skill", function(q) {
	q.m.MeleeSkillAdd <- -20;

	q.create = @(__original) { function create()
	{
		__original();
		this.m.AIBehaviorID = ::Const.AI.Behavior.ID.RF_AttackLunge;
	}}.create;

	q.isDuelistValid <- { function isDuelistValid()
	{
		return this.getBaseValue("ActionPointCost") <= 4;
	}}.isDuelistValid;

	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.getDefaultTooltip();
		ret.extend([
			{
				id = 6,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("무시하고 사용자를 대상 옆으로 이동합니다. [통제 구역|Concept.ZoneOfControl]")
			},
			{
				id = 7, // vanilla has id 6 for this, the same as previous entry
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("추가 피해를 주며, 사용자의 전류가 높아집니다. [주도력|Concept.Initiative]")
			}
		]);

		if (this.m.MeleeSkillAdd != 0)
		{
			ret.push({
				id = 10,
				type = "text",
				icon = "ui/icons/hitchance.png",
				text = "있다 " + ::MSU.Text.colorizeValue(this.m.MeleeSkillAdd, {AddSign = true, AddPercent = true}) + " 칠 기회"
			});
		}

		if (this.getMaxRange() > 2)
		{
			ret.push({
				id = 20,
				type = "text",
				icon = "ui/icons/warning.png",
				text = "명확한 경로가 필요하며 경로를 따라 높이 수준을 두 번 이상 변경할 수 없습니다."
			});
		}

		if (this.getContainer().getActor().getCurrentProperties().IsRooted)
		{
			ret.push({
				id = 9,
				type = "text",
				icon = "ui/tooltips/warning.png",
				text = ::MSU.Text.colorNegative("동안에는 사용할 수 없습니다. [속박|Concept.Rooted]")
			});
		}

		return ret;
	}}.getTooltip;

	q.onAnySkillUsed = @(__original) { function onAnySkillUsed( _skill, _targetEntity, _properties )
	{
		__original(_skill, _targetEntity, _properties);
		if (_skill == this)
		{
			if (!this.getContainer().getActor().isPlayerControlled())
			{
				_properties.MeleeSkill += this.m.MeleeSkillAdd;
				// this.m.HitChanceBonus is set by Modular Vanilla based on changes to _properties.MeleeSkill
			}
		}
	}}.onAnySkillUsed;

	q.getDestinationTile <- { function getDestinationTile( _targetTile, _originTile = null )
	{
		local myTile = this.getContainer().getActor().getTile();

		if (_originTile == null)
			_originTile = myTile;

		local function isTileEmpty( _tile )
		{
			// myTile is always considered empty because if _originTile is not the same as myTile
			// then we are calculating usability of Lunge from a different tile after having moved from myTile
			return _tile.IsEmpty || _tile.isSameTileAs(myTile);
		}

		// Destination has to be 1 tile closer than MaxRange because MaxRange targets an actor and we have to land next to him
		local maxDist = this.m.MaxRange - 1;
		local destTiles = [];

		foreach (destTile in ::MSU.Tile.getNeighbors(_targetTile).filter(@(_, _t) isTileEmpty(_t) && _t.getDistanceTo(_originTile) <= maxDist && ::Math.abs(_targetTile.Level - _t.Level) <= 1))
		{
			// If a destination tile is adjacent to us, always choose that first
			if (this.m.MaxRange == 2 || destTile.getDistanceTo(_originTile) == 1)
			{
				if (::Math.abs(_originTile.Level - destTile.Level) <= 1)
					return destTile;
			}
			else
			{
				// Destination tiles at a distance of 2 can only be chosen if they have an adjacent empty tile that is adjacent to _originTile
				// i.e. we have a clear path to the Destination tile AND along the path we never change height elevation more than once.
				if (::MSU.Tile.getNeighbors(destTile).filter(@(_, _t) isTileEmpty(_t) && _t.getDistanceTo(_originTile) == 1 && ::Math.abs(_originTile.Level - _t.Level) + ::Math.abs(_t.Level - destTile.Level) <= 1).len() != 0)
				{
					destTiles.push(destTile);
				}
			}
		}

		// No valid destination tile at a distance of 1. So, therefore, choose
		// the first valid clockwise destination tile at a distance of 2.
		if (destTiles.len() != 0)
			return destTiles[0];
	}}.getDestinationTile;

	q.onVerifyTarget = @() { function onVerifyTarget( _originTile, _targetTile )
	{
		return this.skill.onVerifyTarget(_originTile, _targetTile) && this.getDestinationTile(_targetTile, _originTile) != null;
	}}.onVerifyTarget;

	q.onUse = @() { function onUse( _user, _targetTile )
	{
		local destTile = this.getDestinationTile(_targetTile);

		if (destTile == null) return false;

		this.getContainer().setBusy(true);
		local tag = {
			Skill = this,
			User = _user,
			OldTile = _user.getTile(),
			TargetTile = _targetTile,
			OnRepelled = this.onRepelled
		};
		_user.spawnTerrainDropdownEffect(_user.getTile());
		::Tactical.getNavigator().teleport(_user, destTile, this.onTeleportDone.bindenv(this), tag, false, 3.0);
		return true;
	}}.onUse;
});
