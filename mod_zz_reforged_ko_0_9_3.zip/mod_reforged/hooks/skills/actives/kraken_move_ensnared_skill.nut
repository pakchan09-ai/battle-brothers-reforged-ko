::Reforged.HooksMod.hook("scripts/skills/actives/kraken_move_ensnared_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "이 캐릭터는 크라켄을 향해 끌려가고 있습니다!";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("매 턴마다 크라켄 쪽으로 이동합니다.")
		});
		return ret;
	}}.getTooltip;
});
