::Reforged.HooksMod.hook("scripts/skills/actives/line_breaker", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "그들을 당신의 길에서 밀어내고 앞으로 나아가며 그들의 대열을 무너뜨리세요.";
	}}.create;

	// Vanilla does not have a tooltip function for this skill.
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.getDefaultUtilityTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = "대상을 뒤로 밀고 해당 위치로 이동합니다."
		});
		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("Inflicts " + ::MSU.Text.colorNegative("10") + " 추가 [피로|Concept.Fatigue]")
		});

		if (this.getContainer().getActor().getCurrentProperties().IsRooted)
		{
			ret.push({
				id = 20,
				type = "text",
				icon = "ui/icons/warning.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorNegative("동안에는 사용할 수 없습니다. [속박|Concept.Rooted]"))
			});
		}

		return ret;
	}}.getTooltip;

	q.isUsable = @(__original) { function isUsable()
	{
		return __original() && !this.getContainer().getActor().getCurrentProperties().IsRooted;
	}}.isUsable;

	// Fixes vanilla issue where Line Breaker cannot push characters off ledges
	q.findTileToKnockBackTo = @() { function findTileToKnockBackTo( _userTile, _targetTile )
	{
		local getValidTileInDir = function( _dir )
		{
			if (_targetTile.hasNextTile(_dir))
			{
				local tile = _targetTile.getNextTile(_dir);
				if (tile.IsEmpty && (tile.Level <= _targetTile.Level || tile.Level - _targetTile.Level == 1))
				{
					return tile;
				}
			}

			return null;
		}

		local dir = _userTile.getDirectionTo(_targetTile);
		local knockToTile = getValidTileInDir(dir);

		if (knockToTile != null) return knockToTile;

		local altdir = dir - 1 >= 0 ? dir - 1 : 5;
		knockToTile = getValidTileInDir(altdir);

		if (knockToTile != null) return knockToTile;

		altdir = dir + 1 <= 5 ? dir + 1 : 0;
		knockToTile = getValidTileInDir(altdir);
		
		if (knockToTile != null) return knockToTile;

		return null;
	}}.findTileToKnockBackTo;

	// We delay the onFollow of this skill by another 100ms because otherwise the entity doesn't follow through with this function properly when at very high speeds using some faster combat speed mods
	q.onFollow = @(__original) { function onFollow( _tag )
	{
		if (::Time.getVirtualSpeed() > 2)
		{
			::Time.scheduleEvent(::TimeUnit.Virtual, 100, __original, _tag);
		}
		else
		{
			__original(_tag);
		}
	}}.onFollow;
});
