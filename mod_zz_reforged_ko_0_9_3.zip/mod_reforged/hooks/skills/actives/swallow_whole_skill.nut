::Reforged.HooksMod.hook("scripts/skills/actives/swallow_whole_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "인접한 대상을 통째로 집어삼켜라!";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("목표물이 뱃속으로 들어가서 [$ $|Skill+swallowed_whole_effect] 효과")
		});
		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/bravery.png",
			text = ::Reforged.Mod.Tooltips.parseString("표적의 [사기|Concept.Morale] 로 설정되어 있습니다 [동요|Concept.Morale]")
		});
		// ret.push({
		// 	id = 12,
		// 	type = "text",
		// 	icon = "ui/icons/special.png",
		// 	text = ::Reforged.Mod.Tooltips.parseString("The target loses the [$ $|Skill+shieldwall_effect], [$ $|Skill+spearwall_effect] and [$ $|Skill+riposte_effect] effects")
		// });
		return ret;
	}}.getTooltip;
});
