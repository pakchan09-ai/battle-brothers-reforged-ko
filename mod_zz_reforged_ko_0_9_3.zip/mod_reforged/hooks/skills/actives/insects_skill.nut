::Reforged.HooksMod.hook("scripts/skills/actives/insects_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "곤충 떼를 소환하여 적을 둘러싸 전투 집중력을 저하시킵니다!";
		this.m.IconDisabled = "skills/active_69_sw.png";	// Vanilla: skills/active_32_sw.png
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("대상은 다음을 얻습니다. [$ $|Skill+insect_swarm_effect] 효과")
		});
		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/vision.png",
			text = "다양한 범위를 가지고 있습니다 " + ::MSU.Text.colorizeValue(this.getMaxRange()) + " tiles"
		});
		return ret;
	}}.getTooltip;
});
