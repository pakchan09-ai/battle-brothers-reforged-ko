::Reforged.HooksMod.hook("scripts/skills/actives/tail_slam_split_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla has the name Tail Slam for this skill which is the same as the name for tail_slam_skill
		// We give it a unique name to help differentiate the two skills
		this.m.Name = "테일 스플릿";
		// Vanilla is missing a description for this skill
		this.m.Description = "직선으로 두 개의 타일을 공격할 수 있는 넓게 휘두르는 오버헤드 공격으로 꼬리를 내리칩니다.";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.getDefaultTooltip();
		ret.extend([
			{
				id = 10,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("무작위로 [멍해짐|Skill+dazed_effect] 또는 [기절시키다|Skill+stunned_effect] 목표")
			}
		]);
		return ret;
	}}.getTooltip;
});
