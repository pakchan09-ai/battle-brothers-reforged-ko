::Reforged.HooksMod.hook("scripts/skills/actives/nightmare_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "당신의 목표를 악몽의 세계로 뛰어들게 하고 그들이 잠든 동안 그들의 영혼을 포식하십시오!";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/vision.png",
			text = "다양한 범위를 가지고 있습니다 " + ::MSU.Text.colorizeValue(this.getMaxRange()) + " tiles"
		});
		ret.push({
			id = 20,
			type = "text",
			icon = "ui/icons/warning.png",
			text = ::Reforged.Mod.Tooltips.parseString("다음에서만 사용할 수 있습니다. [$ $|Skill+sleeping_effect] 목표")
		});
		return ret;
	}}.getTooltip;

	q.onAnySkillUsed = @(__original) function( _skill, _targetEntity, _properties )
	{
		__original(_skill, _targetEntity, _properties)
		if (_skill == this)
		{
			// VanillaFix: Vanilla does not set the Armor Damage of this skill to 0 (unlike they do on Puncture), which causes a confusing skill tooltip
			_properties.DamageArmorMult *= 0.0;
		}
	}
});
