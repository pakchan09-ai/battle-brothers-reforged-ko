::Reforged.HooksMod.hook("scripts/skills/actives/tail_slam_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "꼬리를 위에서 힘차게 내리쳐 목표물을 산산조각내세요.";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.getDefaultTooltip();
		ret.extend([
			{
				id = 10,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("무작위로 [멍해짐|Skill+dazed_effect], [기절시키다|Skill+stunned_effect] 아니면 목표물을 밀어내거나")
			}
		]);
		return ret;
	}}.getTooltip;
});
