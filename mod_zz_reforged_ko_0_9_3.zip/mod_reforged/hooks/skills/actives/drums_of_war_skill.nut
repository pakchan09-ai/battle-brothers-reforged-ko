::Reforged.HooksMod.hook("scripts/skills/actives/drums_of_war_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "격렬한 리듬을 타면 아군이 덜 피곤하고 전투에 더 열의를 갖게 됩니다.";
	}}.create;

	// Vanilla doesn't have a getTooltip function defined for this skill
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/fatigue.png",
			text = ::Reforged.Mod.Tooltips.parseString("전장에 있는 다른 모든 아군은 다음을 얻습니다. [$ $|Skill+drums_of_war_effect] 효과")
		});
		return ret;
	}}.getTooltip;
});
