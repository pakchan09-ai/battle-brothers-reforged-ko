::Reforged.HooksMod.hook("scripts/skills/actives/taunt", function(q) {
	// This field is referenced in taunted_effect so if we change/delete it here we'll have to update that code too
	q.m.DefenseModifierFraction <- 0.2;	// This percentage of the users resolve is removed from the targets defense
	q.m.MaxRangeForDefenseDebuff <- 1;	// The target of your taunt must be at most this many tiles from you to receive the defense debuff

	q.getTooltip = @(__original) { function getTooltip()
	{
		local ret = __original();

		if (this.m.DefenseModifierFraction != 0)
		{
			if (::MSU.isEqual(this.getContainer().getActor(), ::MSU.getDummyPlayer()))
			{
				ret.push({
					id = 10,
					type = "text",
					icon = "ui/icons/special.png",
					text = ::Reforged.Mod.Tooltips.parseString("인접한 대상에게 사용하면 감소합니다. [근접 방어|Concept.MeleeDefense] 그리고 [원거리 방어|Concept.RangeDefense] 에 의해 " + ::MSU.Text.colorizePct(this.m.DefenseModifierFraction) + " 당신의 현재 [의지|Concept.Bravery]")
				});
			}
			else
			{
				ret.push({
					id = 10,
					type = "text",
					icon = "ui/icons/special.png",
					text = ::Reforged.Mod.Tooltips.parseString("인접한 대상에게 사용하면 감소합니다. [근접 방어|Concept.MeleeDefense] 그리고 [원거리 방어|Concept.RangeDefense] 에 의해 " + ::MSU.Text.colorizeValue(this.calculateDefenseModifier()) + " (" + ::MSU.Text.colorizePct(this.m.DefenseModifierFraction) + " 당신의 현재 [의지|Concept.Bravery])")
				});
			}
		}

		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/vision.png",
			text = "다양한 범위를 가지고 있습니다 " + ::MSU.Text.colorizeValue(this.getMaxRange()) + " tiles",
		});

		return ret;
	}}.getTooltip;

	q.onVerifyTarget = @(__original) { function onVerifyTarget( _originTile, _targetTile )
	{
		local ret = __original(_originTile, _targetTile);
		if (ret && _targetTile.getEntity().getSkills().hasSkill("effects.taunted"))	return false;
		return ret;
	}}.onVerifyTarget;

	q.onUse = @(__original) { function onUse( _user, _targetTile )
	{
		local ret = __original(_user, _targetTile);
		if (!ret) return ret;

		local target = _targetTile.getEntity();
		if (this.getContainer().getActor().getTile().getDistanceTo(_targetTile) <= this.m.MaxRangeForDefenseDebuff)
		{
			local tauntEffect = target.getSkills().getSkillByID("effects.taunted");
			tauntEffect.m.DefenseModifier = this.calculateDefenseModifier();
		}
		target.getSkills().update();	// Otherwise the defense debuff will not be immediately visible in the combat tooltip

		return true;
	}}.onUse;

// New Functions
	q.calculateDefenseModifier <- { function calculateDefenseModifier()
	{
		local defenseModifier = -1.0 * this.m.DefenseModifierFraction * this.getContainer().getActor().getCurrentProperties().getBravery();
		return ::Math.min(0, defenseModifier);	// This modifier may never be positive
	}}.calculateDefenseModifier;
});
