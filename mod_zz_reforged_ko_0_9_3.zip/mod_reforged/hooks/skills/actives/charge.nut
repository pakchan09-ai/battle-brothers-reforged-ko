::Reforged.HooksMod.hook("scripts/skills/actives/charge", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		// Vanilla is missing a description for this skill
		this.m.Description = "앞으로 몸을 던져 압도적인 힘으로 적과 충돌하세요!";
	}}.create;

	// Vanilla has a getTooltip function defined for this skill but it doesn't provide all the details
	// so we overwrite it to produce a better tooltip overall
	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.getDefaultUtilityTooltip();
		ret.extend([
			{
				id = 10,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("대상 타일로 이동")
			},
			{
				id = 11,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("있다 " + ::MSU.Text.colorPositive("100%") + " 도착 시 인접한 무작위 적을 기절시킬 확률은 대상의 방패와 방어력에 의해 감소됩니다. [$ $|Skill+shieldwall_effect]")
			},
			{
				id = 12,
				type = "text",
				icon = "ui/icons/vision.png",
				text = "다양한 범위를 가지고 있습니다 " + ::MSU.Text.colorizeValue(this.getMaxRange()) + " tiles"
			}
		]);

		if (this.getContainer().getActor().isEngagedInMelee())
		{
			ret.push({
				id = 20,
				type = "text",
				icon = "ui/icons/warning.png",
				text = ::Reforged.Mod.Tooltips.parseString("이 캐릭터는 다음과 같으므로 사용할 수 없습니다. [교전 중|Concept.ZoneOfControl] 근접전에서")
			});
		}

		return ret;
	}}.getTooltip;
});
