::Reforged.HooksMod.hook("scripts/skills/perks/perk_mastery_cleaver", function(q) {
	q.onAdded = @(__original) { function onAdded()
	{
		__original();
		this.getContainer().add(::Reforged.new("scripts/skills/perks/perk_rf_bloodlust", function(o) {
			o.m.IsRefundable = false;
			o.m.IsSerialized = false;
		}));
	}}.onAdded;

	q.onRemoved = @(__original) { function onRemoved()
	{
		__original();
		this.getContainer().removeByStackByID("perk.rf_bloodlust");
	}}.onRemoved;

	q.onTargetHit = @(__original) { function onTargetHit( _skill, _targetEntity, _bodyPart, _damageInflictedHitpoints, _damageInflictedArmor )
	{
		__original(_skill, _targetEntity, _bodyPart, _damageInflictedHitpoints, _damageInflictedArmor);
		if (!_targetEntity.isAlive() || _damageInflictedHitpoints < ::Const.Combat.MinDamageToApplyBleeding || _targetEntity.getCurrentProperties().IsImmuneToBleeding || !this.isSkillValid(_skill))
			return;

		if (!this.RF_isNewSkillUseOrEntity(_targetEntity))
			return;

		_targetEntity.getSkills().add(::new("scripts/skills/effects/bleeding_effect"));
	}}.onTargetHit;

	q.onQueryTooltip = @(__original) { function onQueryTooltip( _skill, _tooltip )
	{
		__original(_skill, _tooltip);

		if (this.isSkillValid(_skill))
		{
			_tooltip.push({
				id = 100,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("추가 피해를 입힌다 [$ $|Skill+bleeding_effect] 때문에 " + ::Reforged.NestedTooltips.getNestedPerkName(this) + " 적어도 거래할 때 " + ::MSU.Text.color(::Const.UI.Color.DamageValue, ::Const.Combat.MinDamageToApplyBleeding) + " 손상 [체력|Concept.Hitpoints]")
			});
		}
	}}.onQueryTooltip;

	q.isSkillValid <- { function isSkillValid( _skill )
	{
		if (!_skill.isAttack())
			return false;

		local weapon = _skill.getItem();
		return !::MSU.isNull(weapon) && weapon.isItemType(::Const.Items.ItemType.Weapon) && weapon.isWeaponType(::Const.Items.WeaponType.Cleaver);
	}}.isSkillValid;
});
