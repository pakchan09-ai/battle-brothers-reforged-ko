::Reforged.HooksMod.hook("scripts/skills/perks/perk_nine_lives", function(q) {
	// New Variables to tweak the behavior of this perk
	q.m.MinHP <- 11;
	q.m.MaxHP <- 15;

	q.create = @(__original) { function create()
	{
		__original();

		// This makes the perk now always show by default on top of characters while it is not procced yet
		this.m.IconMini = "perk_07_mini";
		this.addType(::Const.SkillType.StatusEffect);	// 'StatusEffect' is requires so that this will show up under the 'Effects' section in the tooltip
	}}.create;

	// Nine lives now shows up as an effect while available. Therefore we give it a custom more detailed description
	q.getDescription = @() { function getDescription()
	{
		return ::Reforged.Mod.Tooltips.parseString("다음번 결정타를 받으면 이 캐릭터는 " + ::MSU.Text.colorPositive(this.m.MinHP + "-" + this.m.MaxHP) + " [체력|Concept.Hitpoints], 시간이 지남에 따라 모든 피해 [효과|Concept.StatusEffect] 제거될 예정이며, [근접 공격|Concept.MeleeSkill], [근접 방어|Concept.MeleeDefense], [의지|Concept.Bravery] 그리고 [주도력|Concept.Initiative] 다음 시작일까지 증가됩니다. [턴|Concept.Turn].");
	}}.getDescription;

	q.setSpent = @(__original) { function setSpent( _f )
	{
		local proc = (_f && !this.m.IsSpent);
		__original(_f);
		if (proc) this.onProc();
	}}.setSpent;

	q.onCombatFinished = @(__original) { function onCombatFinished()
	{
		this.m.IsHidden = false;
		__original();
	}}.onCombatFinished;

	// New function that is called after vanilla just applied the 11-15 hitpoints reset, removal of Dots and addition of the temporary nine_lives_effect
	q.onProc <- { function onProc()
	{
		this.m.IsHidden = true;	 // Visually indicate that this character no longer has cheat-death for this battle
		if (this.m.MinHP == 11 && this.m.MaxHP == 15) return; // There is no need to set the Hitpoints two times if these values were not changes by us/submods

		this.getContainer().getActor().m.Hitpoints = ::Math.rand(this.m.MinHP, this.m.MaxHP);
		this.getContainer().getActor().setDirty(true);
	}}.onProc;
});
