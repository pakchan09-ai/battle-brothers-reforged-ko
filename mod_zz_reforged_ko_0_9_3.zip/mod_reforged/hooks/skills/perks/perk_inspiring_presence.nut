::Reforged.HooksMod.hook("scripts/skills/perks/perk_inspiring_presence", function(q) {
	q.m.IsForceEnabled <- false;

	q.create = @(__original) { function create()
	{
		__original();
		this.m.Description = "이 캐릭터는 전장에서 영감을 주는 존재감을 가지고 있습니다.";
		this.m.Type = ::Const.SkillType.Perk | ::Const.SkillType.StatusEffect;
		this.m.Icon = "ui/perks/perk_rf_inspiring_presence.png";
		this.m.IconMini = "perk_rf_inspiring_presence_mini";
	}}.create;

	q.isHidden = @() { function isHidden()
	{
		return !this.isEnabled();
	}}.isHidden;

	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("시작하는 동맹국 [턴|Concept.Turn] 이 문자에 인접해 있는 경우 [교전 중|Concept.ZoneOfControl] 근접전 중이거나 아군과 인접해 있습니다. [교전 중|Concept.ZoneOfControl] 근접전에서는 [$ $|Skill+rf_inspiring_presence_buff_effect] 효과")
		});
		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/warning.png",
			text = ::Reforged.Mod.Tooltips.parseString("이 경우 동일한 파벌 구성원만 동맹으로 간주됩니다. [퍽|Concept.Perk]")
		});
		return ret;
	}}.getTooltip;

	q.isEnabled <- { function isEnabled()
	{
		if (this.m.IsForceEnabled)
		{
			return true;
		}

		local weapon = this.getContainer().getActor().getMainhandItem();
		if (weapon != null && weapon.getID().find("banner") != null)
		{
			return true;
		}

		return false;
	}}.isEnabled;

	// Overwrite the vanilla function to be empty.
	q.onCombatStarted = @() { function onCombatStarted()
	{
	}}.onCombatStarted;
});
