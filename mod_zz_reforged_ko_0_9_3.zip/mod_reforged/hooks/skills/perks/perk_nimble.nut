::Reforged.HooksMod.hook("scripts/skills/perks/perk_nimble", function(q) {
	q.m.StaminaModifierThresholdMult <- 0.15;
	q.m.WeightThresholdMin <- 15;	// This perks weight threshold can never be lower than this

	q.isHidden = @() { function isHidden()
	{
		return ::Math.floor(this.getHitpointsDamage() * 100) >= 100 && ::Math.floor(this.getArmorDamage() * 100) >= 100;
	}}.isHidden;

	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getTooltip();
		local hpBonus = ::Math.round(this.getHitpointsDamage() * 100);
		if (hpBonus < 100)
		{
			ret.push({
				id = 10,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("손상 [체력|Concept.Hitpoints] 공격으로 인한 피해는 다음과 같이 감소합니다. " + ::MSU.Text.colorPositive((100-hpBonus) + "%"))
			});
		}
		local armorBonus = ::Math.round(this.getArmorDamage() * 100);
		if (armorBonus < 100)
		{
			ret.push({
				id = 11,
				type = "text",
				icon = "ui/icons/special.png",
				text = "공격으로 인한 갑옷의 피해는 다음과 같이 감소합니다. " + ::MSU.Text.colorPositive((100-armorBonus) + "%")
			});
		}

		if (hpBonus >= 100 && armorBonus >= 100)
		{
			ret.push({
				id = 20,
				type = "text",
				icon = "ui/tooltips/warning.png",
				text = ::MSU.Text.colorNegative("이 캐릭터의 몸체와 머리 방어구는 너무 무거워서 어떤 이점도 얻을 수 없습니다. " + this.m.Name)
			});
		}

		ret.push({
			id = 12,
			type = "text",
			icon = "ui/icons/rf_reach.png",
			text = ::Reforged.Mod.Tooltips.parseString("1 무시 [리치 열세|Concept.ReachAdvantage] 낮은 대상을 공격할 때 [주도력|Concept.Initiative] 당신보다")
		});

		local actor = this.getContainer().getActor();
		if (!::MSU.isEqual(actor, ::MSU.getDummyPlayer()))
		{
			local maxHPString = ::Math.floor(actor.getHitpointsMax() / (hpBonus * 0.01));
			local currHPString = ::Math.floor(actor.getHitpoints() / (hpBonus * 0.01));

			ret.push({
				id = 13,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::MSU.Text.colorPositive("유효 체력: ") + currHPString + " / " + maxHPString
			});

			ret.push({
				id = 14,
				type = "text",
				icon = "ui/icons/fatigue.png",
				text = format("머리와 몸통 갑옷의 무게를 합친 것보다 효과가 떨어집니다. %i (현재: %i)", this.getStaminaModifierThreshold(), -actor.getItems().getStaminaModifier([::Const.ItemSlot.Body, ::Const.ItemSlot.Head]))
			});
		}

		return ret;
	}}.getTooltip;

	q.getHitpointsDamage <- { function getHitpointsDamage()
	{
		local fat = this.getContainer().getActor().getItems().getStaminaModifier([::Const.ItemSlot.Body, ::Const.ItemSlot.Head]);
		fat = ::Math.min(0, fat + this.getStaminaModifierThreshold());
		return ::Math.minf(1.0, 1.0 - 0.5 + ::Math.pow(::Math.abs(fat), 1.23) * 0.01);
	}}.getHitpointsDamage;

	q.getArmorDamage <- { function getArmorDamage()
	{
		local fat = this.getContainer().getActor().getItems().getStaminaModifier([::Const.ItemSlot.Body, ::Const.ItemSlot.Head]);
		fat = ::Math.min(0, fat + this.getStaminaModifierThreshold());
		return ::Math.minf(1.0, 1.0 - 0.25 + ::Math.pow(::Math.abs(fat), 1.23) * 0.01);
	}}.getArmorDamage;

	q.onBeforeDamageReceived = @() { function onBeforeDamageReceived( _attacker, _skill, _hitInfo, _properties )
	{
		if (_attacker != null && _attacker.getID() == this.getContainer().getActor().getID() || _skill == null || !_skill.isAttack() || !_skill.isUsingHitchance())
		{
			return;
		}

		_properties.DamageReceivedRegularMult *= this.getHitpointsDamage();
		_properties.DamageReceivedArmorMult *= this.getArmorDamage();
	}}.onBeforeDamageReceived;

	q.onAnySkillUsed = @() { function onAnySkillUsed( _skill, _targetEntity, _properties )
	{
		if (!this.isHidden() && _targetEntity != null && _skill.isAttack() && !_skill.isRanged() && _targetEntity.getInitiative() < this.getContainer().getActor().getInitiative())
		{
			_properties.OffensiveReachIgnore += 1;
		}
	}}.onAnySkillUsed;

	q.getStaminaModifierThreshold <- { function getStaminaModifierThreshold()
	{
		local b = this.getContainer().getActor().getBaseProperties().getClone();
		local wasUpdating = this.getContainer().m.IsUpdating;
		this.getContainer().m.IsUpdating = true;
		foreach (trait in this.getContainer().getSkillsByFunction(@(s) s.isType(::Const.SkillType.Trait) || s.isType(::Const.SkillType.PermanentInjury)))
		{
			trait.onUpdate(b);
		}
		this.getContainer().m.IsUpdating = wasUpdating;
		return ::Math.max(this.m.WeightThresholdMin, this.m.StaminaModifierThresholdMult * b.Stamina * (b.StaminaMult >= 0 ? b.StaminaMult : 1.0 / b.StaminaMult));
	}}.getStaminaModifierThreshold;
});
