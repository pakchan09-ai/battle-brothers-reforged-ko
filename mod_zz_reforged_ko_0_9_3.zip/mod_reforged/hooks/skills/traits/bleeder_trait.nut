::Reforged.HooksMod.hook("scripts/skills/traits/bleeder_trait", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		this.m.Description = "이 캐릭터는 출혈을 일으키기 쉬우며 대부분의 다른 캐릭터보다 출혈을 더 많이 합니다."; // "more than" as opposed to vanilla "longer than"
	}}.create;

	q.onUpdate = @(__original) { function onUpdate( _properties )
	{
		__original(_properties);
		_properties.RF_BleedingEffectMult *= 2.0;
	}}.onUpdate;

	q.getPerkGroupMultiplier = @() { function getPerkGroupMultiplier( _groupID, _perkTree )
	{
		switch (_groupID)
		{
			case "pg.rf_vigorous":
				return 0;
		}
	}}.getPerkGroupMultiplier;

	q.getTooltip = @(__original) { function getTooltip()
	{
		local ret = __original();
		foreach (entry in ret)
		{
			if (entry.id == 10)
			{
				entry.text = ::Reforged.Mod.Tooltips.parseString("효과 [$ $|Skill+bleeding_effect] 이다 " + ::MSU.Text.colorNegative("doubled"));
				break;
			}
		}
		return ret;
	}}.getTooltip;
});
