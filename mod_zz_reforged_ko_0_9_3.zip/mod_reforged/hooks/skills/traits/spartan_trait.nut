::Reforged.HooksMod.hook("scripts/skills/traits/spartan_trait", function(q) {
	q.getTooltip = @(__original) { function getTooltip()
	{
		local ret = __original();

		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/asset_daily_food.png",
			text = "소비하다 " + ::MSU.Text.colorPositive("-1") + " 매일 음식"
		});

		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/asset_daily_food.png",
			text = "패배 " + ::MSU.Text.colorPositive("50%") + " 배가 고파서 기분이 나빠진다"
		});

		return ret;
	}}.getTooltip;

	q.getPerkGroupMultiplier = @() { function getPerkGroupMultiplier( _groupID, _perkTree )
	{
		switch (_groupID)
		{
			case "pg.rf_tough":
			case "pg.rf_vigorous":
				return 0.5;
		}
	}}.getPerkGroupMultiplier;
});
