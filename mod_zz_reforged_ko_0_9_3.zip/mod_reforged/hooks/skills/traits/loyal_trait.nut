::Reforged.HooksMod.hook("scripts/skills/traits/loyal_trait", function(q) {
	q.getTooltip = @(__original) { function getTooltip()
	{
		local ret = __original();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/asset_money.png",
			text = ::MSU.Text.colorPositive("50%") + " 기분이 좋지 않을 때 탈영할 가능성이 적습니다."
		});
		return ret;
	}}.getTooltip;
});
