::Reforged.HooksMod.hook("scripts/skills/traits/disloyal_trait", function(q) {
	q.getTooltip = @(__original) { function getTooltip()
	{
		local ret = __original();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/asset_money.png",
			text = ::MSU.Text.colorNegative("100%") + " 기분이 좋지 않을 때 탈영할 가능성이 더 높음"
		});
		return ret;
	}}.getTooltip;

	q.getPerkGroupMultiplier = @() { function getPerkGroupMultiplier( _groupID, _perkTree )
	{
		switch (_groupID)
		{
			case "pg.special.rf_leadership":
				return 0;
		}
	}}.getPerkGroupMultiplier;
});
