::Reforged.HooksMod.hook("scripts/skills/skill", function(q) {
	q.m.__RF_SkillCount <- 0;
	q.m.__RF_LastTargetID <- 0;
	q.m.__RF_LastAttackerID <- 0;

	// Is used to prevent effects from triggering multiple times from multiple hits/misses in the same attack.
	// The logic is derived from how vanilla does it in perk_overwhelm.
	// Returns true if Const.SkillCounter has progressed since last time this function was called OR if the target is different.
	// Returns false otherwise.
	// Note for use: When using inside a function, this should be called as late as possible but IMMEDIATELY BEFORE
	// applying the effects for which it is intended to prevent them from triggering multiple times.
	// Pass `_false` for `_isAttacker` when the skill user is the actor of this skill and the target is `_entity`.
	// Pass `true` for `_isAttacker` if the actor of this skill is the target and `_entity` is the attacker.
	q.RF_isNewSkillUseOrEntity <- { function RF_isNewSkillUseOrEntity( _entity, _isAttacker = false )
	{
		local id = _entity == null ? 0 : _entity.getID();
		if (::Const.SkillCounter == this.m.__RF_SkillCount && id == (_isAttacker ? this.m.__RF_LastAttackerID : this.m.__RF_LastTargetID))
		{
			return false;
		}

		this.m.__RF_SkillCount = ::Const.SkillCounter;
		if (_isAttacker)
		{
			this.m.__RF_LastAttackerID = id;
		}
		else
		{
			this.m.__RF_LastTargetID = id;
		}

		return true;
	}}.RF_isNewSkillUseOrEntity;

	q.onSkillsUpdated <- { function onSkillsUpdated()
	{
	}}.onSkillsUpdated;

	q.isDuelistValid <- { function isDuelistValid()
	{
		return this.isAttack() && !this.isRanged() && !this.isAOE() && this.getBaseValue("MaxRange") == 1;
	}}.isDuelistValid;

	q.getHitFactors = @(__original) { function getHitFactors( _targetTile )
	{
		local ret = __original(_targetTile);
		for (local index = (ret.len() - 1); index >= 0; index--)	// We traverse it in reverse because we want to remove entries during the loop
		{
			switch (ret[index].text)
			{
				// For these entries we switch out the Icon for a better one
				case "Immune to stun":
				case "Immune to being rooted":
				case "Immune to being disarmed":
				case "Immune to being knocked back or hooked":
					ret[index].icon = "ui/tooltips/warning.png";	// These cases should be a warnings and not hide in-between hit-chance lines
					break;

				// We remove these entries from ever displaying because they are mostly redundant and take away space
				case "Fast Adaption":		// This should be handled by the perk itself if it really feels like this information is important
				case "Armed with shield":	// Already displayed on the stats of the character and shield is visible
				case "Riposte":				// This has nothing to do with hitchance and there is already a mini-icon for it anyways
				case "Resistance against ranged weapons":	// This was never followed through for anything other than skeletons
				case "Resistance against piercing attacks":	// This was never followed through for anything other than skeletons
				case "Nighttime":			// Already displayed on the stats of the character and in the effects section
				case "On bad terrain":		// Terrain effects usually have their effects viewable in the actor tooltip
				case "Target on bad terrain":	// Terrain effects usually have their effects viewable in the actor tooltip
					ret.remove(index);
					break;

				// We add additional hit-chance numbers for some other entries
				case "Too close":
				case this.getName():
					if (this.m.HitChanceBonus == 0) break;	// MSU pushes a raw 'this.getName()' string sometimes even when HitChanceBonus is 0. Currently this is with ranged attacks based on AdditionalAccuracy
					if (this.m.HitChanceBonus < 0)
					{
						ret[index].text = ::MSU.Text.colorNegative(this.m.HitChanceBonus + "% ") + ret[index].text;
					}
					else
					{
						ret[index].text = ::MSU.Text.colorPositive(this.m.HitChanceBonus + "% ") + ret[index].text;
					}
					break;

				case "Height disadvantage":
					ret[index].text = ::MSU.Text.colorNegative((::Const.Combat.LevelDifferenceToHitMalus * (_targetTile.Level - this.m.Container.getActor().getTile().Level)) + "% ") + " 키 단점";
					break;

				case "Height advantage":
					ret[index].text = ::MSU.Text.colorPositive(::Const.Combat.LevelDifferenceToHitBonus + "% ") + " 신장 이점";
					break;
				case "Surrounded":
					if (_targetTile.IsOccupiedByActor)
					{
						local bonus = this.getContainer().getActor().getSurroundedBonus(_targetTile.getEntity());
						if (bonus > 0) ret[index].text = ::MSU.Text.colorPositive(bonus + "%") + " Surrounded";
					}
					break;

			}
		}

		// New Entries
		if (!this.m.IsShieldRelevant && _targetTile.IsOccupiedByActor && _targetTile.getEntity().isArmedWithShield())
		{
			local shield = _targetTile.getEntity().getItems().getItemAtSlot(::Const.ItemSlot.Offhand);
			local bonus = (this.isRanged()) ? shield.getRangedDefenseBonus() : shield.getMeleeDefenseBonus();
			if (bonus > 0)
			{
				ret.push({
					icon = "ui/tooltips/positive.png",
					text = ::MSU.Text.colorPositive(bonus + "%") + " 쉴드 무시"
				});
			}
		}

		if (this.isAttack() && _targetTile.IsOccupiedByActor)
		{
			local target = _targetTile.getEntity();
			if (!target.getCurrentProperties().IsImmuneToHeadshots && (!::MSU.isIn("IsHeadless", target.m, true) || !target.m.IsHeadless))
			{
				local p = this.getContainer().buildPropertiesForUse(this, target);
				local headshotChance = p.getHitchance(::Const.BodyPart.Head);
				if (headshotChance <= 0)
				{
					ret.push({
						icon = "ui/icons/chance_to_hit_head.png",
						text = format("머리를 칠 기회가 없어")
					});
				}
				else
				{
					local headshotDamageMult = target.getCurrentProperties().IsImmuneToCriticals ? 1.0 : p.DamageAgainstMult[::Const.BodyPart.Head];
					ret.push({
						icon = "ui/icons/chance_to_hit_head.png",
						text = format("%s 머리를 맞힐 기회 %s 손상", ::MSU.Text.colorizeValue(headshotChance, {AddPercent = true}), ::MSU.Text.colorizeMultWithText(headshotDamageMult))
					});
				}
			}
		}

		return ret;
	}}.getHitFactors;

	q.isTargeted = @() { function isTargeted()
	{
		if (this.m.IsTargeted)
			return true;

		// If ConfirmSkillUse is enabled then we treat all skills as Targeted unless user is pressing the keybind
		if (::Reforged.Mod.ModSettings.getSetting("ConfirmSkillUse").getValue())
		{
			return !::Reforged.Mod.Keybinds.isKeybindPressed("ConfirmSkillUseKeybind");
		}

		// If ConfirmSkillUse is disabled then treat we all skills as Targeted when the user is pressing the keybind
		return ::Reforged.Mod.Keybinds.isKeybindPressed("ConfirmSkillUseKeybind");
	}}.isTargeted;
});

::Reforged.HooksMod.hookTree("scripts/skills/skill", function(q) {
	if (q.contains("create"))
	{
		q.create = @(__original) { function create()
		{
			__original();

			// VanillaFix: Some vanilla skills for AI entities have IconDisabled same as Icon or are missing IconDisabled
			// they are missing the _sw gfx in the game files. In Reforged we have created
			// _sw variants of those gfx and therefore we fix the IconDisabled to use the _sw variant
			if (this.m.Icon == this.m.IconDisabled || this.m.IconDisabled == "")
			{
				this.m.IconDisabled = ::String.replace(this.m.Icon, ".png", "_sw.png");
			}

			// VanillaFix: Some vanilla non-targeted skills such as `drums_of_war_skill`
			// have MinRange = 1. This causes issue with our ConfirmSkillUse setting
			// whereby NPCs get stuck in ai behaviors execution trying to use the skill
			// but being unable to target their own tile.
			// Players will suffer from the same problem with such skills.
			// This seems like a vanilla oversight in such skills because almost all
			// non-targeted skills in vanilla have both MinRange and MaxRange set to 0.
			if (!this.m.IsTargeted)
			{
				this.m.MinRange = 0;
				this.m.MaxRange = 0;
			}
		}}.create;
	}

	q.getTooltip = @(__original) { function getTooltip()
	{
		local ret = __original();

		if (::Tactical.isActive() && this.isActive() && !this.m.IsTargeted && ::Tactical.TurnSequenceBar.isActiveEntity(this.getContainer().getActor()))
		{
			ret.push({
				id = 100,
				type = "hint",
				icon = "ui/icons/rf_mouse_left_button_ctrl.png",
				text = format("보류 %s 선택할 때 %s",
								::Reforged.Mod.ModSettings.getSetting("ConfirmSkillUseKeybind").getValue(),
								::Reforged.Mod.ModSettings.getSetting("ConfirmSkillUse").getValue() ? "즉시 사용" : "미리보기 사용법")
			});
		}

		return ret;
	}}.getTooltip;

	q.onVerifyTarget = @(__original) { function onVerifyTarget( _userTile, _targetTile )
	{
		return this.m.IsTargeted ? __original(_userTile, _targetTile) : _userTile.isSameTileAs(_targetTile);
	}}.onVerifyTarget;
});

::Reforged.QueueBucket.Late.push(function() {
	::Reforged.HooksMod.hook("scripts/skills/skill", function(q) {
		// Ensure that skill always has a valid container during getTooltip
		// to prevent errors when getting tooltips of skills that aren't added to anyone.
		q.getTooltip = @(__original) { function getTooltip()
		{
			if (!::MSU.isNull(this.getContainer()))
				return __original();

			this.m.Container = ::MSU.getDummyPlayer().getSkills();
			local ret = __original();
			this.m.Container = null;
			return ret;
		}}.getTooltip;
	});
});
