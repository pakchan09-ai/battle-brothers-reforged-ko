::Reforged.HooksMod.hook("scripts/skills/special/night_effect", function(q) {
	q.m.HitChancePerTile <- -10;

	q.getTooltip = @(__original) { function getTooltip()
	{
		local ret = __original();
		foreach (entry in ret)
		{
			if (entry.id == 12 && entry.icon == "ui/icons/ranged_skill.png")
			{
				entry.text = "있다 " + ::MSU.Text.colorizeValue(this.m.HitChancePerTile, {AddSign = true, AddPercent = true}) + " 거리 타일당 적중 확률"
			}
		}
		return ret;
	}}.getTooltip;

	q.onGetHitFactors = @(__original) { function onGetHitFactors( _skill, _targetTile, _tooltip )
	{
		__original(_skill, _targetTile, _tooltip);

		if (_skill.isAttack() && _skill.isRanged() && !this.isHidden())
		{
			local malus = this.m.HitChancePerTile * (this.getContainer().getActor().getTile().getDistanceTo(_targetTile) - _skill.getMinRange());
			if (malus != 0)
			{
				_tooltip.push({
					icon = "ui/tooltips/negative.png",
					text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorizeValue(malus, {AddPercent = true}) + " [$ $|Skill+night_effect]")
				});
			}
		}
	}}.onGetHitFactors;

	q.onUpdate = @(__original) { function onUpdate( _properties )
	{
		local oldRangedSkillMult = _properties.RangedSkillMult;
		__original(_properties);
		_properties.RangedSkillMult = oldRangedSkillMult;	// Prevent Vanilla from changing the Ranged Skill

		if (_properties.IsAffectedByNight)
		{
			_properties.HitChanceAdditionalWithEachTile += this.m.HitChancePerTile;
		}
	}}.onUpdate;
});
