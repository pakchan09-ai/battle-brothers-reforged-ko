::Reforged.HooksMod.hook("scripts/scenarios/world/militia_scenario", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		local additionalDesc = "\n[color=#bcad8c]민병대:[/color] 모든 신병은 민병대 특전 그룹에 접근할 수 있습니다.";
		if (this.m.Description.slice(-4) == "[/p]")
		{
			this.m.Description = this.m.Description.slice(0, -4) + additionalDesc + "[/p]";
		}
		else
		{
			this.m.Description += additionalDesc;
		}
	}}.create;

	q.onBuildPerkTree = @(__original) { function onBuildPerkTree( _perkTree )
	{
		__original(_perkTree);

		// Instead of directly adding militia perk group, we iterate over its rows and add
		// the perks to the perk tree because some perks may have come from other perk groups
		// at tiers different from the tiers that militia perk group has them at.
		foreach (i, row in ::DynamicPerks.PerkGroups.findById("pg.rf_militia").getTree())
		{
			foreach (perkID in row)
			{
				if (_perkTree.hasPerk(perkID))
				{
					if (_perkTree.getPerkTier(perkID) == i + 1)
						continue;
					else
						_perkTree.removePerk(perkID);
				}
				_perkTree.addPerk(perkID, i + 1);
			}
		}
	}}.onBuildPerkTree;
});
