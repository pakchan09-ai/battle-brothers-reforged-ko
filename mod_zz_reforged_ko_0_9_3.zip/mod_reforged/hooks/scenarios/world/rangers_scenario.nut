::Reforged.HooksMod.hook("scripts/scenarios/world/rangers_scenario", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		local additionalDesc = "\n[color=#bcad8c]패스파인더:[/color] 모든 신병은 패스파인더 특전을 이용할 수 있습니다.";
		if (this.m.Description.slice(-4) == "[/p]")
		{
			this.m.Description = this.m.Description.slice(0, -4) + additionalDesc + "[/p]";
		}
		else
		{
			this.m.Description += additionalDesc;
		}
	}}.create;

	q.onBuildPerkTree = @(__original) { function onBuildPerkTree( _perkTree )
	{
		__original(_perkTree);
		// We remove it and add it so that it goes on the first tier
		if (_perkTree.hasPerk("perk.pathfinder"))
		{
			_perkTree.removePerk("perk.pathfinder");
		}
		_perkTree.addPerk("perk.pathfinder");
	}}.onBuildPerkTree;
});
