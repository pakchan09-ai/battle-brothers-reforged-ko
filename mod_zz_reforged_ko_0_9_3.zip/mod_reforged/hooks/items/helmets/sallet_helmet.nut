::Reforged.HooksMod.hook("scripts/items/helmets/sallet_helmet", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		this.m.Name = "오픈 페이스 샐릿 헬멧";
		this.m.Value = 1500; // vanilla 1200
		this.m.Condition = 125; // vanilla 120
		this.m.ConditionMax = 125; // vanilla 120
	}}.create;
});
