::Reforged.HooksMod.hook("scripts/items/armor/footman_armor", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		this.m.Description = "긴 메일 셔츠와 리벳이 박힌 가죽 감베손으로 구성된 임시 갑옷입니다."; // Fixes vanilla typo "rivetted" to "riveted".
	}}.create;
});
