::Reforged.HooksMod.hook("scripts/items/shields/special/craftable_lindwurm_shield", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		this.m.Condition = 200;
		this.m.ConditionMax = 200;
		// Similar description as vanilla but add mention of "weighs little" because our design of the shield
		// has a much lower stamina modifier than vanilla.
		this.m.Description = "린드부름의 반짝이는 비늘로 만든 이 견고한 방패는 무게가 가볍지만 거의 파괴할 수 없는 보호 기능을 제공합니다.";
		this.m.StaminaModifier = -8; // vanilla -14
		this.m.MeleeDefense = 20; // vanilla 17
		this.m.RangedDefense = 20; // vanilla 25
		this.m.ReachIgnore = 3;
	}}.create;
});
