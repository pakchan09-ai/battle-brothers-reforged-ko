::Reforged.HooksMod.hook("scripts/items/shields/special/craftable_kraken_shield", function(q) {
	q.m.ThreatModifier <- 10;

	q.create = @(__original) { function create()
	{
		__original();
		this.m.Condition = 220;
		this.m.ConditionMax = 220;
		this.m.ReachIgnore = 3;
	}}.create;

	q.getTooltip = @(__original) { function getTooltip()
	{
		local ret = __original();
		if (this.m.ThreatModifier != 0)
		{
			ret.push({
				id = 10,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("감소시킵니다 [의지|Concept.Bravery] 인접한 상대의 " + ::MSU.Text.colorNegative(10) + " 동안 [사기 판정|Concept.Morale]")
			});
		}
		return ret;
	}}.getTooltip;

	q.onUpdateProperties = @(__original) { function onUpdateProperties( _properties )
	{
		__original(_properties);
		_properties.Threat += this.m.ThreatModifier;
	}}.onUpdateProperties;
});
