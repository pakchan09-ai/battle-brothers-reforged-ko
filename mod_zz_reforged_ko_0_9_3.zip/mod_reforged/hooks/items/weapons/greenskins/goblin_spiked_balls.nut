::Reforged.HooksMod.hook("scripts/items/weapons/greenskins/goblin_spiked_balls", function(q) {
	q.m.IconLargeFull <- "weapons/ranged/goblin_weapon_07.png";		// Same as Vanilla
	q.m.IconFull <-	"weapons/ranged/goblin_weapon_07_70x70.png";	// Same as Vanilla
	q.m.IconLargeEmpty <- "weapons/ranged/rf_goblin_weapon_07_empty.png";
	q.m.IconEmpty <- "weapons/ranged/rf_goblin_weapon_07_empty_70x70.png";

	q.create = @(__original) { function create()
	{
		__original();
		this.m.Reach = 0;
	}}.create;

	q.setAmmo = @(__original) { function setAmmo( _a )
	{
		__original(_a);
		if (this.m.Ammo > 0)
		{
			this.m.Name = "가시 박힌 볼라 묶음";
			this.m.IconLarge = this.m.IconLargeFull;
			this.m.Icon = this.m.IconFull;
		}
		else
		{
			this.m.Name = "가시 박힌 볼라 묶음(비어 있음)";
			this.m.IconLarge = this.m.IconLargeEmpty;
			this.m.Icon = this.m.IconEmpty;
		}

		this.updateAppearance();
	}}.setAmmo;
});
