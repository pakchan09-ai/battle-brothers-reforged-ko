::Reforged.HooksMod.hook("scripts/contracts/contracts/return_item_contract", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		this.m.Name = "도난당한 물건을 돌려주세요";
	}}.create;

	q.createStates = @(__original) { function createStates()
	{
		__original();
		foreach (state in this.m.States)
		{
			if (state.ID != "Offer") continue;
			local end = state.end;
			state.end = function()
			{
				end();
				this.Contract.m.Target.setMovementSpeed(this.Contract.m.Target.getBaseMovementSpeed() * 0.9);  // Thieves are easier to catch
			}
			break;
		}
	}}.createStates;

	q.createScreens = @(__original) { function createScreens()
	{
		__original();
		foreach (screen in this.m.Screens)
		{
			if (screen.ID != "CounterOffer1") continue;
			foreach (option in screen.Options)
			{	// We now show the original payment so the player compare the two
				if (option.Text != "We\'re paid to return it, and that\'s what we\'ll do.") continue;
				option.Text = "우리는 돈을 받았습니다 %reward_completion% 그것을 돌려보내는 것, 그것이 우리가 할 일입니다.";
				break;
			}
			break;
		}
	}}.createScreens;

	q.onPrepareVariables = @(__original) { function onPrepareVariables( _vars )
	{
		__original(_vars);
		foreach (var in _vars)
		{
			if (var[0] != "bribe") continue;
			var[1] = "[b]" + var[1] + "[/b]";	 // Bribe is bold now so its easier to spot and compare
			break;
		}
	}}.onPrepareVariables;

	q.RF_getOriginText = @() { function RF_getOriginText()
	{
		return ::Reforged.Mod.Tooltips.parseString(format("도둑들의 흔적을 따라가 보세요 %s", ::MSU.isEqual(::World.State.getCurrentTown(), this.getHome()) ? "here" : ::Reforged.NestedTooltips.getNestedWorldEntityName(this.getHome())));
	}}.RF_getOriginText;
});
