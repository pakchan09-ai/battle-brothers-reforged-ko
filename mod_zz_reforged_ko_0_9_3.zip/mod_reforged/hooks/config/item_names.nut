// Vanilla Adjustments
::MSU.Array.removeValues(::Const.Strings.BillNames, [
	"바디시",	// There is already a vanilla weapon with this name
	"불즈"	// There is already a reforged weapon with this name
]);

::MSU.Array.removeValues(::Const.Strings.CrossbowNames, [
	"배신자"		// moved over to dagger names
]);
::Const.Strings.CrossbowNames.extend([
	"전갈",
	"쇠가늠쇠",
	"벼락",
	"까마귀때까치",
	"핏빛화살",
	"죽음의사격",
	"용의송곳니",
	"검은가시",
	"폭풍분쇄자",
	"강철바람"
]);

::MSU.Array.removeValues(::Const.Strings.DaggerNames, [
	"에스토크"		// We have our own actual Estoc item
]);
::Const.Strings.DaggerNames.extend([
	"배신자"		// formerly a crossbow name
]);

::Const.Strings.HandgonneNames.extend([
	"귀먹이는자",
	"강철굉음",
	"화산",
	"강철불꽃",
	"천둥총구",
	"폭풍불",
	"지옥불",
	"폭염"
]);

::Const.Strings.LongaxeNames.extend([
	"솎아내는자"
]);

::Const.Strings.SwordlanceNames.extend([	// In Vanilla this has only 2 entries
	"핏빛달",
	"구울의 베인",
	"영혼강타",
	"그림자수확자",
	"죽음의 손",
	"참혹한수확",
	"피폭풍",
	"전쟁인도자",
	"죽음바람"
]);

::MSU.Array.removeValues(::Const.Strings.WarbrandNames, [
	"크릭스메서",	// We have our own actual Kriegsmesser item
]);

::Const.Strings.WhipNames.extend([
	"노예감독",
	"덩굴손",
	"덩굴",
	"사혈자",
	"쇠못채찍",
	"가시채찍",
	"핏빛채찍"
]);

// Reforged Lists
::Const.Strings.RF_KriegsmesserNames <- [
	"크릭스메서",
	"절개자",
	"저미는칼",
	"절단자",
	"참수자",
	"약탈자",
	"피흘림",
	"피에굶주린자",
	"광기",
	"조각칼",
	"전쟁 식칼",
	"열상검",
	"파쇄자",
	"난도꾼",
	"훼손자",
	"불구자",
	"고문자",
	"분쇄자",
	"바이핸더",
	"칼날",
	"장검",
	"학살자",
	"정복자",
	"참수자",
	"재앙",
	"살점절단자",
	"살점분쇄자"
];

::Const.Strings.RF_LongswordNames <- [
	"베는칼",
	"저미는칼",
	"칼날",
	"절단자",
	"검",
	"죽음의집행자",
	"자비",
	"학살자",
	"검날",
	"전투검",
	"장검",
	"피흘림",
	"서약수호자",
	"희미한빛",
	"심판",
	"복수자",
	"레드 리버스",
	"독침",
	"번개",
	"타격자",
	"면도날",
	"검날",
	"바람칼",
	"쾌검",
	"조각칼",
	"복수",
	"명예",
	"정복자"
];
