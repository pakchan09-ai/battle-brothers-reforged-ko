::MSU.Table.merge(::Const.Strings.PerkName, {
	RF_Angler = "그물잡이",
	RF_BattleFervor = "전투의 열기",
	RF_BackToBasics = "기본으로 돌아가기",
	RF_CalculatedStrikes = "계산된 일격",
	RF_CheapTrick = "비열한 수",
	RF_Command = "지휘",
	RF_Skirmisher = "척후병",
	RF_BearDown = "몰아붙이기",
	RF_BestialVigor = "야수의 활력",
	RF_BetweenTheEyes = "미간 조준",
	RF_BetweenTheRibs = "갈비뼈 사이로",
	RF_Blitzkrieg = "전격전",
	RF_Bloodlust = "피의 갈망",
	RF_DeathDealer = "죽음의 집행자",
	RF_Bolster = "북돋우기",
	RF_BoneBreaker = "뼈 분쇄자",
	RF_Bully = "약자 사냥",
	RF_Bulwark = "철벽",
	RF_Finesse = "기교",
	RF_Centurion = "백인대장",
	RF_Combo = "연계 공격",
	RF_ConcussiveStrikes = "충격타",
	RF_Decanus = "십인대장",
	RF_Decisive = "결단력",
	RF_DeepCuts = "깊은 상처",
	RF_DeepImpact = "강력한 충격",
	RF_DentArmor = "갑옷 찌그러뜨리기",
	RF_DiscoveredTalent = "발견된 재능",
	RF_Dismantle = "해체",
	RF_Dismemberment = "사지 절단",
	RF_DoubleStrike = "이중 타격",
	RF_DynamicDuo = "환상의 짝",
	RF_EnGarde = "경계 자세",
	RF_Entrenched = "참호 사수",
	RF_ExploitOpening = "빈틈 공략",
	RF_ExudeConfidence = "넘치는 자신감",
	RF_FailedPotential = "좌절된 잠재력",
	RF_FamilyPride = "가문의 긍지",
	RF_Fencer = "펜싱의 달인",
	RF_FeralRage = "야성의 분노",
	RF_FlailSpinner = "도리깨 돌리기",
	RF_FlamingArrows = "불화살",
	RF_FollowUp = "후속 공격",
	RF_FormidableApproach = "위압적인 접근",
	RF_FreshAndFurious = "기세등등",
	RF_FromAllSides = "사방에서",
	RF_FruitsOfLabor = "노동의 결실",
	RF_Ghostlike = "유령 같은 몸놀림",
	RF_HaleAndHearty = "강건한 체질",
	RF_TrickstersPurses = "재주꾼의 주머니",
	RF_HipShooter = "속사",
	RF_HoldSteady = "대열 유지",
	RF_Hybridization = "복합 훈련",
	RF_Supporter = "지원병",
	InspiringPresence = "고무하는 존재감",
	RF_IronSights = "가늠쇠",
	RF_Kingfisher = "물총새",
	RF_KingOfAllWeapons = "만병의 왕",
	RF_Legatus = "군단장",
	RF_Leverage = "지렛대의 원리",
	RF_LineBreaker = "전열 돌파",
	RF_Poise = "균형 감각",
	RF_LongReach = "긴 사거리",
	RF_ManOfSteel = "강철의 사나이",
	RF_Marksmanship = "사격술",
	RF_Mauler = "강타자",
	RF_Menacing = "위협",
	RF_Mentor = "스승",
	RF_NailedIt = "정확히 꽂기",
	RF_OffhandTraining = "보조 손 훈련",
	RF_Opportunist = "기회주의자",
	RF_PassingStep = "엇걸음",
	RF_PatternRecognition = "패턴 파악",
	RF_Phalanx = "밀집 방진",
	RF_Professional = "직업 군인",
	RF_PromisedPotential = "유망한 잠재력",
	RF_Onslaught = "맹공",
	RF_Rattle = "동요시키기",
	RF_RealizedPotential = "개화한 잠재력",
	RF_Rebuke = "응수",
	RF_RisingStar = "떠오르는 신예",
	RF_Sanguinary = "피에 굶주린 자",
	RF_SavageStrength = "야만적인 힘",
	RF_SecondWind = "두 번째 숨결",
	RF_ShieldSergeant = "방패병 하사",
	RF_SmallTarget = "작은 표적",
	RF_SoulLink = "영혼의 연결",
	RF_SteadyBrace = "단단히 버티기",
	RF_StrengthInNumbers = "수적 우세",
	RF_SurvivalInstinct = "생존 본능",
	RF_SweepingStrikes = "휩쓸기",
	RF_SwiftStabs = "신속한 찌르기",
	RF_SwordmasterBladeDancer = "검무의 달인",
	RF_SwordmasterGrappler = "격투가",
	RF_SwordmasterJuggernaut = "거인",
	RF_SwordmasterMetzger = "도살자",
	RF_SwordmasterPrecise = "정밀한 검술",
	RF_SwordmasterReaper = "수확자",
	RF_SwordmasterVersatileSwordsman = "다재다능한 검사",
	RF_TargetPractice = "표적 연습",
	RF_Tempo = "완급 조절",
	RF_TerrifyingVisage = "공포스러운 모습",
	RF_TheRushOfBattle = "전투의 고양감",
	RF_ThroughTheGaps = "틈새 노리기",
	RF_ThroughTheRanks = "대열을 헤치고",
	RF_TrickShooter = "곡예 사격",
	RF_TripArtist = "발걸기 달인",
	RF_Unstoppable = "불굴",
	RF_Vanquisher = "정복자",
	RF_Retribution = "응징",
	RF_VengefulSpite = "복수심",
	RF_Vigilant = "경계심",
	RF_VigorousAssault = "맹렬한 공세",
	RF_WeaponMaster = "무기의 달인",
	RF_WearThemDown = "소모전",
	RF_WearsItWell = "갑옷 숙련",
	RF_WhirlingDeath = "회전하는 죽음"
});

local vanillaDescriptions = [
	{
		ID = "perk.battle_forged",
		Key = "BattleForged",
		Description = ::UPD.getDescription({
			Fluff = "중갑 착용에 특화된다.",
			Effects = [{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"현재 머리와 몸통 방어도의 합계에 " + ::MSU.Text.colorPositive("5%") + "를 곱한 값만큼 받는 방어구 피해가 백분율로 감소한다.",
					"[리치 열세|Concept.ReachDisadvantage]인 상대를 공격할 때 현재 머리와 몸통 방어도의 합계가 300일 때마다 열세가 1씩 줄어든다."
					"정신 공격이나 상태 효과로 받는 피해에는 적용되지 않는다.",
					"[$ $|Perk+perk_nimble] 또는 [$ $|Perk+perk_rf_poise] 보유 시 습득할 수 없다."
				]
			}]
		})
	},
	{
		ID = "perk.bullseye",
		Key = "Bullseye",
		Description = ::UPD.getDescription({
			Fluff = "수풀 속 두 마리보다 손안의 한 마리가 낫다.",
			Requirement = "원거리 무기",
			Effects = [{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"사선이 가려진 표적을 쏠 때 명중률 불이익이 기존 " + ::MSU.Text.colorNegative("75%") + "에서 " + ::MSU.Text.colorNegative("50%") + "로 줄어든다.",
					"엄폐하지 않은 표적을 공격할 때 방어구 관통률이 활 사용 시 " + ::MSU.Text.colorPositive("+10%") + "만큼, 다른 무기 사용 시 " + ::MSU.Text.colorPositive("+20%") + "만큼 증가한다."
				]
			}]
		})
	},
	{
		ID = "perk.rotation",
		Key = "Rotation",
		Description = ::UPD.getDescription({
			Fluff = "누가 용병은 춤을 못 춘다고 했나?",
			Effects = [{
				Type = ::UPD.EffectType.Active,
				Description = [
					"[$ $|Skill+rotation] 기술을 습득한다. [통제 구역|Concept.ZoneOfControl]을 무시하고 인접한 아군과 자리를 바꿀 수 있다.",
					"둘 중 하나라도 [$ $|Skill+stunned_effect], [$ $|Skill+rooted_effect] 또는 다른 행동 불능 상태라면 사용할 수 없다."
				]
			}]
		})
	},
	{
		ID = "perk.fearsome",
		Key = "Fearsome",
		Description = ::UPD.getDescription({
			Fluff = "적을 뿔뿔이 흩어 도망치게 하라!",
			Effects = [{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"발동을 위한 피해 임계값 [사기 판정|Concept.Morale] 당신의 공격으로 1로 감소합니다.",
					"이러한 사기 점검에는 이제 추가 페널티가 있습니다. [의지|Concept.Bravery] 의 " + ::MSU.Text.colorPositive("20%") + " 너의 [의지|Concept.Bravery]."
				]
			}]
		})
	},
	{
		ID = "perk.footwork",
		Key = "Footwork",
		Description = ::UPD.getDescription({
			Fluff = "상대 손아귀에서 미끄러지듯 벗어나라!",
			Effects = [
				{
					Type = ::UPD.EffectType.Active,
					Description = [
						"잠금을 해제합니다 [$ $|Skill+footwork] 떠날 수 있게 해주는 스킬 [통제 구역|Concept.ZoneOfControl] 무료 공격을 유발하지 않고."
					]
				},
				{
					Type = ::UPD.EffectType.Active,
					Description = [
						"잠금을 해제합니다 [$ $|Skill+rf_sprint_skill] 더 먼 거리를 이동할 수 있는 기술 [턴|Concept.Turn]."
					]
				}
			]
		})
	},
	{
		ID = "perk.rally_the_troops",
		Key = "RallyTheTroops",
		Description = ::UPD.getDescription({
			Fluff = "아군의 뿔나팔 소리는 언제나 전사들의 마음을 굳게 다잡아 준다.",
			Effects = [{
				Type = ::UPD.EffectType.Active,
				Description = [
					"잠금을 해제합니다 [$ $|Skill+rally_the_troops] 올릴 수 있는 스킬 [사기|Concept.Morale] 당신 진영의 모든 주변 동맹국을 안정적인 수준으로 유지합니다.",
					"높을수록 [의지|Concept.Bravery] 이 스킬을 사용하는 캐릭터가 성공할 확률이 높아집니다."
				]
			}]
		})
	},
	{
		ID = "perk.adrenaline",
		Key = "Adrenaline",
		Description = ::UPD.getDescription({
			Fluff = "핏줄을 타고 솟구치는 투지를 느껴라!",
			Effects = [{
				Type = ::UPD.EffectType.Active,
				Description = [
					"잠금을 해제합니다 [$ $|Skill+adrenaline_skill] 당신을 최우선으로 생각하는 기술 [턴|Concept.Turn] 다음 주문 [라운드|Concept.Round], 또 다른 [턴|Concept.Turn] 적들이 그러기 전에.",
					"의 영향으로 [$ $|Skill+adrenaline_effect] 받을 수 없으며 영향을 받지 않습니다. [일시적 부상|Concept.InjuryTemporary]."
				]
			}]
		})
	},
	{
		ID = "perk.anticipation",
		Key = "Anticipation",
		Description = ::UPD.getDescription({
			Fluff = "그럴 줄 알았지!",
			Effects = [{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"원거리 무기로 공격을 받을 때, " + ::MSU.Text.colorPositive("1 + 10%") + " 너의 [기본|Concept.BaseAttribute] [원거리 방어|Concept.RangeDefense] 추가로 [원거리 방어|Concept.RangeDefense] 공격자가 떨어져 있는 타일마다, 항상 최소한 " + ::MSU.Text.colorPositive("+10") + " + [원거리 방어|Concept.RangeDefense]."
				]
			}]
		})
	},
	{
		ID = "perk.bags_and_belts",
		Key = "BagsAndBelts",
		Description = ::UPD.getDescription({
			Fluff = "준비가 승리의 열쇠다.",
			Effects = [{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"두 개의 추가 잠금 해제 [가방 칸|Concept.BagSlots].",
					"에 배치된 항목 [가방|Concept.BagSlots] 더 이상 페널티를 적용하지 않습니다. [최대 피로|Concept.MaximumFatigue], 양손 무기는 제외."
				]
			}]
		})
	},
	{
		ID = "perk.taunt",
		Key = "Taunt",
		Description = ::UPD.getDescription({
			Fluff = "저 현란한 손놀림 좀 보라고!",
			Effects = [{
				Type = ::UPD.EffectType.Active,
				Description = [
					"잠금을 해제합니다 [$ $|Skill+taunt] 대상이 방어적인 행동 대신 공격적인 행동을 취하게 만들고, 잠재적으로 더 취약한 다른 캐릭터보다 도발하는 캐릭터를 공격하게 만드는 스킬입니다.",
					"인접한 대상에게 사용하면 대상이 감소합니다. [근접 방어|Concept.MeleeDefense] 그리고 [원거리 방어|Concept.RangeDefense] 에 의해 " + ::MSU.Text.colorPositive("20%") + " 사용자의 [의지|Concept.Bravery]."
				]
			}]
		})
	},
	{
		ID = "perk.recover",
		Key = "Recover",
		Description = ::UPD.getDescription({
			Fluff = "영영 목을 잃느니 잠시 숨을 돌리는 게 낫다.",
			Effects = [{
				Type = ::UPD.EffectType.Active,
				Description = [
					"잠금을 해제합니다 [$ $|Skill+recover_skill] 휴식을 취할 수 있게 해주는 스킬 [턴|Concept.Turn] 누적을 줄이기 위해 [피로|Concept.Fatigue]."
				]
			}]
		})
	},
	{
		ID = "perk.underdog",
		Key = "Underdog",
		Description = ::UPD.getDescription({
			Fluff = "이젠 익숙해.",
			Effects = [{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"방어적 악의로 인한 것 [포위|Concept.Surrounding] 더 이상 상대방에 의해 이 캐릭터에 적용되지 않습니다.",
					"공격자가 다음을 갖고 있는 경우 [$ $|Perk+perk_backstabber] 해당 특전의 효과는 무효화되며, 이로 인해 정상적인 방어력이 저하됩니다. [포위|Concept.Surrounding] 대신 적용됩니다."
				]
			}]
		})
	},
	{
		ID = "perk.coup_de_grace",
		Key = "CoupDeGrace",
		Description = ::UPD.getDescription({
			Fluff = "저놈들의 목을 쳐라!",
			Effects = [{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"피해량은 다음과 같이 증가합니다. " + ::MSU.Text.colorPositive("20%") + " 지속되는 적들에 맞서 [부상|Concept.Injury] 아니면 [$ $|Skill+sleeping_effect], [$ $|Skill+stunned_effect], [$ $|Skill+net_effect], [$ $|Skill+web_effect], 또는 [$ $|Skill+rooted_effect]."
				]
			}]
		})
	},
	{
		ID = "perk.crippling_strikes",
		Key = "CripplingStrikes",
		Description = ::UPD.getDescription({
			Fluff = "일단 찔렀으면 칼을 비틀어 주는 것도 잊지 마라!",
			Effects = [{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"낮춘다 [한계치|Concept.InjuryThreshold] 가하다 [부상|Concept.Injury] 에 의해 " + ::MSU.Text.colorNegative("33%") + " 근접 공격과 원거리 공격 모두에 해당됩니다."
				]
			}]
		})
	},
	{
		ID = "perk.duelist",
		Key = "Duelist",
		Description = ::UPD.getDescription({
			Fluff = "무기와 한 몸이 되어 약점을 노려라!",
			Requirement = "기본 근접 공격에 기본이 있는 무기 [행동력|Concept.ActionPoints] 4 이하의 비용",
			Effects = [{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"추가 피해는 방어구를 무시합니다. 이 보너스는 " + ::MSU.Text.colorPositive("25%") + " 한손 무기의 경우, " + ::MSU.Text.colorPositive("35%") + " 방패가 달린 한손 무기의 경우 " + ::MSU.Text.colorPositive("15%") + " 양손무기용.",
					"이제 방패도 무효화됩니다. [리치 우세|Concept.ReachAdvantage] 공격할 때 대상의."
				]
			}],
			Footer = ::MSU.Text.colorNegative("이 특전은 다음을 제외하고 기본 최대 범위가 1타일인 AOE가 아닌 근접 공격에만 작동합니다. [$ $|Skill+lunge_skill].")
		})
	},
	{
		ID = "perk.hold_out",
		Key = "HoldOut",
		Description = ::UPD.getDescription({
			Fluff = "정신 바짝 차려!",
			Effects = [{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"모든 부정적인 [상태 효과|Concept.StatusEffect] 한정된 기간(예: [$ $|Skill+disarmed_effect], [$ $|Skill+charmed_effect]) 지속 시간이 다음으로 감소했습니다. " + ::MSU.Text.colorPositive(1) + " [턴|Concept.Turn].",
					"[상태 효과|Concept.StatusEffect] 여러 번에 걸쳐 효과가 약해집니다. [턴|Concept.Turn] (e.g. [$ $|Skill+goblin_poison_effect])는 처음부터 가장 약한 상태에 있습니다.",
					"효과 [$ $|Skill+bleeding_effect] 이다 " + ::MSU.Text.colorPositive("반으로 줄인") + "."
				]
			}]
		})
	},
	{
		ID = "perk.indomitable",
		Key = "Indomitable",
		Description = ::UPD.getDescription({
			Fluff = "산은 밀어낼 수도, 쓰러뜨릴 수도 없다!",
			Effects = [
				{
					Type = ::UPD.EffectType.Active,
					Description = [
						"잠금을 해제합니다 [$ $|Skill+indomitable] 받는 피해를 감소시키고 면역 상태를 부여하는 스킬입니다. [$ $|Skill+stunned_effect], 뒤로 밀렸거나 붙잡혔습니다."
					]
				}
			]
		})
	},
	{
		ID = "perk.lone_wolf",
		Key = "LoneWolf",
		Description = ::UPD.getDescription({
			Fluff = "난 혼자일 때 실력이 가장 잘 나와.",
			Effects = [{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"당신의 세력 구성원이 당신과 인접하지 않거나 당신으로부터 2타일 이내의 거리에 1명 이상 없을 때, " + ::MSU.Text.colorPositive("15%") + " 보너스 [근접 공격|Concept.MeleeSkill], [원거리 공격|Concept.RangeSkill], [근접 방어|Concept.MeleeDefense], [원거리 방어|Concept.RangeDefense], 그리고 [의지|Concept.Bravery]."
				]
			}]
		})
	},
	{
		ID = "perk.mastery.axe",
		Key = "SpecAxe",
		Description = ::UPD.getDescription({
			Fluff = "도끼술을 익혀 적의 무장을 무력화한다.",
			Requirement = "도끼",
			Effects = [
				{
					Type = ::UPD.EffectType.Passive,
					Description = [
						"실력이 쌓인다 " + ::MSU.Text.colorPositive("25%") + " 덜 [피로|Concept.Fatigue].",
						"[$ $|Skill+round_swing] 이득 " + ::MSU.Text.colorPositive("+5%") + " 칠 기회."
						"는 [$ $|Item+longaxe] 그리고 [$ $|Item+rf_poleaxe] 더 이상 바로 인접한 대상을 공격해도 페널티가 적용되지 않습니다."
					]
				},
				{
					Type = ::UPD.EffectType.Active,
					Description = [
						"잠금을 해제합니다 [$ $|Skill+rf_bearded_blade_skill] 상대방이 공격 중이거나 공격을 놓쳤을 때 상대방을 무장해제시킬 수 있는 스킬입니다."
					]
				},
				{
					Type = ::UPD.EffectType.Active,
					Description = [
						"잠금을 해제합니다 [$ $|Skill+rf_hook_shield_skill] 대상의 보호막 효과를 감소시키는 스킬입니다."
					]
				}
			]
		})
	},
	{
		ID = "perk.mastery.bow",
		Key = "SpecBow",
		Description = ::UPD.getDescription({
			Fluff = "궁술을 익혀 먼 거리에서 적에게 화살비를 퍼붓는다.",
			Requirement = "활",
			Effects = [
				{
					Type = ::UPD.EffectType.Passive,
					Description = [
						"실력이 쌓인다 " + ::MSU.Text.colorPositive("25%") + " 덜 [피로|Concept.Fatigue].",
						"[시야|Concept.SightDistance] 활의 최대 사격 범위가 증가합니다. " + ::MSU.Text.colorPositive("+1") + "."
					]
				},
				{
					Type = ::UPD.EffectType.Active,
					Description = [
						"잠금을 해제합니다 [$ $|Skill+rf_arrow_to_the_knee_skill] 전장에서 이동하는 적의 능력을 약화시키는 기술입니다."
					]
				}
			]
		})
	},
	{
		ID = "perk.mastery.cleaver",
		Key = "SpecCleaver",
		Description = ::UPD.getDescription({
			Fluff = "참도를 숙달해 피에 굶주린 기세로 싸운다.",
			Requirement = "식칼",
			Effects = [{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"실력이 쌓인다 " + ::MSU.Text.colorPositive("25%") + " 덜 [피로|Concept.Fatigue].",
					"이득 [$ $|Perk+perk_rf_bloodlust] 특권.",
					"식칼의 공격은 추가 스택을 적용합니다. [$ $|Skill+bleeding_effect].",
					"[$ $|Skill+disarm_skill] 명중할 페널티는 절반만 있습니다.",
					"[$ $|Skill+rf_gouge_skill] 가지고있다 " + ::MSU.Text.colorNegative("50%") + " 더 낮은 [한계치|Concept.InjuryThreshold] 가하다 [부상|Concept.InjuryTemporary].",
					"는 [$ $|Item+rf_voulge] 더 이상 바로 인접한 대상을 공격해도 페널티가 적용되지 않습니다."
				]
			}]
		})
	},
	{
		ID = "perk.mastery.crossbow",
		Key = "SpecCrossbow",
		Description = ::UPD.getDescription({
			Fluff = "쇠뇌와 화기의 조준법을 숙달한다.",
			Requirement = "석궁 또는 총기",
			Effects = [
				{
					Type = ::UPD.EffectType.Passive,
					Description = [
						"실력이 쌓인다 " + ::MSU.Text.colorPositive("25%") + " 덜 [피로|Concept.Fatigue].",
						"[$ $|Item+heavy_crossbow] 이제 필요하다 " + ::MSU.Text.colorNegative("4") + " [행동력|Concept.ActionPoints] 에 [$ $|Skill+reload_bolt], 일반 석궁과 마찬가지로 쏘고, 재장전하고, 이동할 수 있습니다.",
						"[$ $|Item+handgonne] 이제 필요하다 " + ::MSU.Text.colorNegative("6") + " [행동력|Concept.ActionPoints] 에 [$ $|Skill+reload_handgonne_skill] 매 턴마다 발사하는 대신 매 턴마다 발사할 수 있습니다."
					]
				},
				{
					Type = ::UPD.EffectType.Active,
					Description = [
						"잠금을 해제합니다 [$ $|Skill+rf_take_aim_skill] 장애물 뒤에 있는 적을 공격할 수 있는 스킬입니다. [$ $|Item+crossbow] 또는 [$ $|Item+handgonne]."
					]
				},

			]
		})
	},
	{
		ID = "perk.mastery.dagger",
		Key = "SpecDagger",
		Description = ::UPD.getDescription({
			Fluff = "빠르고 치명적인 단검술을 익힌다.",
			Requirement = "단검",
			Effects = [{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"실력이 쌓인다 " + ::MSU.Text.colorPositive("25%") + " 덜 [피로|Concept.Fatigue].",
					"현재 당신을 쫓는 대상에 대한 단검 공격 [라운드|Concept.Round] 대상을 모두 무시 [리치 우세|Concept.ReachAdvantage].",
					"[$ $|Skill+stab], [$ $|Skill+puncture] 그리고 [$ $|Skill+deathblow_skill] 감소했다 [행동력|Concept.ActionPoints] 매 턴마다 추가 공격을 허용하는 비용입니다."
				]
			}]
		})
	},
	{
		ID = "perk.mastery.flail",
		Key = "SpecFlail",
		Description = ::UPD.getDescription({
			Fluff = "도리깨를 숙달해 적의 방패를 우회한다.",
			Requirement = "플레일",
			Effects = [{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"실력이 쌓인다 " + ::MSU.Text.colorPositive("25%") + " 덜 [피로|Concept.Fatigue].",
					"[$ $|Skill+lash_skill] 그리고 [$ $|Skill+hail_skill] 방패로 부여되는 방어 보너스는 무시하지만 [$ $|Skill+shieldwall_effect].",
					"이득 [$ $|Perk+perk_rf_from_all_sides] 특권.",
					"[$ $|Skill+pound] 추가 무시 " + ::MSU.Text.colorPositive("+10%") + " 머리에 닿는 갑옷.",
					"[$ $|Skill+thresh] 이득 " + ::MSU.Text.colorPositive("+5%") + " 칠 기회.",
					"장대도박은 더 이상 바로 인접한 대상을 공격해도 페널티를 받지 않습니다."
				]
			}]
		})
	},
	{
		ID = "perk.mastery.hammer",
		Key = "SpecHammer",
		Description = ::UPD.getDescription({
			Fluff = "망치술을 익혀 중무장한 적을 상대한다.",
			Requirement = "망치",
			Effects = [
				{
					Type = ::UPD.EffectType.Passive,
					Description = [
						"실력이 쌓인다 " + ::MSU.Text.colorPositive("25%") + " 덜 [피로|Concept.Fatigue].",
						"[$ $|Skill+crush_armor] 그리고 [$ $|Skill+demolish_armor_skill] 가하다 " + ::MSU.Text.colorPositive("33%") + " 갑옷에 더 많은 피해를 입히고 [$ $|Skill+rf_dented_armor_effect] 효과.",
						"[$ $|Skill+shatter_skill] 이득 " + ::MSU.Text.colorPositive("+5%") + " 칠 기회.",
						"는 [$ $|Item+polehammer] 더 이상 바로 인접한 대상을 공격해도 페널티가 적용되지 않습니다."
					]
				},
				{
					Type = ::UPD.EffectType.Active,
					Description = [
						"양손 망치를 사용할 때 [$ $|Skill+rf_pummel_skill] 기술."
					]
				}
			]
		})
	},
	{
		ID = "perk.mastery.mace",
		Key = "SpecMace",
		Description = ::UPD.getDescription({
			Fluff = "철퇴를 숙달해 갑옷의 유무를 막론하고 상대를 때려눕힌다.",
			Requirement = "메이스",
			Effects = [{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"실력이 쌓인다 " + ::MSU.Text.colorPositive("25%") + " 덜 [피로|Concept.Fatigue].",
					"이득 [$ $|Perk+perk_rf_bear_down] 특권."
					"[$ $|Skill+knock_out], [$ $|Skill+knock_over_skill] 그리고 [$ $|Skill+strike_down_skill] 가지고 있다 " + ::MSU.Text.colorPositive("100%") + " 가할 기회 [$ $|Skill+stunned_effect] 면역이 아닌 경우 대상.",
					"폴메이스는 더 이상 바로 인접한 대상을 공격해도 페널티를 받지 않습니다."
				]
			}]
		})
	},
	{
		ID = "perk.mastery.polearm",
		Key = "SpecPolearm",
		Description = ::UPD.getDescription({
			Fluff = "장병기를 숙달해 아군을 지원한다.",
			Requirement = "폴암",
			Effects = [{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"실력이 쌓인다 " + ::MSU.Text.colorPositive("25%") + " 덜 [피로|Concept.Fatigue].",
					"이득 [$ $|Perk+perk_rf_bolster] 특권."
					"양손 무기를 사용하는 모든 스킬, 범위 2타일, [행동력|Concept.ActionPoints] 비용 " + ::MSU.Text.colorNegative("6") + " 그들의 [행동력|Concept.ActionPoints] 비용 절감 " + ::MSU.Text.colorNegative("5") + ".",
					"장창은 더 이상 바로 인접한 대상을 공격해도 페널티를 받지 않습니다."
				]
			}]
		})
	},
	{
		ID = "perk.mastery.spear",
		Key = "SpecSpear",
		Description = ::UPD.getDescription({
			Fluff = "창술을 익혀 적이 접근하지 못하게 한다.",
			Requirement = "창",
			Effects = [{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"실력이 쌓인다 " + ::MSU.Text.colorPositive("25%") + " 덜 [피로|Concept.Fatigue].",
					"[$ $|Skill+spearwall] 상대방이 이를 극복하면 더 이상 비활성화되지 않습니다. 대신, [$ $|Skill+spearwall] 계속해서 사용할 수 있으며, 진입을 시도하는 추가 상대에게 계속해서 무료 공격을 제공합니다. [통제 구역|Concept.ZoneOfControl]",
					"시작할 때 [턴|Concept.Turn] 창을 장착한 상태에서 첫 번째 관통 창 공격 비용 " + ::MSU.Text.colorPositive("아니") + " [행동력|Concept.ActionPoints] 그리고 빌드 " + ::MSU.Text.colorPositive("50%") + " 덜 [피로|Concept.Fatigue]. 양손 창을 사용하는 경우 해당 위치에서 이동하거나 한손 창을 사용하는 경우 타일을 1개 이상 이동하면 만료됩니다.",
					"는 [$ $|Item+spetum] 그리고 [$ $|Item+warfork] 더 이상 바로 인접한 대상을 공격해도 페널티가 적용되지 않습니다."
				]
			}]
		})
	},
	{
		ID = "perk.mastery.sword",
		Key = "SpecSword",
		Description = ::UPD.getDescription({
			Fluff = "검술을 숙달해 상대의 실수를 파고든다.",
			Requirement = "검",
			Effects = [
				{
					Type = ::UPD.EffectType.Passive,
					Description = [
						"실력이 쌓인다 " + ::MSU.Text.colorPositive("25%") + " 덜 [피로|Concept.Fatigue].",
						"[$ $|Skill+riposte] 더 이상 충돌에 대한 페널티를 받지 않습니다.",
						"[$ $|Skill+gash_skill] 가지고있다 " + ::MSU.Text.colorNegative("50%") + " 더 낮은 [한계치|Concept.InjuryThreshold] 가하다 [부상|Concept.InjuryTemporary].",
						"[$ $|Skill+split] 그리고 [$ $|Skill+swing] 더 이상 히트와 이득에 대한 페널티를 받지 않습니다. " + ::MSU.Text.colorPositive("+5%") + " 칠 기회."
					]
				},
				{
					Type = ::UPD.EffectType.Active,
					Description = [
						"잠금을 해제합니다 [$ $|Skill+rf_passing_step_skill] 공격 성공 직후 무시하고 한 타일씩 이동할 수 있는 스킬입니다. [통제 구역|Concept.ZoneOfControl] 감소된 [행동력|Concept.ActionPoints] 비용이 들지만 " + ::MSU.Text.colorNegative("+2") + " [피로|Concept.Fatigue] 비용.",
						"이동 대상 타일은 적과 인접해야 합니다.",
						"양손검이나 양손검으로 베는 공격이 필요합니다."
					]
				}
			]
		})
	},
	{
		ID = "perk.mastery.throwing",
		Key = "SpecThrowing",
		Description = ::UPD.getDescription({
			Fluff = "투척술을 익혀 적이 다가오기 전에 부상을 입히거나 처치한다.",
			Requirement = "투척무기",
			Effects = [{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"실력이 쌓인다 " + ::MSU.Text.colorPositive("25%") + " 덜 [피로|Concept.Fatigue].",
					"피해량은 다음과 같이 증가합니다. " + ::MSU.Text.colorPositive("30%") + " 2타일 거리에서 공격할 때 " + ::MSU.Text.colorPositive("20%") + " 3타일 거리에서 공격할 때.",
					"투척 공격으로 인한 적중은 이제 대상에게 특정 디버프를 적용합니다. 관통형 공격에는 " + ::MSU.Text.colorPositive("50%") + " 을 가할 기회 [$ $|Skill+rf_arrow_to_the_knee_debuff_effect] 효과. 절단형 공격에는 항상 [$ $|Skill+overwhelmed_effect] 효과. 둔기형 공격에는 " + ::MSU.Text.colorPositive("50%") + " 가할 기회 [$ $|Skill+staggered_effect] 그리고 목표가 이미 있다면 [$ $|Skill+staggered_effect], " + ::MSU.Text.colorPositive("100%") + " 가할 기회 [$ $|Skill+stunned_effect]."
				]
			}]
		})
	},
	{
		ID = "perk.student",
		Key = "Student",
		Description = ::UPD.getDescription({
			Fluff = "마음만 먹으면 무엇이든 배울 수 있다.",
			Effects = [{
				Type = ::UPD.EffectType.OneTimeEffect,
				Description = [
					"11번째 캐릭터 레벨에서는 추가 특전 포인트를 얻고 이 특전은 비활성화됩니다.",
					"'Manhunters' 오리진을 플레이하면 7번째 캐릭터 레벨에서 혜택 포인트를 환불받을 수 있습니다."
				]
			},
			{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"추가 획득 " + ::MSU.Text.colorPositive("20%") + " 전투 경험."
				]
			}],
			Footer = ::MSU.Text.colorNegative("이 혜택은 환불될 수 없습니다.")	// This line is new, rest is the same
		})
	},
	{
		ID = "perk.gifted",
		Key = "Gifted",
		Description = ::UPD.getDescription({
			Fluff = "타고난 재능이 있으니 용병 생활도 수월하다.",
			Effects = [{
				Type = ::UPD.EffectType.OneTimeEffect,
				Description = [
					"최대 굴림으로 이 캐릭터의 속성을 높이려면 즉시 레벨 업을 얻으십시오. 단, 재능은 없습니다."
				]
			}],
			Footer = ::MSU.Text.colorNegative("이 혜택은 환불될 수 없습니다.")	// This line is new, rest is the same
		})
	},
	{
		ID = "perk.nimble",
		Key = "Nimble",
		Description = ::UPD.getDescription({
			Fluff = "경갑에 특화된다. 몸을 가볍게 틀거나 일격을 흘려 정타도 스치는 공격으로 바꾼다.",
			Effects = [{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"손상 [체력|Concept.Hitpoints] 에 의해 감소된다 " + ::MSU.Text.colorPositive("50%") + " 그리고 그것은 갑옷에 의해 " + ::MSU.Text.colorPositive("25%") + ".",
					"머리와 몸통 갑옷을 착용하면 보너스가 기하급수적으로 떨어집니다. [최대 피로|Concept.MaximumFatigue] 15를 초과하고 귀하의 15%를 초과합니다. [기본|Concept.BaseAttribute] [최대 피로|Concept.Fatigue] 의 효과를 포함하여 [특성|Concept.Trait] 그리고 [영구 부상|Concept.InjuryPermanent].",
					"정신 공격이나 상태 효과로 인한 피해에는 영향을 미치지 않지만, 이를 피하는 데 도움이 될 수 있습니다.",
					"자신이 가지고 있는 대상을 공격할 때 [리치 열세|Concept.ReachAdvantage], 이 단점을 다음과 같이 줄입니다. " + ::MSU.Text.colorPositive(1) + " 만약 당신의 [주도력|Concept.Initiative] 목표보다 큽니다."
					"[$ $|Perk+perk_brawny] 이 혜택에는 영향을 미치지 않습니다.",
					"가지고 있으면 배울 수 없습니다. [$ $|Perk+perk_rf_poise] 또는 [$ $|Perk+perk_battle_forged]."
				]
			}]
		})
	},
	{
		ID = "perk.overwhelm",
		Key = "Overwhelm",
		Description = ::UPD.getDescription({
			Fluff = "높은 [주도력|Concept.Initiative]을 살려 공격을 퍼부어라. 압도당한 적은 제대로 반격하기 어렵다.",
			Effects = [{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"현재 라운드에서 당신을 따라 행동하는 상대에 대한 모든 공격, 히트 또는 실패로 인해 [$ $|Skill+overwhelmed_effect] 둘 다 낮추는 상태 효과 [근접 공격|Concept.MeleeSkill] 그리고 [원거리 공격|Concept.RangeSkill] 에 의해 " + ::MSU.Text.colorNegative("-10%") + " 하나를 위해 [턴|Concept.Turn].",
					"효과는 각 공격마다 최대 7회까지 중첩되며, 한 번의 공격으로 여러 대상에게 동시에 적용할 수 있습니다."
				]
			}]
		})
	},
	{
		ID = "perk.pathfinder",
		Key = "Pathfinder",
		Description = ::UPD.getDescription({
			Fluff = "험한 지형을 헤쳐 나가는 법을 익힌다.",
			Effects = [
				{
					Type = ::UPD.EffectType.Passive,
					Description = [
						"[행동력|Concept.ActionPoints] 모든 지형에서의 이동 비용은 다음과 같이 감소합니다. " + ::MSU.Text.colorPositive("1") + " 최소 2개 [행동력|Concept.ActionPoints] 타일당, 그리고 [피로|Concept.Fatigue] 비용이 절반으로 줄어듭니다.",
						"높이 수준 변경에도 추가 사항이 없습니다. [행동력|Concept.ActionPoints] 더 이상 비용이 들지 않습니다."
					]
				}
			]
		})
	},
	{
		ID = "perk.quick_hands",
		Key = "QuickHands",
		Description = ::UPD.getDescription({
			Fluff = "서부에서 가장 빠른 손.",
			Effects = [{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"전투 중 아이템 교환은 아무런 부담 없이 자유로운 행동이 됩니다. [행동력|Concept.ActionPoints] 비용은 한 번씩 [턴|Concept.Turn].",
					"방패를 교체하거나 양손 근접 무기 하나를 다른 양손 근접 무기로 교체하는 경우에는 작동하지 않습니다.",
					"다른 무료 스왑 스킬과 중복되지 않습니다."
				]
			}]
		})
	},
	{
		ID = "perk.shield_expert",
		Key = "ShieldExpert",
		Description = ::UPD.getDescription({
			Fluff = "공격을 정면에서 막는 대신 옆으로 흘려내는 법을 익힌다.",
			Requirement = "방패",
			Effects = [
				{
					Type = ::UPD.EffectType.Passive,
					Description = [
						"방패 방어 보너스가 증가합니다. " + ::MSU.Text.colorPositive("25%") + ". 이는 추가 방어 보너스에도 적용됩니다. [$ $|Skill+shieldwall] 기술.",
						"방패 방어 보너스 최대 감소 [피로|Concept.Fatigue] 에서 감소됩니다 " + ::MSU.Text.colorNegative("50%") + " 에 " + ::MSU.Text.colorNegative("25%") + ".",
						"당신에 대한 공격 실패로 인해 더 이상 당신의 체력이 증가하지 않습니다. [피로|Concept.Fatigue]."
					]
				},
				{
					Type = ::UPD.EffectType.Active,
					Description = [
						"잠금을 해제합니다 [$ $|Skill+rf_cover_ally_skill] 아군을 대상으로 지정하여 무시하고 1타일씩 이동할 수 있게 하는 스킬입니다. [통제 구역|Concept.ZoneOfControl] 그들의 [턴|Concept.Turn] 다음 턴 순서에서 자신의 위치를 향상시키면서 [라운드|Concept.Round]."
					]
				}
			]
		})
	},
	{
		ID = "perk.steel_brow",
		Key = "SteelBrow",
		Description = ::UPD.getDescription({
			Fluff = "이 정도는 버틸 수 있어!",
			Effects = [{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"머리에 타격을 가해도 더 이상 이 캐릭터에게 심각한 손상이 발생하지 않으며, 머리가 약해질 위험도 줄어듭니다. [부상|Concept.Injury] 상당히."
				]
			}]
		})
	},
	{
		ID = "perk.nine_lives",
		Key = "NineLives",
		Description = ::UPD.getDescription({
			Fluff = "호기심이 고양이를 죽였다지만 그리 빨리 죽진 않았다.",
			Effects = [{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"전투당 한 번, 결정타를 받으면 대신 몇 발로 살아남습니다. [체력|Concept.Hitpoints] 남아 있으며 시간이 지남에 따라 모든 피해가 적용됩니다(예: [$ $|Skill+bleeding_effect], [$ $|Skill+spider_poison_effect]) 치료되었습니다.",
					"트리거 시 게인 [$ $|Skill+nine_lives_effect] 다음 시작까지 [턴|Concept.Turn]."
				]
			}]
		})
	},
	{
		ID = "perk.brawny",
		Key = "Brawny",
		Description = ::UPD.getDescription({
			Fluff = "거북이 등껍질처럼 갑옷을 몸에 익혀라.",
			Effects = [{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"갑옷과 투구 착용으로 인한 피로도와 주도력 페널티가 다음과 같이 감소합니다. " + ::MSU.Text.colorNegative("30%") + "."
				]
			}]
		})
	}
];

::MSU.Table.merge(::Const.Strings.PerkDescription, {
	RF_Angler = ::UPD.getDescription({
		Fluff = "표적을 빈틈없이 휘감도록 그물을 활짝 펼쳐 던진다.",
		Requirement = "던지기 그물",
		Effects = [
			{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"[$ $|Skill+throw_net]의 사거리가 1칸 늘어난다. 최대 사거리는 3칸이다.",
					"2칸 이내에서 당신의 [$ $|Skill+net_effect]에 걸린 적은 탈출할 때 " + ::MSU.Text.colorNegative("50%") + " 더 많은 [행동력|Concept.ActionPoints]을 [$ $|Skill+break_free_skill]에 소모한다."
				]
			},
			{
				Type = ::UPD.EffectType.Active,
				Description = [
					"[$ $|Skill+rf_net_pull_skill]을 습득한다. 대상을 끌어당겨 [그물|Skill+net_effect]에 가둔다."
				]
			}
		]
	}),
	RF_BattleFervor = ::UPD.getDescription({
		Fluff = "이것이 우리의 운명이다!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"수신 [사기 판정|Concept.Morale] 매 시작마다 [턴|Concept.Turn] 만약 당신이 [자신만만|Concept.Morale] 성공하면 최대 4개의 스택을 얻습니다. 각 스택에 대해 [의지|Concept.Bravery], [근접 공격|Concept.MeleeSkill], [원거리 공격|Concept.RangeSkill], [근접 방어|Concept.MeleeDefense] 그리고 [원거리 방어|Concept.RangeDefense] 에 의해 증가된다 " + ::MSU.Text.colorPositive("5%") + ".",
				"패배 " + ::MSU.Text.colorNegative(1) + " 종료 시 스택 [턴|Concept.Turn] 공격하지도 않고.",
				"자신감을 잃으면 즉시 모든 스택을 잃습니다. [사기|Concept.Morale]."
			]
		}]
	}),
	RF_BackToBasics = ::UPD.getDescription({
		Fluff = "대장 말대로 기본에 충실해. 멋 부리다간 죽는 수가 있어!",
		Effects = [{
			Type = ::UPD.EffectType.OneTimeEffect,
			Description = [
				"2개의 특전 포인트를 얻습니다.",
				"당신의 [퍽 단계|Concept.PerkTier] 아래로 " + ::MSU.Text.colorNegative(2) + "."
			]
		}],
		Footer = ::MSU.Text.colorNegative("이 혜택은 환불될 수 없습니다.")
	}),
	RF_Skirmisher = ::UPD.getDescription({
		Fluff = "갑옷과 기동성의 균형을 맞춰 속도와 지구력을 높인다.",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"처벌은 [주도력|Concept.Initiative] 머리와 몸통의 방어구는 다음과 같이 감소합니다. " + ::MSU.Text.colorPositive("30%") + ".",
				"언제나 당신의 [주도력|Concept.Initiative] 에 의해서만 감소됩니다 " + ::MSU.Text.colorPositive("50%") + " 누적된 [피로|Concept.Fatigue], 그 모든 것 대신.",
				"스택 [곱연산으로|Concept.StackMultiplicatively] 와 함께 [$ $|Perk+perk_relentless] 특권."
			]
		}]
	}),
	BattleFlow = ::UPD.getDescription({
		Fluff = "다음 놈!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"당 한 번 [턴|Concept.Turn], 상대를 죽이면 전류가 감소합니다. [피로|Concept.Fatigue] 에 의해 " + ::MSU.Text.colorPositive("10%") + " 의 [기본|Concept.BaseAttribute] [최대 피로|Concept.MaximumFatigue]."
			]
		}]
	}),
	RF_BearDown = ::UPD.getDescription({
		Fluff = "머리를 한 대 먹여. 그다음 파고들어 끝내는 거야!",
		Requirement = "메이스",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"게인 " + ::MSU.Text.colorPositive("+15%") + " 머리를 칠 기회와 " + ::MSU.Text.colorPositive("33%") + " 감소 [한계치|Concept.InjuryThreshold] 가하다 [부상|Concept.InjuryTemporary] 공격할 때 [$ $|Skill+rf_rattled_effect], [$ $|Skill+stunned_effect], [$ $|Skill+dazed_effect], [$ $|Skill+net_effect], [$ $|Skill+sleeping_effect], [$ $|Skill+staggered_effect], [$ $|Skill+web_effect], 또는 [$ $|Skill+rooted_effect] 목표."
			]
		}]
	}),
	RF_BestialVigor = ::UPD.getDescription({
		Fluff = "내면의 야수를 풀어라!",
		Effects = [{
			Type = ::UPD.EffectType.Active,
			Description = [
				"잠금을 해제합니다 [$ $|Skill+rf_bestial_vigor_skill] 줄여줄 수 있는 스킬 [피로|Concept.Fatigue] 그리고 이득 [행동력|Concept.ActionPoints] 전투 중."
			]
		}]
	}),
	RF_BetweenTheEyes = ::UPD.getDescription({
		Fluff = "버터를 가르듯이!",
		Requirement = "근접 공격",
		Effects = [{
			Type = ::UPD.EffectType.Active,
			Description = [
				"잠금을 해제합니다 [$ $|Skill+rf_between_the_eyes_skill] 기술."
			]
		}]
	}),
	RF_BetweenTheRibs = ::UPD.getDescription({
		Fluff = "상대가 한눈을 파는 순간, 가장 취약한 곳을 노려라!",
		Requirement = "단검으로 찌르는 공격",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"다음에 대한 공격 [포위|Concept.Surrounding] 목표 거래 " + ::MSU.Text.colorPositive("10%") + " 더 많은 피해를 입었고 " + ::MSU.Text.colorPositive("+10%") + " 대상 주변의 캐릭터당 방어구 관통력입니다."
			]
		}]
	}),
	RF_Blitzkrieg = ::UPD.getDescription({
		Fluff = "눈 깜짝할 사이에 끝난다!",
		Effects = [{
			Type = ::UPD.EffectType.Active,
			Description = [
				"잠금을 해제합니다 [$ $|Skill+rf_blitzkrieg_skill] 귀하와 귀하의 회사의 나머지 구성원이 [$ $|Skill+adrenaline_effect] 효과."
			]
		}]
	}),
	RF_Bloodlust = ::UPD.getDescription({
		Fluff = "주변이 피바다가 될수록 기운이 솟는다. 집에 온 기분이다!",
		Requirement = "식칼",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"치명타를 가한 후, 이득을 얻습니다. " + ::MSU.Text.colorPositive("2") + " Bloodlust는 최대 2중첩까지 쌓을 수 있습니다.",
				"각 스택에 대해 [의지|Concept.Bravery], [주도력|Concept.Initiative] 그리고 [피로 회복|Concept.FatigueRecovery] 비율이 증가합니다 " + ::MSU.Text.colorPositive("15%") + " 스태킹 [합산 방식으로|Concept.StackAdditively].",
				"당신은 패배 " + ::MSU.Text.colorNegative("1") + " 매 시작마다 스택 [턴|Concept.Turn]."
			]
		}]
	}),
	RF_Command = ::UPD.getDescription({
		Fluff = "넌 해낼 거다!",
		Effects = [{
			Type = ::UPD.EffectType.Active,
			Description = [
				"잠금을 해제합니다 [$ $|Skill+rf_command_skill] 아군을 턴 순서대로 전진시킬 수 있는 스킬입니다."
			]
		}]
	}),
	RF_CalculatedStrikes = ::UPD.getDescription({
		Fluff = "서두르지 말고 정확히 쳐라!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"거래 " + ::MSU.Text.colorPositive("20%") + " 시작하지 않은 사람에게는 더 많은 피해를 입힙니다. [턴|Concept.Turn] 아직 현재 [라운드|Concept.Round]."
				"[주도력|Concept.Initiative] 에 의해 감소된다 " + ::MSU.Text.colorNegative("20%") + "."
			]
		}]
	}),
	RF_CheapTrick = ::UPD.getDescription({
		Fluff = "비겁하다고? 우린 그걸 승리라고 하지.",
		Effects = [{
			Type = ::UPD.EffectType.Active,
			Description = [
				"잠금을 해제합니다 [$ $|Skill+rf_cheap_trick_skill] 다음 공격의 적중률은 증가하지만 피해량은 감소하는 스킬입니다."
			]
		}]
	}),
	RF_DeathDealer = ::UPD.getDescription({
		Fluff = "낫 앞의 밀처럼!",
		Requirement = "근접 AOE 공격",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"근접 [범위 공격|Concept.AOE] 공격 이득 " + ::MSU.Text.colorPositive("+10%") + " 히트 앤 딜 기회 " + ::MSU.Text.colorPositive("10%") + " 피해 증가."
			]
		}]
	}),
	RF_Bolster = ::UPD.getDescription({
		Fluff = "네가 뒤를 받쳐 주면 전우들은 자신감을 얻는다.",
		Requirement = "6개 이상의 무기 [리치|Concept.Reach]",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"그렇지 않은 동안 [근접 교전 중|Concept.ZoneOfControl], 공격하거나 맞거나 놓칠 때마다 긍정적인 효과가 발동됩니다. [사기 판정|Concept.Morale] 귀하 회사의 인접 구성원이 아닌 경우 [도주 중|Concept.Morale]."
			]
		}]
	}),
	RF_BoneBreaker = ::UPD.getDescription({
		Fluff = "뚝, 우지끈, 와삭. 이 얼마나 듣기 좋은 소리인가!",
		Requirement = "메이스를 이용한 둔기 공격",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"최소한의 공격 " + ::MSU.Text.colorNegative(5) + " 손상 [체력|Concept.Hitpoints] 유효한 것을 적용하십시오 [상태 효과|Concept.StatusEffect] 또는 유효한 문자를 상대로 합니다. [상태 효과|Concept.StatusEffect] 를 가할 기회가 있다 [부상|Concept.Injury]. 이번 기회는 " + ::MSU.Text.colorPositive("100%") + " 양손 철퇴용 " + ::MSU.Text.colorPositive("50%") + " 한손 메이스용.",
				"피해를 입힐 만큼 충분한 경우 [부상|Concept.Injury], 추가 피해를 입힙니다. [부상|Concept.Injury].",
				"한 턴에 같은 대상에게 두 번 이상 발동할 수 없습니다.",
				"유효한 상태 효과는 다음과 같습니다: [$ $|Skill+stunned_effect], [$ $|Skill+net_effect], [$ $|Skill+web_effect], [$ $|Skill+rooted_effect], [$ $|Skill+sleeping_effect]."
			]
		}]
	}),
	RF_Bully = ::UPD.getDescription({
		Fluff = "멈추라고 했나?",
		Requirement = "근접 공격",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"낮은 캐릭터에 대한 공격 [사기|Concept.Morale] 당신이 거래하는 것보다 " + ::MSU.Text.colorPositive("10%") + " 레벨당 데미지 증가 [사기|Concept.Morale] 차이."
			]
		}]
	}),
	RF_Bulwark = ::UPD.getDescription({
		Fluff = "판금 갑옷 안에 있으면 겁날 것도 별로 없지!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"게인 " + ::MSU.Text.colorPositive("5%") + " 현재 머리와 몸통 갑옷의 내구성을 합친 것입니다. [의지|Concept.Bravery] 동안 [사기 판정|Concept.Morale]. 이것은 부정적인 것에 대해 두 배입니다 [사기 판정|Concept.Morale].",
				"정신적 공격에 대해서는 아무것도 하지 않습니다."
			]
		}]
	}),
	RF_Finesse = ::UPD.getDescription({
		Fluff = "오랜 전투 훈련을 거치며 전장에서 힘을 아끼는 몸놀림을 익혔다.",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"[피로|Concept.Fatigue] 스킬 비용이 감소합니다. " + ::MSU.Text.colorPositive("20%") + "."
			]
		}]
	}),
	RF_Centurion = ::UPD.getDescription({
		Fluff = "더 빨리!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"트리거 [$ $|Skill+rf_centurion_command_effect] 최대 6타일 떨어진 아군 해골에 효과가 적용됩니다."
			]
		}]
	}),
	RF_Combo = ::UPD.getDescription({
		Fluff = "언제나 잘 먹히는 하나, 둘.",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"비용이 많이 드는 기술을 사용하면 [행동력|Concept.ActionPoints] 감소시킨다 [행동력|Concept.ActionPoints] 모든 기술의 비용 " + ::MSU.Text.colorPositive("1") + " 최소 3개까지.",
				"자유 스킬이 아닌 스킬을 사용하면 효과가 만료되며, [대기|Concept.Wait] 또는 당신의 종료 [턴|Concept.Turn]."
			]
		}]
	}),
	RF_ConcussiveStrikes = ::UPD.getDescription({
		Fluff = "이 자에게 머리를 한 대 맞으면 그대로 꿈나라다!",
		Requirement = "메이스를 이용한 둔기 공격"
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"한손 철퇴로 머리를 때린다. [기절시키다|Skill+stunned_effect] 1인용 [턴|Concept.Turn] 목표가 이미 있다면 [$ $|Skill+dazed_effect] 또는 공격으로 인해 [$ $|Skill+dazed_effect]. 그렇지 않으면 가하다 [$ $|Skill+dazed_effect] 1인용 [턴|Concept.Turn] 대신.",
				"양손 철퇴로 머리 타격 [기절시키다|Skill+stunned_effect] 1의 목표 [턴|Concept.Turn]."
			]
		}]
	}),
	RF_Decanus = ::UPD.getDescription({
		Fluff = "대열을 맞춰 싸워라!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"트리거 [$ $|Skill+rf_decanus_command_effect] 최대 4타일 떨어진 아군 해골에 효과가 적용됩니다."
			]
		}]
	}),
	RF_Decisive = ::UPD.getDescription({
		Fluff = "기다릴 시간 없다!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"게임을 끝낼 때마다 스택을 얻습니다. [턴|Concept.Turn] 사용하지 않은 채 [대기|Concept.Wait], 최대 3중첩까지 가능합니다.",
				"[의지|Concept.Bravery] 그리고 [주도력|Concept.Initiative] 둘 다 증가합니다 " + ::MSU.Text.colorPositive("15%") + " 스택이 1개 이상 있을 때.",
				"실력이 쌓인다 " + ::MSU.Text.colorPositive("15%") + " 덜 [피로|Concept.Fatigue] 스택이 2개 이상 있을 때.",
				"거래 " + ::MSU.Text.colorPositive("15%") + " 3중첩이 있으면 피해가 더 커집니다.",
				"사용하면 모든 스택을 잃습니다. [대기|Concept.Wait]."
			]
		}]
	}),
	RF_DeepCuts = ::UPD.getDescription({
		Fluff = "숫돌 다루는 솜씨가 뛰어나 칼날이 소름 끼치도록 예리하다.",
		Requirement = "절단 손상",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"당신의 [턴|Concept.Turn], 대상에 대한 공격이 성공한 후 모든 후속 공격에는 " + ::MSU.Text.colorNegative("33%") + " 감소 [한계치|Concept.InjuryThreshold] 가하다 [부상|Concept.InjuryTemporary] 그리고 가할 것이다 [$ $|Skill+bleeding_effect]. 공격 중 하나라도 발생한 경우 [부상|Concept.InjuryTemporary]., 공격은 추가 피해를 입힙니다. [$ $|Skill+bleeding_effect].",
				"대상 전환, 이동, 아이템 교체, 대기 또는 종료 시 효과가 만료됩니다. [턴|Concept.Turn], 또는 절단 공격을 제외한 모든 스킬을 사용합니다."
			]
		}]
	}),
	RF_DeepImpact = ::UPD.getDescription({
		Fluff = "술통을 굴려라, 뼛속까지 울리게!",
		Requirement = "망치로 둔기 공격",
		Effects = [{
			Type = ::UPD.EffectType.Active,
			Description = [
				"잠금을 해제합니다 [$ $|Skill+rf_deep_impact_skill] 대상을 약화시킬 수 있는 스킬입니다."
			]
		}]
	}),
	RF_DentArmor = ::UPD.getDescription({
		Fluff = "걷지도 못하는 놈이 어떻게 싸우겠어?",
		Requirement = "둔기 피해",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"성공적인 공격에는 " + ::MSU.Text.colorPositive("66%") + " 적용할 수 있는 기회 [$ $|Skill+rf_dented_armor_effect] 효과."
			]
		}]
	}),
	RF_DiscoveredTalent = ::UPD.getDescription({
		Fluff = "영문은 모르겠지만 갑자기 하는 일마다 두각을 보이기 시작했다!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"레벨업을 할 때마다, " + ::MSU.Text.colorPositive(1) + " 그리고 " + ::MSU.Text.colorPositive(3) + " [재능|Concept.Talent] 별이 3개 미만인 무작위 속성의 별입니다.",
				"속성당 한 번만 발동할 수 있으며 횟수를 늘릴 수 없습니다. [재능|Concept.Talent] 3 이상의 속성에 있는 별."
			]
		}],
		Footer = ::MSU.Text.colorNegative("이 특전은 다른 곳에서 특전 포인트를 사용한 후에는 선택할 수 없습니다. 이 혜택은 환불될 수 없습니다.")
	}),
	RF_Dismantle = ::UPD.getDescription({
		Fluff = "갑옷을 입은 채로 발가벗겨 주마!",
		Requirement = "도끼로 베기 공격",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"모든 성공적인 히트에는 다음을 적용할 기회가 있습니다. [$ $|Skill+rf_dismantled_effect] 효과로 인해 대상이 중첩을 받게 됩니다. " + ::MSU.Text.colorNegative("+20%") + " 남은 전투 동안 신체 부위의 갑옷을 무시하고 피해를 입었습니다.",
				"확률은 적중한 신체 부위의 남은 방어력 대비 입힌 방어구 피해 비율과 동일합니다."
			]
		}]
	}),
	RF_Dismemberment = ::UPD.getDescription({
		Fluff = "도마 위에 오른 걸 환영한다!",
		Requirement = "도끼로 베기 공격",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"을 가할 때 [부상|Concept.InjuryTemporary] 공격으로, 당신이 만난다면 [한계치|Concept.InjuryThreshold] 가능한 가장 낮은 부상을 입히는 대신 가장 높은 부상을 입히십시오. [한계치|Concept.InjuryThreshold].",
				"이 [부상|Concept.InjuryTemporary] 하나 이상의 추가 트리거 [사기 판정|Concept.Morale] 대상에 대해 최대 1회까지 발동할 수 있습니다. " + ::MSU.Text.colorNegative(3) + " [사기 판정|Concept.Morale], 각각에 대해 하나씩 " + ::MSU.Text.colorPositive("33%") + " 의 [체력|Concept.Hitpoints] 남은 피해량에 비해 피해량 [체력|Concept.Hitpoints]."
			]
		}]
	}),
	RF_DoubleStrike = ::UPD.getDescription({
		Fluff = "자, 한 대 더 받아라!",
		Requirement = "근접 공격",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"적중이 성공하면 다음 공격의 피해가 다음과 같이 증가합니다. " + ::MSU.Text.colorNegative("20%") + ".",
				"이동, 아이템 교환, 단일 대상 공격을 제외한 스킬 사용, 공격 실패, [대기|Concept.Wait] 또는 당신의 종료 [턴|Concept.Turn]."
			]
		}]
	}),
	RF_DynamicDuo = ::UPD.getDescription({
		Fluff = "등을 맡길 짝이 있을 때 가장 잘 싸운다는 걸 깨달았다.",
		Effects = [
			{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"회사의 다른 구성원을 파트너로 선택할 수 있습니다. 귀하 중 한 명이 사망하거나 회사를 떠날 때까지 귀하는 파트너로 유지됩니다. 당신이나 당신의 파트너 옆에 아군이 없을 때 당신과 당신의 파트너는 다음과 같은 보너스를 얻습니다.",
					"게인 " + ::MSU.Text.colorPositive("+10") + " [근접 공격|Concept.MeleeSkill] 파트너를 공격하는 적에 맞서고 " + ::MSU.Text.colorPositive("+10") + " [근접 방어|Concept.MeleeDefense] 파트너가 공격한 적에 대해 [턴|Concept.Turn].",
					"파트너의 난전 [범위 공격|Concept.AOE] 공격은 결코 " + ::MSU.Text.colorPositive(::Const.Combat.MV_HitChanceMin + "%") + " 파트너를 때리고 피해를 입힐 수 있는 기회 " + ::MSU.Text.colorPositive("50%") + " 피해가 적습니다.",
					"파트너는 이것을 배울 필요가 없습니다 [퍽|Concept.Perk] 혜택을 누리기 위해서입니다."
				]
			},
			{
				Type = ::UPD.EffectType.Active,
				Description = [
					"이득 [$ $|Skill+rf_dynamic_duo_shuffle_skill] 1회에 한 번씩 파트너와 자리를 바꿀 수 있는 스킬입니다. [턴|Concept.Turn] 다음 항목에 넣습니다. [턴|Concept.Turn] 바로 주문하세요."
				]
			}
		]
	}),
	RF_EnGarde = ::UPD.getDescription({
		Fluff = "검술이 몸에 배어 공격과 방어가 한 동작으로 이어진다.",
		Requirement = "검",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"미만 " + ::MSU.Text.colorNegative("10") + " 손에 무게를 싣더라도 남부 검은 이중 그립 보너스를 유지하고 [$ $|Skill+gash_skill] 대신에 [$ $|Skill+slash] 자유 공격을 할 때."
				"사용 [$ $|Skill+riposte] 연말에 무료로 [턴|Concept.Turn] 당신이 접근할 수 있다면 [$ $|Skill+riposte]. 그렇지 않으면 이득을 얻습니다 [$ $|Perk+perk_rf_rebuke] 대신에 하나 [턴|Concept.Turn], 추가 확률로 " + ::MSU.Text.colorPositive("+15%") + " 놓친 공격을 되돌리기 위해. 이로 인해 발생한 공격 [$ $|Perk+perk_rf_rebuke] 짓지 마 [피로|Concept.Fatigue].",
				"당신은 공짜만을 얻는다 [$ $|Skill+riposte_effect] 또는 [$ $|Perk+perk_rf_rebuke] 당신이 적어도 " + ::MSU.Text.colorNegative(15) + " [피로|Concept.Fatigue] 남지만 비용이 전혀 들지 않습니다. [행동력|Concept.ActionPoints] 아무것도 만들지도 않고 [피로|Concept.Fatigue]."
			]
		}]
	}),
	RF_Entrenched = ::UPD.getDescription({
		Fluff = "앞과 양옆의 전우를 믿고 맡은 일에 집중하는 대열 전투를 익혔다.",
		Requirement = "원거리 무기",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"근접 무기를 휘두르는 아군 옆에 서 있을 때 [근접 교전 중|Concept.ZoneOfControl], 이득 " + ::MSU.Text.colorPositive("+7") + " [원거리 공격|Concept.RangeSkill], [원거리 방어|Concept.RangeDefense], 그리고 [의지|Concept.Bravery]. 보너스는 다음과 같이 증가합니다. " + ::MSU.Text.colorPositive("+2") + " 모든 [턴|Concept.Turn] 최대 " + ::MSU.Text.colorPositive("+15") + " 당신이 계속해서 일을 시작하는 한 [턴|Concept.Turn] 근접 무기를 휘두르지 않는 아군 근처에 [근접 교전 중|Concept.ZoneOfControl]."
			]
		}]
	}),
	RF_ExploitOpening = ::UPD.getDescription({
		Fluff = "살짝 내린 방패, 어설픈 찌르기, 비틀거리는 시늉. 모두 상대의 치명적인 실수를 유도하는 수법이다.",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"당신에 대한 근접 공격을 놓친 상대에 대해 이득을 얻습니다. " + ::MSU.Text.colorPositive("+10%") + " 방패로 부여된 방어력 중 더 큰 것을 공격하거나 무시할 수 있는 기회가 있습니다. " + ::MSU.Text.colorPositive("20%") + " 더 많은 피해. 다음 공격 시 만료됩니다. [대기|Concept.Wait] 또는 당신의 종료 [턴|Concept.Turn]."
			]
		}]
	}),
	RF_ExudeConfidence = ::UPD.getDescription({
		Fluff = "네가 곁에 있으면 전우들은 산도 정복할 수 있을 것만 같다!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"당신의 시작 부분에 [턴|Concept.Turn], 최소한 꾸준함이 있는 경우 [사기|Concept.Morale], 개선하다 [사기 상태|Concept.Morale] 인접한 동맹국의 " + ::MSU.Text.colorPositive(1) + " 그들의 한 [사기 상태|Concept.Morale] 당신보다 낮습니다."
			]
		}]
	}),
	RF_FailedPotential = ::UPD.getDescription({
		Fluff = "한때 유망했지만 운이 없었든 재능이 부족했든 기대만큼 성장하지 못했다. " + ::MSU.Text.colorNegative("이 퍽은 아무 효과도 없다."),
		Footer = ::MSU.Text.colorNegative("이 혜택은 환불될 수 없습니다.")
	}),
	RF_FamilyPride = ::UPD.getDescription({
		Fluff = "불명예보다는 죽음을!",
		Effects = [
			{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"항상 자신감 있게 전투를 시작하세요 [사기|Concept.Morale].",
					"[의지|Concept.Bravery] 에 의해 증가된다 " + ::MSU.Text.colorPositive("50%") + " 부정적인 반대 [사기 판정|Concept.Morale]."
				]
			},
			{
				Type = ::UPD.EffectType.OneTimeEffect,
				Description = [
					"제거합니다 [$ $|Skill+insecure_trait] 그리고 [$ $|Skill+dastard_trait] 특성."
				]
			}
		]
	}),
	RF_Fencer = ::UPD.getDescription({
		Fluff = "날렵한 검을 다루는 기술을 숙달한다.",
		Requirement = "펜싱 소드",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"실력이 쌓인다 " + ::MSU.Text.colorPositive("20%") + " 덜 [피로|Concept.Fatigue] 그리고 이득 " + ::MSU.Text.colorPositive("+10%") + " 칠 기회.",
				"손상 유형 요구 사항은 다음과 같습니다. [$ $|Skill+rf_passing_step_skill] 제거됩니다.",
				"한손검을 사용하는 경우, [행동력|Concept.ActionPoints] 비용 [$ $|Skill+rf_sword_thrust_skill], [$ $|Skill+riposte] 그리고 [$ $|Skill+lunge_skill] 에 의해 감소된다 " + ::MSU.Text.colorPositive(1) + ".",
				"양손 검술 검 사용 시, [$ $|Skill+lunge_skill] 에 의해 증가된다 " + ::MSU.Text.colorPositive(1) + " tile."
			]
		}]
	}),
	RF_FeralRage = ::UPD.getDescription({
		Fluff = "늑대 앞의 양 떼처럼!",
		Requirement = "근접 공격",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"전투 중에 분노가 쌓입니다. 명중하면 분노 1을 얻고, 대상을 처치하면 분노 3을 얻고, 인접한 대상에 대한 명중이 성공할 때마다 분노 2를 얻습니다. 매 시작마다 분노 3을 잃습니다. [턴|Concept.Turn].",
				"각 분노 스택이 증가합니다. [의지|Concept.Bravery] 그리고 [주도력|Concept.Initiative] 에 의해 " + ::MSU.Text.colorPositive("+2") + " 및 근접 피해 " + ::MSU.Text.colorPositive("2%") + ". 각 스택이 낮아집니다. [근접 방어|Concept.MeleeDefense] 에 의해 " + ::MSU.Text.colorNegative("-1") + " 그리고 받는 피해를 감소시킵니다. " + ::MSU.Text.colorPositive("2%") + ", 최대 70%까지 가능합니다."
			]
		}]
	}),
	RF_FlailSpinner = ::UPD.getDescription({
		Fluff = "도리깨의 회전력을 이용해 재빠르게 후속타를 날린다!",
		Requirement = "플레일",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"당신의 차례 동안 공격에는 " + ::MSU.Text.colorPositive("50%") + " 동일한 유형의 무료 추가 공격을 수행할 수 있는 기회 " + ::MSU.Text.colorNegative("50%") + " 피해 감소."
			]
		}]
	}),
	RF_FlamingArrows = ::UPD.getDescription({
		Fluff = "전부 태워라!",
		Requirement = "활",
		Effects = [{
			Type = ::UPD.EffectType.Active,
			Description = [
				"잠금을 해제합니다 [$ $|Skill+rf_flaming_arrows_skill] 기술."
			]
		}]
	}),
	RF_FollowUp = ::UPD.getDescription({
		Fluff = "전우가 놈을 칠 때 너도 같이 쳐!",
		Requirement = "근접 공격",
		Effects = [{
			Type = ::UPD.EffectType.Active,
			Description = [
				"잠금을 해제합니다 [$ $|Skill+rf_follow_up_skill] 아군 공격 중에 아군에게 피해를 입은 적을 공격할 수 있는 스킬입니다. [턴|Concept.Turn]."
			]
		}]
	}),
	RF_FormidableApproach = ::UPD.getDescription({
		Fluff = "가까이 오기 전에 한 번 더 생각하게 해 줘라!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"게인 " + ::MSU.Text.colorPositive("+1") + " [리치|Concept.Reach].",
				"각 포인트별 보너스 [리치 우세|Concept.ReachAdvantage] 당신이 가진 것이 증가했습니다 " + ::MSU.Text.colorPositive("+1") + " 당신의 적에 맞서 [통제 구역|Concept.ZoneOfControl] 그들이 당신을 때릴 때까지. 이 효과는 적중당한 후 만료되지만 다음과 같은 경우에는 재설정됩니다. [통제 구역|Concept.ZoneOfControl] 고장났습니다."
			]
		}]
	}),
	RF_FreshAndFurious = ::UPD.getDescription({
		Fluff = "기운이 넘치는 전투 초반에 가장 큰 피해를 입힌다.",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"이전 [대기|Concept.Wait] 에 [라운드|Concept.Round], 비용이 드는 첫 번째 스킬 사용 [행동력|Concept.ActionPoints] 환불 " + ::MSU.Text.colorPositive("절반") + " 그것의 [행동력|Concept.ActionPoint] 비용.",
				"시작하면 효과가 비활성화됩니다. [턴|Concept.Turn] 와 " + ::MSU.Text.colorNegative("30%") + " 또는 그 이상 [피로|Concept.Fatigue] 사용할 때까지 구축되었으며 비활성화된 상태로 유지됩니다. [$ $|Skill+recover_skill]."
			]
		}]
	}),
	RF_FromAllSides = ::UPD.getDescription({
		Fluff = "종잡을 수 없는 도리깨 궤적으로 적이 다음 수를 읽지 못하게 한다.",
		Requirement = "플레일",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"도리깨의 성공적인 명중은 대상의 공격력을 점진적으로 감소시킵니다. [근접 방어|Concept.MeleeDefense] 그리고 [원거리 방어|Concept.RangeDefense] 스태킹으로 " + ::MSU.Text.colorNegative(-5) + " 하나를 위해 [턴|Concept.Turn].",
				"공격이 머리에 맞으면 효과가 두 배가됩니다."
			]
		}]
	}),
	RF_FruitsOfLabor = ::UPD.getDescription({
		Fluff = "고된 노동으로 단련한 몸이 용병 일에도 쓸모 있다는 걸 금세 깨달았다.",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"[체력|Concept.Hitpoints] 그리고 [최대 피로|Concept.MaximumFatigue] 에 의해 증가된다 " + ::MSU.Text.colorPositive("10%") + " 각각의 기본 값입니다."
			]
		}]
	}),
	RF_Ghostlike = ::UPD.getDescription({
		Fluff = "눈 한번 깜빡이면 날 놓칠걸.",
		Requirement = "총 갑옷 무게는 최대 20입니다."
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"인접한 아군의 수가 인접한 적의 수보다 크거나 같으면 무시할 수 있습니다. [통제 구역|Concept.ZoneOfControl] 다음 동작을 위해."
				"최대 4명으로 근접 무기를 휘두를 때 [리치|Concept.Reach] 다음에서 움직임을 종료합니다. [포위|Concept.Surrounding] 적, 그 적에 대한 다음 공격은 " + ::MSU.Text.colorPositive("25%") + " 더 큰 피해와 " + ::MSU.Text.colorPositive("+20%") + " 갑옷을 무시한 피해. 이 보너스는 공격 이외의 행동을 취하면 만료됩니다."
			]
		}]
	}),
	RF_HaleAndHearty = ::UPD.getDescription({
		Fluff = "이 덩치 좋은 친구는 누구야?",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"피로 회복량이 증가합니다. " + ::MSU.Text.colorPositive("5%") + " 너의 [최대 피로|Concept.MaximumFatigue] 기어 후."
			]
		}]
	}),
	RF_TrickstersPurses = ::UPD.getDescription({
		Fluff = "내 주머니엔 별의별 물건이 다 있지…",
		Effects = [
			{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"두 개의 추가 잠금 해제 [가방 칸|Concept.BagSlots]."
				]
			},
			{
				Type = ::UPD.EffectType.Active,
				Description = [
					"잠금을 해제합니다 [$ $|Skill+rf_pocket_sand_skill] 빈 공간에 모래를 저장할 수 있는 스킬 [가방 칸|Concept.BagSlots] 근처의 적들의 주의를 분산시킵니다."
				]
			}
		]
	}),
	RF_HipShooter = ::UPD.getDescription({
		Fluff = "네 화살이 드리운 그늘 아래 적들이 움츠러들 것이다!",
		Requirement = "활",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"는 [행동력|Concept.ActionPoints] 비용 [$ $|Skill+quick_shot] 에 의해 감소된다 " + ::MSU.Text.colorPositive(1) + ".",
				"이후의 각 [$ $|Skill+quick_shot] 에 [턴|Concept.Turn] 빌드 " + ::MSU.Text.colorNegative("10%") + " 더 [피로|Concept.Fatigue]."
			]
		}]
	}),
	RF_HoldSteady = ::UPD.getDescription({
		Fluff = "병사들에게 자리를 굳게 지키라고 지시하라!",
		Effects = [{
			Type = ::UPD.EffectType.Active,
			Description = [
				"잠금을 해제합니다 [$ $|Skill+rf_hold_steady_skill] 자신과 근처 아군이 얻는 능력이 증가하는 스킬 [근접 방어|Concept.MeleeDefense], [원거리 방어|Concept.RangeDefense] 그리고 [의지|Concept.Bravery] 그리고 존재에 대한 면역 [$ $|Skill+stunned_effect], 뒤로 밀렸거나 붙잡혔습니다."
			]
		}]
	}),
	RF_Hybridization = ::UPD.getDescription({
		Fluff = "손도끼든 투척 도끼든 창이든 투창이든, 맞으면 죽는 건 매한가지야!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"게인 " + ::MSU.Text.colorPositive("10%") + " 당신의 기지 [원거리 공격|Concept.RangeSkill] 추가로 [근접 공격|Concept.MeleeSkill] 그리고 [근접 방어|Concept.MeleeDefense].",
				"투척 공격 이득 " + ::MSU.Text.colorPositive("20%") + " 당신의 현재 [근접 공격|Concept.MeleeSkill] 추가 타격 기회로."
				"1회에 한해 무료로 투척 무기로 전환할 수 있습니다. [턴|Concept.Turn]. 다른 무료 스왑 스킬과 중복되지 않습니다."
			]
		}]
	}),
	RF_Supporter = ::UPD.getDescription({
		Fluff = "네 등은 내가 지킨다!",
		Effects = [
			{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"당 한 번 [턴|Concept.Turn], 인접한 아군을 대상으로 스킬 사용 후 회복 " + ::MSU.Text.colorPositive("3") + " [행동력|Concept.ActionPoints]."
				]
			},
			{
				Type = ::UPD.EffectType.Active,
				Description = [
					"이득 [$ $|Skill+rf_encourage_skill] 증가시킬 수 있는 스킬 [사기|Concept.Morale] 동맹의."
				]
			}
		]
	}),
	InspiringPresence = ::UPD.getDescription({
		Fluff = "용병단 깃발 곁에 서면 병사들은 한계를 뛰어넘을 용기를 얻는다.",
		Requirement = "배너",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"적과 인접한 아군, 또는 적과 인접한 아군과 인접한 모든 아군은 다음을 얻습니다. " + ::MSU.Text.colorPositive("+3") + " [행동력|Concept.ActionPoints] 그들이 시작하는 한 [턴|Concept.Turn] 당신 옆에.",
				"귀하 회사의 구성원만이 이에 대한 동맹자로 간주됩니다. [퍽|Concept.Perk]."
			]
		}]
	}),
	RF_IronSights = ::UPD.getDescription({
		Fluff = "원거리 무기에 조준 장치를 손봐 더 정밀하게 사격할 수 있게 됐다.",
		Requirement = "석궁 또는 총기",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"공격에는 추가 효과가 있습니다. " + ::MSU.Text.colorPositive("25%") + " 머리를 칠 기회.",
				"총기의 헤드샷에는 다음이 적용됩니다. [$ $|Skill+shellshocked_effect] 캐릭터를 제외한 효과 " + ::Const.MoraleStateName[::Const.MoraleState.Ignore] + " [사기|Concept.Morale]."
			]
		}]
	}),
	RF_Kingfisher = ::UPD.getDescription({
		Fluff = "물고기 잡는 법을 가르쳐 주면 평생 제 밥값은 한다.",
		Requirement = "던지기 그물",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"당신의 [턴|Concept.Turn], [그물|Item+throwing_net], 인접한 대상에 대한 모든 성공적인 근접 공격은 명중 확률과 동일한 확률을 갖습니다. [함정|Skill+net_effect] 비용을 지출하지 않고 목표 [그물|Item+throwing_net].",
				"이것을 사용하거나 교환할 수 없습니다 [그물|Item+throwing_net] 대상이 풀려나거나 죽을 때까지. 자유로워지려는 시도는 항상 성공합니다.",
				"대상에서 멀어지면 대상은 그대로 유지됩니다. [갇힌|Skill+net_effect] 하지만 당신은 그것을 잃었습니다 [그물|Item+throwing_net].",
				"게인 " + ::MSU.Text.colorPositive("+2") + " [리치|Concept.Reach] 들고 있는 동안 [그물|Item+throwing_net] 그리고 현재는 아니야 [트래핑|Skill+net_effect] 목표."
			]
		}]
	}),
	RF_KingOfAllWeapons = ::UPD.getDescription({
		Fluff = "모든 무기 위에 군림하는 단 하나의 왕!",
		Requirement = "창으로 찌르는 공격",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"공격의 확률은 다음과 같습니다. " + ::MSU.Text.colorPositive("66%") + " 당신의 현재 [근접 공격|Concept.MeleeSkill] 하부 장갑으로 신체 부위를 타겟으로 삼았습니다."
			]
		}]
	}),
	RF_Legatus = ::UPD.getDescription({
		Fluff = "모두 정복하라!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"트리거 [$ $|Skill+rf_legatus_command_effect] 최대 8타일 떨어진 아군 해골에 효과가 적용됩니다."
			]
		}]
	}),
	RF_Leverage = ::UPD.getDescription({
		Fluff = "무기의 길이를 이용해 머리를 노릴 각도를 잡는다!",
		Requirement = "최대 범위가 2개 타일인 무기",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"2타일 범위의 대상을 공격할 때, " + ::MSU.Text.colorNegative("+20%") + " 머리를 칠 기회."
			]
		}]
	}),
	RF_LineBreaker = ::UPD.getDescription({
		Fluff = "악당 나가신다, 길을 비켜라!",
		Requirement = "방패",
		Effects = [
			{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"[$ $|Skill+knock_back] 이득 " + ::MSU.Text.colorPositive("+15%") + " 칠 기회."
				]
			},
			{
				Type = ::UPD.EffectType.Active,
				Description = [
					"잠금을 해제합니다 [$ $|Skill+rf_shield_bash_skill] 할 수 있게 해주는 스킬 [멍해짐|Skill+dazed_effect] 목표."
				]
			},
			{
				Type = ::UPD.EffectType.Active,
				Description = [
					"잠금을 해제합니다 [$ $|Skill+rf_line_breaker_skill] 한 번의 행동으로 적을 밀어내고 그 자리를 차지할 수 있는 스킬입니다."
				]
			}
		]
	}),
	RF_Poise = ::UPD.getDescription({
		Fluff = "중형 갑옷에 특화된다. 가벼운 차림보다는 둔해도 중무장한 자보다 날렵하다!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"손상 [체력|Concept.Hitpoints] 에 의해 감소된다 " + ::MSU.Text.colorPositive("30%") + " 그리고 갑옷으로 " + ::MSU.Text.colorPositive("20%") + ".",
				"머리와 몸통 갑옷을 착용하면 보너스가 기하급수적으로 떨어집니다. [최대 피로|Concept.MaximumFatigue] 35를 초과하고 귀하의 30%를 초과합니다. [기본|Concept.BaseAttribute] [최대 피로|Concept.Fatigue] 의 효과를 포함하여 [특성|Concept.Trait] 그리고 [영구 부상|Concept.InjuryPermanent].",
				"정신 공격이나 상태 효과로 인한 피해에는 영향을 미치지 않지만, 이를 피하는 데 도움이 될 수 있습니다.",
				"자신이 가지고 있는 대상을 공격할 때 [리치 열세|Concept.ReachAdvantage], 이 단점을 다음과 같이 줄입니다. " + ::MSU.Text.colorPositive(1) + " 만약 당신의 [주도력|Concept.Initiative] 목표보다 큽니다."
				"[$ $|Perk+perk_brawny] 이 혜택에는 영향을 미치지 않습니다.",
				"가지고 있으면 배울 수 없습니다. [$ $|Perk+perk_nimble] 또는 [$ $|Perk+perk_battle_forged]."
			]
		}]
	}),
	RF_LongReach = ::UPD.getDescription({
		Fluff = "네 장창 끝을 보고 있는 놈이 제 등 뒤까지 살피진 못하겠지!",
		Requirement = "폴암",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"2타일 이내의 적도 고려됩니다. [포위|Concept.Surrounding] 해당 대상을 공격하는 모든 아군에 대한 적중률 보너스를 목적으로 귀하가 제공합니다."
			]
		}]
	}),
	RF_ManOfSteel = ::UPD.getDescription({
		Fluff = "가슴의 표식은 희망을 뜻한다.",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"받는 방어구 관통 피해는 다음과 같은 비율로 감소합니다. " + ::MSU.Text.colorPositive("10%") + " 현재 갑옷 조각의 내구도가 적중했습니다."
			]
		}]
	}),
	RF_Mauler = ::UPD.getDescription({
		Fluff = "살갗은 네가 그림을 그리는 화폭이다!",
		Requirement = "클리버를 이용한 절단 공격",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"식칼의 공격은 추가 스택을 적용합니다. [$ $|Skill+bleeding_effect] 목표에.",
				"이미 3중첩 이상 쌓인 대상을 공격할 때 [$ $|Skill+bleeding_effect], 당신은 " + ::MSU.Text.colorPositive("33%") + " 부상을 입힐 수 있는 기회. 공격이 이미 부상을 입혔다면 추가 부상이 적용됩니다."
			]
		}]
	}),
	RF_Marksmanship = ::UPD.getDescription({
		Fluff = "풍속과 거리를 본능적으로 가늠해 적의 약점을 겨눈다!",
		Requirement = "원거리 무기",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"게인 " + ::MSU.Text.colorPositive("10%") + " 당신의 기지 [원거리 공격|Concept.RangeSkill] 추가 최소 및 최대 피해로 표시됩니다."
			]
		}]
	}),
	RF_Menacing = ::UPD.getDescription({
		Fluff = "네 모습만 봐도 적은 잠시 망설인다!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"낮추다 [의지|Concept.Bravery] 인접한 적의 " + ::MSU.Text.colorNegative("-10") + " 동안 [사기 판정|Concept.Morale]."
			]
		}]
	}),
	RF_Mentor = ::UPD.getDescription({
		Fluff = "너를 위대한 전사로 이끌어 주마!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"이 캐릭터의 학생은 [$ $|Skill+rf_mentors_presence_effect] 효과.",
				"학생이 사망하면 이 캐릭터는 즉시 회복됩니다. " + ::MSU.Text.colorPositive("50%") + " 지어진 [피로|Concept.Fatigue] 그리고 [$ $|Skill+adrenaline_effect] 효과."
			]
		}]
	}),
	RF_NailedIt = ::UPD.getDescription({
		Fluff = "머리에 투창 한 방이면 끝이야!",
		Requirement = "원거리 공격",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"게인 " + ::MSU.Text.colorPositive("+25%") + " 2타일 거리에서 머리를 칠 기회가 있습니다. 그 이상의 타일마다 이 보너스는 다음과 같이 감소합니다. " + ::MSU.Text.colorNegative("-5%") + ".",
				"시야가 차단된 상태에서 충돌에 대한 페널티는 다음과 같이 감소합니다. " + ::MSU.Text.colorPositive("50%") + " 2 타일 거리에 있습니다."
			]
		}]
	}),
	RF_OffhandTraining = ::UPD.getDescription({
		Fluff = "보조 손으로 도구를 다루다 보니 양손을 자유자재로 쓰게 됐다.",
		Requirement = "무게가 10 미만인 보조 아이템",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"당 한 번 [턴|Concept.Turn], 무게가 다음보다 작은 보조 품목을 처음 사용하는 경우 " + ::MSU.Text.colorNegative(10) + " 비용 없음 [행동력|Concept.ActionPoints].",
				"그물 장착 시, [$ $|Skill+rf_trip_artist_effect] 효과."
			]
		}]
	}),
	RF_Opportunist = ::UPD.getDescription({
		Fluff = "대장, 약탈하는 거 아닙니다! 제 투창 줍는 겁니다!",
		Requirement = "투척무기",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"전투 중 처음 두 번의 투척 공격에는 [행동력|Concept.ActionPoints] 비용 " + ::MSU.Text.colorPositive("반으로 줄인") + ". 이 효과는 두 번째가 끝날 때까지만 지속됩니다. [턴|Concept.Turn].",
				"탄약을 사용하는 투척 무기를 사용할 때, 적의 시체 위에서 이동을 멈출 때마다 [턴|Concept.Turn], 회복하다 " + ::MSU.Text.colorPositive(1) + " 탄약. 그 직후 다음 투척 공격에는 비용이 듭니다. " + ::MSU.Text.colorPositive("아니") + " [행동력|Concept.ActionPoints] 그리고 빌드 " + ::MSU.Text.colorPositive("50%") + " 덜 [피로|Concept.Fatigue].",
				"시체는 전투당 한 번만 사용할 수 있으며 이 특전을 사용하는 여러 캐릭터가 사용할 수 없습니다."
			]
		}]
	}),
	RF_PassingStep = ::UPD.getDescription({
		Fluff = "단련된 발놀림으로 상대 주위를 춤추듯 돈다!",
		Requirement = "검",
		Effects = [{
			Type = ::UPD.EffectType.Active,
			Description = [
				"잠금을 해제합니다 [$ $|Skill+rf_passing_step_skill] 공격 성공 직후 무시하고 한 타일씩 이동할 수 있는 스킬입니다. [통제 구역|Concept.ZoneOfControl] 감소된 [행동력|Concept.ActionPoints] 비용과 [피로|Concept.Fatigue] 이동 비용.",
				"이동 대상 타일은 적과 인접해야 합니다.",
				"양손 검이나 한손 검에만 사용할 수 있습니다."
			]
		}]
	}),
	RF_PatternRecognition = ::UPD.getDescription({
		Fluff = "수많은 전투를 겪으며 상대의 전투 방식에 재빠르게 적응하는 법을 익혔다.",
		Requirement = "근접 공격",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"상대방이 근접 공격을 하거나 내가 상대를 공격할 때마다 중첩을 얻습니다. " + ::MSU.Text.colorPositive("+3") + " [근접 공격|Concept.MeleeSkill] 그리고 [근접 방어|Concept.MeleeDefense] 남은 전투 동안 해당 상대와 대결합니다.",
				"총 보너스에 도달하면 " + ::MSU.Text.colorPositive(15) + ", 모든 후속 공격은 이를 증가시킵니다. " + ::MSU.Text.colorPositive("+1") + " only."
			]
		}]
	}),
	RF_Phalanx = ::UPD.getDescription({
		Fluff = "고대부터 전해지는 밀집 대형 전투법을 익힌다.",
		Requirement = "관통 공격이 가능한 양손 무기 또는 방패",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"근접전에서 공격하거나 방어할 때 이득을 얻습니다. " + ::MSU.Text.colorPositive("+1") + " [리치|Concept.Reach] 관통 공격이나 방패로 양손 무기를 휘두르는 인접한 아군당.",
				"방어악의 존재를 무시하라 [포위|Concept.Surrounding] 인접한 아군 수만큼 적에 의해. 여기에는 [$ $|Perk+perk_backstabber] 특권.",
				"버클러에는 작동하지 않습니다."
			]
		}]
	}),
	RF_Professional = ::UPD.getDescription({
		Fluff = "너는 경험이 풍부한 직업 전사다!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"처음 두 개를 얻으십시오 [퍽|Concept.Perk] 당신이 접근할 수 있는 무작위 근접 특전 그룹에 속해 있습니다."
			]
		}]
	}),
	RF_PromisedPotential = ::UPD.getDescription({
		Fluff = "대장이 너에게 한번 걸어 보겠다고 했다. 실망시키지 마라!",
		Effects = [{
			Type = ::UPD.EffectType.OneTimeEffect,
			Description = [
				"레벨 11에 도달하면 이 특전은 " + ::MSU.Text.colorPositive("50%") + " 로 대체될 가능성 [$ $|Perk+perk_rf_realized_potential].",
				"실패할 경우 이 특전은 다음으로 대체됩니다. [$ $|Perk+perk_rf_failed_potential] 아무것도하지 않습니다.",
				"A [$ $|Skill+player_character_trait] 가지고있다 " + ::MSU.Text.colorPositive("100%") + " 성공할 기회."
			]
		}],
		Footer = ::MSU.Text.colorNegative("이 특전은 다른 곳에서 특전 포인트를 사용한 후에는 선택할 수 없습니다. 이 혜택은 환불될 수 없습니다.")
	}),
	RF_Onslaught = ::UPD.getDescription({
		Fluff = "대열을 무너뜨리고 허리를 꺾어라. 모조리 짓밟아라!",
		Effects = [{
			Type = ::UPD.EffectType.Active,
			Description = [
				"잠금을 해제합니다 [$ $|Skill+rf_onslaught_skill] 자신과 주변 동료들의 획득량이 증가하는 스킬 [주도력|Concept.Initiative], [근접 공격|Concept.MeleeSkill] 그리고 한 가지 용도는 [$ $|Skill+rf_line_breaker_skill] 2인용 스킬 [라운드|Concept.Round]. 이 사용은 [$ $|Skill+rf_line_breaker_skill] 감소했습니다 [행동력|Concept.ActionPoints] 그리고 [피로|Concept.Fatigue] 비용."
			]
		}]
	}),
	RF_Rattle = ::UPD.getDescription({
		Fluff = "적의 뼛속까지 뒤흔들어 힘을 빼라!",
		Requirement = "망치로 둔기 공격",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"모든 히트에는 다음이 적용됩니다. [$ $|Skill+rf_rattled_effect] 한 사람에게 효과 [턴|Concept.Turn]."
			]
		}]
	}),
	RF_RealizedPotential = ::UPD.getDescription({
		Fluff = "비쩍 마른 몸에 근육이 붙었다. 한때 세상의 밑바닥을 전전하던 자가 이제 어엿한 용병으로 성장했다.",
		Effects = [
			{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"요구하다 " + ::MSU.Text.colorNegative("100%") + " 더 많은 일당.",
				]
			},
			{
				Type = ::UPD.EffectType.OneTimeEffect,
				Description = [
					"사용한 특전 포인트를 모두 환불합니다.",
					"게인 " + ::MSU.Text.colorPositive("+1") + " 퍽 포인트.",
					"게인 " + ::MSU.Text.colorPositive("1") + " 무작위 공유 특전 그룹.",
					"게인 " + ::MSU.Text.colorPositive("2") + " 무작위 무기 특전 그룹.",
					"모든 속성이 증가합니다. " + ::MSU.Text.colorPositive("+15") + "."
				]
			}
		],
		Footer = ::MSU.Text.colorNegative("이 혜택은 환불될 수 없습니다.")
	}),
	RF_Rebuke = ::UPD.getDescription({
		Fluff = "어떻게 하는지 보여 줘!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"이득 " + ::MSU.Text.colorPositive("25%") + " 당신에 대한 근접 공격을 놓친 인접한 상대에게 공격을 수행할 기회입니다. 이 공격에는 비용이 들지 않습니다. [행동력|Concept.ActionPoints] 하지만 충분한 경우에만 발동할 수 있습니다. [피로|Concept.Fatigue] 그것을 감당하기 위해. 해결 확인이 트리거되고, 성공하면 공격이 빌드되지 않습니다. [피로|Concept.Fatigue].",
				"방패 착용 시 확률이 추가로 증가합니다. " + ::MSU.Text.colorPositive("+15%") + " 공격은 어떤 것도 구축하거나 요구하지 않습니다. [피로|Concept.Fatigue]."
			]
		}]
	}),
	RF_RisingStar = ::UPD.getDescription({
		Fluff = "대장 말로는 차근차근 나아가면 언젠가 전설이 될 수 있대!",
		Effects = [
			{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"[경험치|Concept.Experience] 획득량은 다음과 같이 증가합니다. " + ::MSU.Text.colorPositive("20%") + " 다음 5일 동안 [레벨|Concept.Level] 그리고 " + ::MSU.Text.colorPositive("5%") + " 그 후."
				]
			},
			{
				Type = ::UPD.EffectType.OneTimeEffect,
				Description = [
					"게인 " + ::MSU.Text.colorPositive(2) + " 다음 5개 완료 시 혜택 포인트 [레벨|Concept.Level] 이 특혜를 선택한 후."
				]
			}
		],
		Footer = ::MSU.Text.colorNegative("이 혜택은 환불될 수 없습니다.")
	}),
	RF_Sanguinary = ::UPD.getDescription({
		Fluff = "피의 비를 내려라!",
		Requirement = "클리버를 이용한 절단 공격",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"처음 2 [처형|Concept.Fatality] 당신의 동안 [턴|Concept.Turn] 즉시 복원 " + ::MSU.Text.colorPositive(3) + " [행동력|Concept.ActionPoints] 각각.",
				"공격당 한 번만 발동할 수 있습니다."
			]
		}]
	}),
	RF_SavageStrength = ::UPD.getDescription({
		Fluff = "오크도 날 형제라고 부른다!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"는 [피로|Concept.Fatigue] 무기 스킬 비용이 감소합니다. " + ::MSU.Text.colorNegative("25%") + "."
			]
		}]
	}),
	RF_SecondWind = ::UPD.getDescription({
		Fluff = "난 아직 안 끝났어.",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"당신이 사용할 때 [대기|Concept.Wait], 회복하다 [행동력|Concept.ActionPoints] 당신이 가질 때까지 " + ::MSU.Text.colorPositive("4") + " [행동력|Concept.ActionPoints]."
			]
		}]
	}),
	RF_ShieldSergeant = ::UPD.getDescription({
		Fluff = "방패벼어어어억!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"방패를 가진 아군은 다음을 사용합니다. [$ $|Skill+shieldwall] 각 전투가 시작될 때마다 무료로 제공됩니다.",
				"2타일 이내의 동맹국은 [행동력|Concept.ActionPoints] 그리고 [피로|Concept.Fatigue] 비용 [$ $|Skill+shieldwall] 반으로 줄었다. 줄일 수 없습니다. [행동력|Concept.ActionPoints] 비용은 아래 " + ::MSU.Text.colorNegative(2) + ".",
				"당신이 가지고 있다면 [$ $|Skill+shieldwall] 사용 가능한 기술, 시작하거나 종료하는 모든 아군 [턴|Concept.Turn] 당신 옆에 사용할 것입니다 [$ $|Skill+shieldwall] 무료로."
				"당신은 사용할 것입니다 [$ $|Skill+shieldwall] 귀하가 시작하거나 종료하는 한 무료입니다. [턴|Concept.Turn] 다음과 같은 동맹국과 인접해 있습니다. [$ $|Skill+shieldwall] 스킬 사용 가능."
				"이 목적을 위해서는 귀하 회사의 구성원만 동맹자로 간주됩니다. [퍽|Concept.Perk]."
			]
		}]
	}),
	RF_SmallTarget = ::UPD.getDescription({
		Fluff = "온갖 멜론을 표적 삼아 연습한 덕에 머리를 맞히는 데 도가 텄다!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"근접 공격이든 원거리 공격이든 모든 공격은 이득을 얻습니다. " + ::MSU.Text.colorPositive("+10%") + " 머리를 칠 기회."
			]
		}]
	}),
	RF_SoulLink = ::UPD.getDescription({
		Fluff = "죽음이 우릴 갈라놓을 때까지!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"당신의 영혼을 인접한 아군과 연결하여 들어오는 모든 피해의 일부를 다음에게 전달합니다. [체력|Concept.Hitpoints] 무작위로 인접한 아군에게. 이 특전을 갖고 있는 동맹국과는 작동하지 않습니다."
			]
		}]
	}),
	RF_SteadyBrace = ::UPD.getDescription({
		Fluff = "자리를 지키고 시간을 들여 정확히 조준한다.",
		Requirement = "석궁 또는 총기",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"근무 기간 동안 현재 위치에서 이동하지 않은 경우 [턴|Concept.Turn], 석궁의 원거리 공격은 " + ::MSU.Text.colorPositive("+10%") + " 갑옷 관통력과 총기 관통력은 " + ::MSU.Text.colorPositive("+10%") + " 칠 기회."
			]
		}]
	}),
	RF_StrengthInNumbers = ::UPD.getDescription({
		Fluff = "쇠스랑을 든 성난 주민 열 명한테 포위되면 그 잘난 실력도 별 소용 없지!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"인접한 각 아군마다 이득을 얻습니다. " + ::MSU.Text.colorPositive("+2") + " [근접 공격|Concept.MeleeSkill], [원거리 공격|Concept.RangeSkill], [근접 방어|Concept.MeleeDefense] 그리고 [원거리 방어|Concept.RangeDefense] 그리고 " + ::MSU.Text.colorPositive("+5") + " [의지|Concept.Bravery]."
			]
		}]
	}),
	RF_SurvivalInstinct = ::UPD.getDescription({
		Fluff = "살아남고자 하는 의지가 강하다!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"공격을 받을 때마다 중첩 보너스를 얻습니다. [근접 방어|Concept.MeleeDefense] 그리고 [원거리 방어|Concept.RangeDefense] 의 " + ::MSU.Text.colorPositive("+2") + " 실수로 그리고 " + ::MSU.Text.colorPositive("+5") + " 히트에. 이것은 최대로 쌓일 수 있습니다. " + ::MSU.Text.colorPositive("5") + " 실패 횟수 및 최대 횟수 " + ::MSU.Text.colorPositive("2") + " 히트 횟수.",
				"매 시작마다 [턴|Concept.Turn] 나머지 전투 동안 유지되는 공격을 받아 얻은 보너스를 제외하고 보너스는 재설정됩니다."
			]
		}]
	}),
	RF_SweepingStrikes = ::UPD.getDescription({
		Fluff = "무기를 크게 휘둘러 적의 접근을 막아라!",
		Requirement = "근접 [범위 공격|Concept.AOE] 공격"
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"AOE 공격, 적중 여부, 증가 [리치|Concept.Reach] 에 의해 " + ::MSU.Text.colorPositive("+3") + ". 게다가 타겟 적의 [리치|Concept.Reach] 에 의해 감소된다 " + ::MSU.Text.colorPositive("-3") + " 당신을 향한 그들의 공격 때문입니다.",
				"는 [효과|Concept.StatusEffect] 쌓이지 않고 다음 시작까지 지속됩니다. [턴|Concept.Turn]."
			]
		}]
	}),
	RF_SwiftStabs = ::UPD.getDescription({
		Fluff = "빈틈을 만들고 끝장을 내라!",
		Requirement = "단검으로 찌르는 공격"
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"주손 단검으로 공격에 성공하면 [행동력|Concept.ActionPoints] 모든 기술의 비용 " + ::MSU.Text.colorPositive("2") + " 최소한으로 " + ::MSU.Text.colorPositive("2") + " 이 남은 시간 동안 [턴|Concept.Turn].",
				"공격을 놓치거나, 무기를 바꾸거나, 대상을 바꾸거나, 대상을 죽이거나, 단검 공격이 아닌 스킬을 사용하면 효과가 만료됩니다."
			]
		}]
	}),
	RF_SwordmasterBladeDancer = ::UPD.getDescription({
		Fluff = "춤 한번 춰 볼까!",
		Requirement = "검"
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"추가 획득 [주도력|Concept.Initiative] 방어구는 장착된 검의 백분율을 무시합니다.",
				"펜싱이 아닌 검을 사용할 때, [행동력|Concept.ActionPoints] AOE가 아닌 스킬의 비용은 다음과 같이 감소합니다. " + ::MSU.Text.colorPositive(1) + " 그리고 이러한 기술이 쌓이면 " + ::MSU.Text.colorPositive("25%") + " 덜 [피로|Concept.Fatigue].",
				"허용 [$ $|Skill+rf_passing_step_skill] 무언가를 쥐고 있는 동안에도 사용할 수 있다. 방패, 당신의 손에.",
				"[$ $|Skill+rf_passing_step_skill] 비용 " + ::MSU.Text.colorPositive(2) + " 더 적은 [행동력|Concept.ActionPoints] 그리고 빌드 " + ::MSU.Text.colorPositive(2) + " 덜 [피로|Concept.Fatigue], 둘 다 최소 0으로 감소합니다."
			]
		}],
		Footer = ::MSU.Text.colorNegative("Swordmaster 특전 그룹에서는 하나의 특전만 선택할 수 있습니다.")
	}),
	RF_SwordmasterGrappler = ::UPD.getDescription({
		Fluff = "이 세상에서 제자리를 차지하려면 싸워야 한다.",
		Requirement = "검"
		Effects = [
			{
				Type = ::UPD.EffectType.Active,
				Description = [
					"잠금을 해제합니다 [$ $|Skill+rf_swordmaster_kick_skill] 대상을 비틀거리게 만들어 자유 공격을 가할 수 있는 스킬입니다. 공격이 성공하면 대상은 한 타일 뒤로 밀려납니다."
				]
			},
			{
				Type = ::UPD.EffectType.Active,
				Description = [
					"잠금을 해제합니다 [$ $|Skill+rf_swordmaster_push_through_skill] 대상을 비틀거리게 하고 자유 공격을 가할 수 있는 스킬입니다. 공격이 성공하면 대상은 한 타일 뒤로 밀려나고 해당 위치로 이동합니다."
				]
			},
			{
				Type = ::UPD.EffectType.Active,
				Description = [
					"잠금을 해제합니다 [$ $|Skill+rf_swordmaster_tackle_skill] 대상에 대해 자유 공격을 수행합니다. 공격이 성공하면 목표는 다음과 같다. [$ $|Skill+stunned_effect] 그리고 당신은 목표와 위치를 교환합니다."
				]
			}
		],
		Footer = ::MSU.Text.colorNegative("Swordmaster 특전 그룹에서는 하나의 특전만 선택할 수 있습니다.")
	}),
	RF_SwordmasterJuggernaut = ::UPD.getDescription({
		Fluff = "용기와 만용은 종이 한 장 차이다.",
		Requirement = "펜싱이 아닌 양손검"
		Effects = [
			{
				Type = ::UPD.EffectType.Active,
				Description = [
					"잠금을 해제합니다 [$ $|Skill+rf_swordmaster_charge_skill] 이를 통해 적과의 격차를 줄이고 공격하는 모든 작업을 한 번에 수행할 수 있습니다."
				]
			}
		],
		Footer = ::MSU.Text.colorNegative("Swordmaster 특전 그룹에서는 하나의 특전만 선택할 수 있습니다.")
	}),
	RF_SwordmasterMetzger = ::UPD.getDescription({
		Fluff = "검으로도 목은 얼마든지 벨 수 있다!",
		Requirement = "펜싱이 아닌 검"
		Effects = [
			{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"이득 [$ $|Skill+decapitate] 검을 다루는 기술.",
					"검을 사용할 때 Cleaver 특성 그룹의 모든 특성을 얻습니다. 이제 검은 이러한 특전의 목적에 따라 Cleavers 자격을 추가로 획득할 수 있습니다.",
					"검으로 인한 공격이 발생합니다. [$ $|Skill+bleeding_effect] 목표에."
				]
			},
			{
				Type = ::UPD.EffectType.OneTimeEffect,
				Description = [
					"이 캐릭터의 특전 트리에 식칼 특전 그룹을 추가합니다."
				]
			}
		],
		Footer = ::MSU.Text.colorNegative("Swordmaster 특전 그룹에서는 하나의 특전만 선택할 수 있습니다.")
	}),
	RF_SwordmasterPrecise = ::UPD.getDescription({
		Fluff = "눈을 가린 채 바늘귀에 실 꿰는 걸 보여 주지!",
		Requirement = "검"
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"게인 " + ::MSU.Text.colorPositive("+1") + " [근접 공격|Concept.MeleeSkill] 그리고 [근접 방어|Concept.MeleeDefense] 그리고 " + ::MSU.Text.colorPositive("+1%") + " 캐릭터 레벨당 방어력을 무시하고 추가 데미지를 줍니다.",
				"펜싱형 검을 휘두르는 동안 추가로 " + ::MSU.Text.colorPositive("25%") + " 피해량은 방어구를 무시합니다."
			]
		}],
		Footer = ::MSU.Text.colorNegative("Swordmaster 특전 그룹에서는 하나의 특전만 선택할 수 있습니다.")
	}),
	RF_SwordmasterReaper = ::UPD.getDescription({
		Fluff = "수확할 때다!",
		Requirement = "검"
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"는 [행동력|Concept.ActionPoints] AOE 소드 스킬 비용이 감소합니다. " + ::MSU.Text.colorPositive(2) + " 그리고 [피로|Concept.Fatigue] 비용 " + ::MSU.Text.colorPositive("10%") + "."
			]
		}],
		Footer = ::MSU.Text.colorNegative("Swordmaster 특전 그룹에서는 하나의 특전만 선택할 수 있습니다.")
	}),
	RF_SwordmasterVersatileSwordsman = ::UPD.getDescription({
		Fluff = "모든 무기에 통달했다. 어설프게 다루는 무기는 없다.",
		Requirement = "검"
		Effects = [{
			Type = ::UPD.EffectType.Active,
			Description = [
				"작은 전투 중에 전환할 수 있는 세 가지 자세를 잠금 해제합니다. [행동력|Concept.ActionPoints] 그리고 [피로|Concept.Fatigue] 자세를 유지하는 한 지속되는 다양한 효과를 얻기 위한 비용입니다.",
				"[$ $|Skill+rf_swordmaster_stance_half_swording_skill].",
				"[$ $|Skill+rf_swordmaster_stance_reverse_grip_skill].",
				"[$ $|Skill+rf_swordmaster_stance_meisterhau_skill]."
			]
		}],
		Footer = ::MSU.Text.colorNegative("Swordmaster 특전 그룹에서는 하나의 특전만 선택할 수 있습니다.")
	}),
	RF_TargetPractice = ::UPD.getDescription({
		Fluff = "훈련을 거듭하며 탄약을 효율적으로 정리하는 법을 익혔고 명중률도 높아졌다!",
		Requirement = "활",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"원거리 공격 이득 " + ::MSU.Text.colorPositive("+10%") + " 원거리 무기를 휘두르는 적이나 엄폐물에 있지 않은 적에게도 공격할 기회가 있습니다."
			]
		}]
	}),
	RF_Tempo = ::UPD.getDescription({
		Fluff = "상대보다 한발 앞서면 싸움의 흐름을 정할 수 있다!",
		Requirement = "검",
		Effects = [
			{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"게인 " + ::MSU.Text.colorPositive(1) + " 당신의 동안 어떤 목표에 대한 모든 히트 또는 실패에 대해 스택 [턴|Concept.Turn]."
					"각 스택은 [주도력|Concept.Initiative] 에 의해 " + ::MSU.Text.colorPositive("+15") + ". 이 보너스는 다음 번에도 이월됩니다. [턴|Concept.Turn] 단, 첫 번째 스킬을 사용할 때까지만 해당됩니다. [대기|Concept.Wait] 그 [턴|Concept.Turn].",
					"동안 [턴|Concept.Turn] 이득 " + ::MSU.Text.colorPositive("절반") + " 이전에 얻은 스택 중 [턴|Concept.Turn] 추가로 [행동력|Concept.ActionPoints] 그리고 공격이 쌓인다 " + ::MSU.Text.colorPositive("5%") + " 덜 [피로|Concept.Fatigue] 그러한 스택마다."
				]
			}
		]
	}),
	RF_TerrifyingVisage = ::UPD.getDescription({
		Fluff = "네 죽음을 똑똑히 봐라!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"피해를 입히는 각 공격 [체력|Concept.Hitpoints] 정신을 촉발시킨다 [사기 판정|Concept.Bravery] 목표를 위해. 대상이 사기 확인에 실패하면 다음을 얻습니다. [$ $|Skill+horrified_effect] 효과."
			]
		}]
	}),

	RF_TheRushOfBattle = ::UPD.getDescription({
		Fluff = "전투가 끝났는데 수많은 적을 베었다는 것 말고는 아무것도 기억나지 않는 날도 있지!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"공격하거나 공격을 받을 때마다, 맞거나 실패할 때마다 중첩을 얻습니다. " + ::MSU.Text.colorPositive("+5") + " [주도력|Concept.Initiative] 그리고 " + ::MSU.Text.colorPositive("+5%") + " 로 감소 [피로|Concept.Fatigue] 다음 작업이 끝날 때까지의 기술 비용 [턴|Concept.Turn], 최대 " + ::MSU.Text.colorPositive("+25") + " 그리고 " + ::MSU.Text.colorPositive("+25%") + " respectively.",
				"각 기간 동안 얻은 스택 [턴|Concept.Turn] 별도로 추적됩니다."
			]
		}]
	}),
	RF_ThroughTheGaps = ::UPD.getDescription({
		Fluff = "노린 곳에 일격을 꽂아 적 갑옷의 틈새를 찌르는 법을 익힌다!",
		Requirement = "창으로 찌르는 공격",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"공격에는 무작위가 있습니다. " + ::MSU.Text.colorPositive("+10%") + " 에 " + ::MSU.Text.colorPositive("+25%") + " 갑옷 관통."
			]
		}]
	}),
	RF_ThroughTheRanks = ::UPD.getDescription({
		Fluff = "내가 쏜 건 알아서 길을 찾는다.",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"원거리 공격에는 " + ::MSU.Text.colorPositive("50%") + " 아군 사격을 가할 확률이 감소합니다."
			]
		}]
	}),
	RF_TrickShooter = ::UPD.getDescription({
		Fluff = "거침없이 빠르게 사격하는 법을 익힌다!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"이득 [$ $|Perk+perk_rf_hip_shooter] 그리고 [$ $|Perk+perk_rf_flaming_arrows] 특전."
			]
		}]
	}),
	RF_TripArtist = ::UPD.getDescription({
		Fluff = "바닥 구경 한번 시켜 주지.",
		Requirement = "장착된 네트",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"매회 첫 번째 근접 공격 성공 [턴|Concept.Turn] 인접한 대상에게 적용됩니다. [$ $|Skill+staggered_effect] 효과.",
				"무기를 휘두를 때 [리치|Concept.Reach] 4보다 작으면 차이를 얻습니다. [리치|Concept.Reach] 최대 4."
			]
		}]
	}),
	RF_Unstoppable = ::UPD.getDescription({
		Fluff = "한번 기세가 붙으면 누구도 막을 수 없다!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"당신이 당신의 동안 적어도 한 번 공격했다면 [턴|Concept.Turn], 종료하면 [턴|Concept.Turn] 당신의 절반 이하로 [행동력|Concept.ActionPoints] 남은 스택은 최대 5개까지 쌓입니다.",
				"각 스택이 증가합니다. [행동력|Concept.ActionPoints] 에 의해 " + ::MSU.Text.colorPositive("+1") + " 그리고 [주도력|Concept.Initiative] 에 의해 " + ::MSU.Text.colorPositive("+10") + ".",
				"종료하면 모든 스택이 손실됩니다. [턴|Concept.Turn] 당신의 절반 이상을 가지고 [행동력|Concept.ActionPoints] 남은, 사용 [대기|Concept.Wait] 또는 [$ $|Skill+recover_skill], 또는 [$ $|Skill+stunned_effect], 뿌리가 있거나 [$ $|Skill+staggered_effect]."
			]
		}]
	}),
	RF_Vanquisher = ::UPD.getDescription({
		Fluff = "다음은 누구냐?",
		Effects = [
			{
				Type = ::UPD.EffectType.Passive,
				Description = [
					"당 한 번 [턴|Concept.Turn], 상대를 죽인 직후, 죽인 대상의 타일로 이동하면, [행동력|Concept.ActionPoints] 다음 사용 스킬의 비용은 " + ::MSU.Text.colorPositive("반으로 줄인") + "."
				]
			},
			{
				Type = ::UPD.EffectType.Active,
				Description = [
					"잠금을 해제합니다 [$ $|Skill+rf_gain_ground_skill] 인접한 상대를 죽인 직후 무시하고 해당 타일로 이동할 수 있는 스킬입니다. [통제 구역|Concept.ZoneOfControl] 그리고 감소된 [행동력|Concept.ActionPoints] 비용."
				]
			}
		]
	}),
	RF_Retribution = ::UPD.getDescription({
		Fluff = "복수에는 앙갚음 한 숟갈이 제맛이지.",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"타격을 받을 때마다 스택을 얻습니다. " + ::MSU.Text.colorPositive("25%") + " 다음 공격에 대한 피해 보너스.",
				"효과는 다음 공격이나 공격이 끝날 때까지 지속됩니다. [턴|Concept.Turn]."
			]
		}]
	}),
	RF_VengefulSpite = ::UPD.getDescription({
		Fluff = "반드시 대가를 치르게 하겠다!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"근처에 아군이 죽을 때마다 중첩을 얻습니다. " + ::MSU.Text.colorPositive("5%") + " 남은 전투 동안 피해량이 증가합니다."
			]
		}]
	}),
	RF_Vigilant = ::UPD.getDescription({
		Fluff = "전장에서는 순식간에 방어 태세를 취하고, 찰나의 기회에도 공격할 준비가 되어 있어야 한다!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"당신의 마지막에 [턴|Concept.Turn], 이득 " + ::MSU.Text.colorPositive("절반") + " 당신의 남은 것 [행동력|Concept.ActionPoints], 반올림됨, 추가로 [행동력|Concept.ActionPoints] 다음에는 [턴|Concept.Turn]."
			]
		}]
	}),
	RF_VigorousAssault = ::UPD.getDescription({
		Fluff = "이동할 때 붙는 탄력마저 무기로 삼는 법을 익혔다!",
		Requirement = "근접 또는 투척 공격",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"타일 2개를 이동할 때마다 [행동력|Concept.ActionPoints] 다음 공격 비용이 다음만큼 감소합니다. " + ::MSU.Text.colorPositive(1) + " 최소한으로 " + ::MSU.Text.colorPositive(1) + ", 그리고 [피로|Concept.Fatigue] 비용은 다음과 같이 감소됩니다. " + ::MSU.Text.colorPositive("10%") + ".",
				"기다리거나 종료하면 보너스가 사라집니다. [턴|Concept.Turn], 스킬을 사용하거나 투척 무기를 제외하고 무기를 교체합니다."
			]
		}]
	}),
	RF_WeaponMaster = ::UPD.getDescription({
		Fluff = "무기도 연장처럼 저마다 쓰임새가 있다. 그래서 온갖 상황에 대비해 작은 무기고를 통째로 들고 다닌다!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"무기 장착 시 일시적으로 첫 번째와 두 번째 획득 [퍽|Concept.Perk] 그 모든 것의 [퍽|Concept.Perk] 해당하는 그룹이 있는 경우 [퍽|Concept.Perk] 어떤 무기에서든 [퍽|Concept.Perk] 계층에 관계없이 그룹.",
				"에 대한 [비혼합형|Concept.HybridWeapon] 무기, 이것은 세 번째까지 확장됩니다. [퍽|Concept.Perk] 뿐만 아니라."
			]
		}]
	}),
	RF_WearThemDown = ::UPD.getDescription({
		Fluff = "강철과 힘으로 적을 압도하라!"
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"성공적인 공격은 다음을 적용합니다. [$ $|Skill+rf_worn_down_effect] 대상에 영향을 미칩니다.",
				"스태킹을 얻습니다 " + ::MSU.Text.colorPositive("20%") + " 적이 적에게 영향을 미치는 부정적인 상태 효과마다 당신을 공격하려면 두 번의 성공적인 굴림이 필요할 확률입니다. 유효한 상태 효과는 다음과 같습니다: [$ $|Skill+rf_worn_down_effect], [$ $|Skill+stunned_effect], [$ $|Skill+dazed_effect], [$ $|Skill+rf_rattled_effect], [$ $|Skill+net_effect], [$ $|Skill+sleeping_effect], [$ $|Skill+staggered_effect], [$ $|Skill+rooted_effect], [$ $|Skill+web_effect]."
			]
		}]
	}),
	RF_WearsItWell = ::UPD.getDescription({
		Fluff = "오랜 세월 무거운 짐을 짊어진 덕에 용병 장비쯤은 거뜬히 들고 다닌다!",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"처벌은 [최대 피로|Concept.MaximumFatigue] 그리고 [주도력|Concept.Initiative] 머리, 몸, 주손 및 보조 손 슬롯에 장착된 아이템의 양이 다음과 같이 감소합니다. " + ::MSU.Text.colorPositive("20%") + ". 이 효과는 다음과 중첩됩니다. [$ $|Perk+perk_brawny]."
			]
		}]
	}),
	RF_WhirlingDeath = ::UPD.getDescription({
		Fluff = "빙글도는 도리깨 머리로 죽음의 소용돌이를 일으켜라!",
		Requirement = "플레일",
		Effects = [{
			Type = ::UPD.EffectType.Passive,
			Description = [
				"도리깨로 공격할 때마다 전류가 증가합니다. [리치|Concept.Reach] 에 의해 " + ::MSU.Text.colorPositive("+1") + " 다음까지 [턴|Concept.Turn].",
				"양손 도리깨로 전류가 낮은 대상을 공격할 때 [리치|Concept.Reach] 너보다 이득 " + ::MSU.Text.colorPositive("+10%") + " 전류 차이에 따라 머리를 맞힐 확률 [리치|Concept.Reach] 당신과 목표 사이.",
				"당신의 [턴|Concept.Turn], 한손 도리깨로 공격 시, " + ::MSU.Text.colorNegative("50%") + " 전류가 낮은 다른 인접한 적에 대한 피해가 감소합니다. [리치|Concept.Reach] 너보다. 이 추가 공격은 [리치|Concept.Reach].",
				"무시하거나 수정하는 능력을 고려하지 않습니다. [리치|Concept.Reach] 공격 중."
			]
		}]
	})
});

::Reforged.QueueBucket.FirstWorldInit.push(function() {
	foreach (vanillaDesc in vanillaDescriptions)
	{
		::UPD.setDescription(vanillaDesc.ID, vanillaDesc.Key, ::Reforged.Mod.Tooltips.parseString(vanillaDesc.Description));
	}

	foreach (key, string in ::Const.Strings.PerkDescription)
	{
		local parsedString = ::Reforged.Mod.Tooltips.parseString(string);
		::Const.Strings.PerkDescription[key] = parsedString;
	}

	foreach (perkDef in ::Const.Perks.LookupMap)
	{
		perkDef.Tooltip = ::Reforged.Mod.Tooltips.parseString(perkDef.Tooltip);
	}
});

::Const.Strings.Distance[4] = "멀리";
::Const.Strings.Distance[5] = "아주 멀리";
