// Remove several vanilla "tips" that barely classify as such or are pure flavor
for (local index = (::Const.TipOfTheDay.len() - 1); index >= 0; index--)
{
	switch (::Const.TipOfTheDay[index])
	{
		case "As brothers we fight, as brothers we die!":
		case "Learn the 'Rotation' or 'Footwork' perks for additional mobility in battle.":
		case "A life can be worth little in this world.":
		case "Try the Ironman mode to experience Battle Brothers the way it's meant to be played.":	 // not advisable while the mod is still riddled with potential bugs
		case "Dying is part of a mercenary's job description.":
		case "Try playing a campaign in veteran mode once you've gained some experience - it's the recommended difficulty.":
		case "Do the job. Survive. Get paid.":
		case "The 'Lone Wolf' perk is not affected by nearby dogs or allies that are not part of your company.":
		case "The 'Fast Adaptation' perk reduces variance of randomness.":
		case "Losing is fun.":
		case "Some people will use you and throw you away.":
		case "With the \'Beast Slayers\' origin you\'ll have an easier time tracking beasts and get more trophies from any of those you slay.":
		case "With the \'Lone Wolf\' origin you\'ll have a player character in the world. If you die, the campaign ends.":
		case "With the \'Peasant Militia\' origin you can take up to 16 men into battle at once.":
		case "With the \'Cultists\' origin your god will demand sacrifices from you, but also bestow boons upon those loyal to him.":
		case "With the \'Band of Poachers\' origin you\'ll move faster on the worldmap.":
		case "With the \'Trading Caravan\' origin you\'ll get better prices for both buying and selling.":
		case "With the \'Manhunters\' origin you can make prisoners after every battle against humans and force them to fight for you.":
		case "With the \'Gladiators\' origin you start with three powerful characters, but losing all three will end your campaign.":
		case "With the \'Anatomists\' origin, defeating new enemies grants potions that mutate your men and grant them special abilities.":
		case "With the \'Oathtakers\' origin, instead of ambitions you\'ll pick oaths that grant special boons and burdens.":
		case "Consider putting injured characters in reserve until their wounds have healed.":
		case "Consider building up a reserve roster and rotating your men, so you can more easily deal with losses down the road.":
		case "Having men of different backgrounds in your company may enable you to perform different actions in events.": // Vanilla has another tip which conveys this information more concisely and completely.
		case "You don\'t have to be a hero, you\'re running a business.":
		case "Drag and drop your men in the inventory screen to where you want them to be in your formation.":
		case "Consider forming a shieldwall when surrounded.":
		case "Conserve your stamina when in prolonged engagements.":
		case "Success in Battle Brothers is also about picking the right fights.":
		case "Undead are unaffected by fatigue and morale.":
		case "Crossbows require less skill to fire accurately than bows, but are slower to use.":
		case "Each type of weapon has advantages and disadvantages.":
		case "Clubs and maces can stun or incapacitate targets.":
		case "Try to save some crowns for when things turn sour.":
		case "Longswords and Greatswords can hit multiple targets with one strike.":
		case "Spears are good defensive weapons due to their Spearwall ability.":
		case "Use terrain and chokepoints to your advantage.":
		case "The higher their level, the more your men will demand in wages.":
		case "Skeletons are highly resistant to ranged attacks and fire.":
		case "Heavy armor offers great protection, but also slows down the wearer and makes him tire more quickly.":
		case "Heavy helmets can be hard to breathe in and limit the field of vision.":
		case "Warhammers and Military Picks can make short work of heavy armor.":
		case "The Billhook, Pike and Longaxe can attack over 2 tiles, unlike most other melee weapons.":
		case "A human is no match for an adult orc physically.":
		case "Orcs rely on raw power and physical prowess.":
		case "A goblin is no match for an adult human physically, so they rely on wit and dirty tricks.":
		case "Geists are lost between the physical world and the world beyond, constantly shifting between the two.":
		case "Two-handed axes can hit up to 6 targets with a single round swing.":
		case "Roads are the fastest way to travel over land, but not always the safest.":
		case "Forests can hide many dangers within.":
		case "Always keep a good stock of provisions - lest your men starve and desert you!":
		case "Wiedergangers are the dead walking again.":
		case "Difficult terrain, such as mountains and swamp, has your men use more supplies on the worldmap.":
		case "If you can not win, retreat to fight another day.": // vanilla has another tip that conveys the same message
		case "Try to negotiate better payment for your contracts.":
		case "Try to negotiate payment modalities that guarantee you the most money for contracts.":
		case "Throwing weapons can be deadly on short distances, but their accuracy drops sharply the farther away the target.":
		case "You can find contract offers in the top left of settlement screens.":
		case "Cleavers can inflict bleeding wounds.":
		case "Stunned characters get no attack of opportunity when someone moves inside their zone of control.":
		case "The minimum hit chance for any attack is 5%, and the maximum hit chance for any attack is 95%.":
		case "The natural habitat of direwolves is the forest.":
		case "You can enable faster AI turns in the options menu.":
			::Const.TipOfTheDay.remove(index);
			break;
		case "Flails ignore the defense bonus of shields.":
			::Const.TipOfTheDay[index] = "리포지드: Flails와 유사하게 Bolas는 방패의 방어 보너스를 무시하지만 'Shieldwall'의 방어 보너스는 무시하지 않습니다.";
			break;
	}
}

::Const.TipOfTheDay.extend([
	"플레이어가 제어하지 않는 캐릭터는 활, 석궁, 총의 탄약이 부족하지 않습니다.",
	"개편됨: 캐러밴 임무를 수행하는 동안 같은 타일에만 들어가는 대신 최대 2타일 떨어진 마을에 들어갈 수 있습니다.",
	"모드 옵션에는 삶의 질과 관련하여 많은 사용자 정의가 있습니다.",
	"사기 점검은 인접한 모든 적에게는 더 어렵고 모든 인접한 아군에게는 더 쉽습니다.",
	"개편됨: 활성 계약을 클릭하면 세계 지도에서 해당 목표에 집중할 수 있습니다(알고 있는 경우).",
	"개편됨: 선술집에 관한 소문은 결코 당신이 이미 발견한 전설적인 장소에 관한 것이 아닙니다.",
	"리포지드: 살인마와 관계없이 당신의 진영이 해당 적이 받은 총 피해의 50% 이상을 입힌 경우에만 적들이 전리품을 떨어뜨립니다.",
	"리포지드: 형제가 적에게 얼마나 많은 피해를 입혔는지에 따라 살해된 적으로부터 경험치를 얻습니다.",
	"Reforged: 모드 옵션에서 캐릭터와 적의 전술적 툴팁을 맞춤 설정할 수 있습니다.",
	"리포지드: 언데드는 특정 부상을 입을 수 있지만, 부상을 입히는 데는 평소보다 더 많은 피해가 필요합니다.",
	"리포지드: Oathtaker 형제는 일반 오리진을 플레이할 때 정기적으로 새로운 무작위 맹세를 합니다.",
	"다채로운 사각형이 보이면 게임을 저장하지 마세요. 그렇지 않으면 저장 파일이 손상될 수 있습니다.",
	"개편됨: 캐릭터가 착용한 무기는 파손되더라도 전투 후에 항상 떨어지고 복구됩니다."
]);
