
::Const.Strings.LegendaryLocationAdjective <- [
	"overwhelming",
	"mystical",
	"mindblowing",
	"한 번도 본 적이 없는",
	"spectacular",
	"surreal"
];

::Const.Strings.RumorsUniqueLocation <- [
	[	// Doesn't include the name but the information is correct
		"{계속 얘기가 들려오는데 | 어떤 여행자가 뭔가를 언급했어요 | 어떤 순례자가 뭔가를 언급했습니다.} 약 %legendaryLocationAdjective% {장소 | 위치} {%direction% 여기에서 | %distance% 여기에서 %terrain% }"
	],
	[	// Include the exact name but the other information is usually randomly true or fake
		"{탐험가 | 지도 제작자} 최근에 들렀는데, 찾았다고 하더군요 {a | 일부} %legendaryLocationAdjective% {장소 | 위치} %distance% 여기에서 {그 사람은 | } {전화하다 | 명명된} %location%. 그의 입에서 좀 더 자세한 내용이 흘러나왔더라면...",
		"{어떤 남자가 %randomtown% | %randomname%} 나한테 말했어 %location% 다른 날. 그는 그렇다고 말했다 {%direction% | %wrongDirection% | %wrongDirection%} 여기에서. {하지만 그 사람은 술에 취해서 그 말을 믿을 수 없었어요 | 아마 제가 잘못 기억하고 있는 것 같아요}.",
		"이 있습니다 {도시의 | 늙은} {이야기 | 전설 | 이야기} 약 {장소 | 위치} 전화하다 %location%. {일부 | 일부 사람들} {말하다 | 주장하다} 그것은 {%distance% 여기에서 %terrain% 다른 사람들이 평가하는 동안 %wrongDistance% 여기에서 %wrongTerrain% | %wrongDistance% 여기에서 %wrongTerrain% 다른 사람들이 평가하는 동안 %distance% 여기에서 %terrain%}.",
		"그냥 {다른 날 | 어제 | 오늘 아침} 취한 사람 {말하고 있었다 | 올라왔다} 나에게 그가 말했다. {발견 | 발견 | 우연히 발견하다} {a | 일부} {장소 | 위치} 전화하다 %location% 그의 모험 중 하나에서. 처음에 그는 그렇다고 주장했다. {%direction%, 그리고 그는 그것이라고 스스로 정정했습니다. %wrongDirection% | %wrongDirection%, 그리고 그는 그것이라고 스스로 정정했습니다. %direction%}. 결국 그는 {주장했다 | 맹세하다} 그것에 대해 {%direction% | %wrongDirection%}",
		"{일부 | %randomname%s} 꼬마가 나한테 말했어 {이 | a} 이야기 {다른 날 | 어제 | 오늘 아침}. 그것은 대략 {a | 일부} {장소 | 위치} {그가 전화한다 | 전화하다} %location%. 그는 나에게 그럴 거라고 말했어 {%distance% | %wrongDistance%} 에 {%direction% | %wrongDirection%} 여기에서, {%terrain% | %wrongTerrain%}. 당신 {알아요, 내 생각엔 그 이야기가 | 이거 좀 믿어? 나도 마찬가지야.} 부하 {말 | 말 | 말 | 말 | 보류를 해제하다} 똥."
	]
]
