::Const.Strings.RF_BansheeNames <- [
	"시빌라",
	"엘스베트",
	"로헬리네",
	"벨다",
	"게르트룬",
	"브리다",
	"마르가",
	"엘스빈",
	"힐다",
	"프레이야",
	"메히트힐트",
	"브룬힐트",
	"쿠니군데",
	"우르줄라",
	"마르가레테",
	"구드룬",
	"이졸데"
];
local more = [];
foreach (n in ::Const.Strings.RF_BansheeNames)
{
	more.push("Lady " + n);
	more.push("Mother " + n);
	more.push("Old " + n);
	more.push("Dame " + n )
};
::Const.Strings.RF_BansheeNames.extend(more);

::Const.Strings.RF_BansheeTitles <- [
	"애도하지 않는 자",
	"망가진 자궁의",
	"절단된",
	"할로우",
	"매장되지 않은",
	"미망인",
	"애도자",
	"더지와이프",
	"비명을 지르는 대모",
	"사랑이 없는",
	"맹세 없는 자",
	"베일에 싸인 자"
];
::Const.Strings.RF_VampireLordNames <- [
	"킨파엘",
	"두라델",
	"오베론",
	"레스타트",
	"이카보드",
	"모르타스",
	"드레이븐",
	"드레간",
	"자디무스"
	"말라키",
	"다보린",
	"라파엘",
	"멜키오르"
	"블라디미르",
	"자로스",
	"오르페우스"
];
::Const.Strings.RF_VampireLordTitles <- [
	"임팔러",
	"불멸의",
	"영생하는",
	"유혈 편지",
	"불멸의",
	"크림슨"
	"스컬지",
	"악몽",
	"테러",
	"악마",
	"악마",
	"악마",
	"새디스트",
	"악순환"
];
::Const.Strings.RF_AncientDeadCommanderTitles <- [
	"돌아온",
	"복원자",
	"고대",
	"파괴자",
	"헤럴드",
	"발굴된 것",
	"명예로운 자",
	"수비수",
	"영광스러운",
	"선호하는"
];
::Const.Strings.RF_ManAtArmsTitles <- [
	"황소 %factionname%",
	"방패 %factionname%",
	"검 %factionname%",
	"망치 %factionname% ",
	"영웅 %factionname% ",
	"정육점",
	"황소",
	"곰",
	"자랑스러운",
	"영웅",
	"용감한",
	"강철잡이",
	"오크살해자",
	"그린스킨의 베인",
	"십자군",
	"파괴할 수 없는 것",
	"쓴 칼날",
	"쓴강철",
	"사자",
	"용기있는",
	"광휘검",
	"용감한",
	"맹세를 지키는 자",
	"무패",
	"강철태생"
];
::Const.Strings.RF_FencerTitles <- [
	"자랑스러운",
	"영웅",
	"용감한",
	"정육점",
	"강철잡이",
	"검 %factionname%",
	"영웅 %factionname% ",
	"자랑스러운",
	"쓴 칼날",
	"쓴강철",
	"늑대",
	"용기있는",
	"광휘검",
	"빠른",
	"쾌검",
	"가시",
	"심장 관통자",
	"꼬치",
	"장검",
	"맹세를 지키는 자",
	"팔콘",
	"호크",
	"독수리",
	"블레이드의 %factionname% ",
	"노래하는 칼날"
];
::Const.Strings.RF_ZweihanderTitles <- [
	"정육점",
	"황소",
	"곰",
	"황소 %factionname%",
	"자랑스러운",
	"영웅",
	"용감한",
	"정육점",
	"강철잡이",
	"방패 %factionname%",
	"검 %factionname%",
	"영웅 %factionname% ",
	"자랑스러운",
	"오크살해자",
	"그린스킨의 베인",
	"십자군",
	"무패",
	"쓴 칼날",
	"쓴강철",
	"사자",
	"용기있는",
	"광휘검",
	"용감한",
	"맹세를 지키는 자",
	"노래하는 칼날",
	"회오리바람",
	"폭풍우",
	"냉철",
	"강철태생"
];
::Const.Strings.RF_DraugrNames <- [
	"스카른",
	"흐로드",
	"바르",
	"켈드",
	"라스크",
	"울드",
	"스레그",
	"모르른",
	"그리스",
	"야른",
	"발크",
	"허스크",
	"드렝",
	"오름",
	"룬",
	"카엘",
	"피오르",
	"스텐",
	"위르",
	"크로스",
	"흐림르",
	"발",
	"스켈드르",
	"보르",
	"다그룬",
	"카른",
	"울스",
	"레스",
	"브란",
	"골"
];
::Const.Strings.RF_DraugrTitles <- [
	"무덤결속자",
	"불타지 않은 자",
	"언덕 감시자",
	"맹세한 돌",
	"그의 마지막 친족",
	"차가운 눈",
	"케른 왕",
	"침묵의 챔피언",
	"서리결속자",
	"서리가 낀",
	"무덤의 주인",
	"언제나 깨어있는",
	"무덤 군주",
	"뼈 왕관을 쓴",
	"잠 못 드는 사람",
	"무덤이 지켜졌다",
	"킨바운드",
	"기억된 것",
	"불안한",
	"스톤 블러드"
];
::Const.Strings.CharacterNames.extend([
	"아그나르",
	"알라르트",
	"알라리크",
	"알베르트",
	"알브테루스",
	"알드윈",
	"안스가르",
	"바둘프",
	"발다리히",
	"발도",
	"발도빈",
	"볼드윈",
	"바라노르",
	"베르틸로",
	"비외른",
	"브란도",
	"부르크하르트",
	"카롤루스",
	"켄리크",
	"콘라트",
	"다그핀",
	"던스턴",
	"에크하르트",
	"에드가",
	"에기노",
	"엘로프",
	"에멜리히",
	"에스비크",
	"파라문트",
	"파르발트",
	"필리베르트",
	"프랑코",
	"프리두헬름",
	"가우프리트",
	"가우트빈",
	"게르볼트",
	"길베르트",
	"기젤베르트",
	"기스문트",
	"고드리크",
	"그림",
	"하두베르트",
	"하가노",
	"해럴드",
	"하르트빈",
	"하이드리히",
	"헬름프리트",
	"헬모",
	"헬무트",
	"헤르만",
	"쿠노",
	"람베르트",
	"란둘프",
	"란초",
	"레오프리크",
	"레오나르트",
	"로이다가르",
	"로이타르",
	"로이트빈",
	"만노",
	"마이노",
	"마인라트",
	"밀로",
	"노르베르트",
	"오도",
	"올비르",
	"오스윈",
	"피핀",
	"란둘프",
	"레긴",
	"라이날트",
	"라인하르트",
	"리하르트",
	"롤란트",
	"지기마르",
	"질반",
	"시워드",
	"스벤",
	"테오",
	"테오다르",
	"티모",
	"발데마르",
	"베레문트",
	"발도",
	"발도마르",
	"발터",
	"비달트",
	"비도",
	"비간트",
	"비크하르트",
	"빌프레트",
	"볼프하르트",
	"울프리크"
]);
::Const.Strings.SwordmasterTitles.extend([
	"표범",
	"킨",
	"검성",
	"결투사",
	"회오리바람",
	"강철의 폭풍우",
	"춤추는 강철"
]);

// This removes all duplicate CharacterNames. This line is redundant for Vanilla + Reforged because our additional names are already checked for duplicates
// Any mod that adds names after ours may re-introduce duplicates. This is not game-breaking but still undeLorded
::Const.Strings.CharacterNames = ::MSU.Array.uniques(::Const.Strings.CharacterNames);

foreach(characterName in ::Const.Strings.CharacterNames)
{
	::Const.Strings.KnightNames.push("Sir " + characterName);
}

// This removes all duplicate KnightNames. This is important because Vanilla has KnightNames that also exist as CharacterNames.
::Const.Strings.KnightNames = ::MSU.Array.uniques(::Const.Strings.KnightNames);
::Const.Strings.RF_KnightAnointedNames <- ::Const.Strings.KnightNames.map(@(name) ::String.replace(name, "Sir", "Lord"));

// Remove The Robber Baron as a bandit leader name because we have a RobberBaron entity in Reforged
::MSU.Array.removeByValue(::Const.Strings.BanditLeaderNames, "강도 남작");

// Remove the Fencer and Bladedancer as Swordmaster titles name because we have Swordmaster perks with these names and if the Swordmaster doesn't have the appropriate perk it can be confusing
::MSU.Array.removeByValue(::Const.Strings.SwordmasterTitles, "펜싱 선수");
::MSU.Array.removeByValue(::Const.Strings.SwordmasterTitles, "Bladedancer");

::Const.Strings.SouthernNames.extend([
	"아딜",
	"아킬",
	"아크람",
	"아민",
	"안와르",
	"아심",
	"바드르",
	"바시르",
	"파하드",
	"파이살",
	"파리드",
	"가산",
	"하비브",
	"하디",
	"하킴",
	"하리스",
	"이드리스",
	"이흐산",
	"이마드",
	"임란",
	"이샤크",
	"자파르",
	"자말",
	"지브릴",
	"카림",
	"칼리드",
	"칼릴",
	"라티프",
	"라이스",
	"마흐디",
	"마히르",
	"마르완",
	"무니르",
	"나디르",
	"나지브",
	"나지",
	"나우팔",
	"카디르",
	"카심",
	"카이스",
	"라피크",
	"사드",
	"사프완",
	"살라",
	"살림",
	"사미르",
	"수하일",
	"탈리브",
	"사비트",
	"와히드",
	"와카스",
	"야시르",
	"자파르",
	"자이드",
	"지샨",
	"지야드",
	"주하이르",
	"자히드",
	"주바이르"
]);

// The array contains some duplicates even in vanilla
::Const.Strings.SouthernNames = ::MSU.Array.uniques(::Const.Strings.SouthernNames);

foreach (i, name in ::Const.Strings.SouthernNames)
{
	::Const.Strings.SouthernNamesLast.push("Ibn " + name);
	::Const.Strings.SouthernNamesLast.push("Al-" + name);
	// For Officer Titles we push all Al- variants but fewer Ibn variants
	// and a small number of long variants of the form "Al-Name Ibn Name"
	// this is similar to the distribution of vanilla SouthernOfficerTitles
	::Const.Strings.SouthernOfficerTitles.push("Al-" + name);
	if (i % 3 == 0)
	{
		::Const.Strings.SouthernOfficerTitles.push("Ibn " + name);
	}
	if (i % 5 == 0)
	{
		::Const.Strings.SouthernOfficerTitles.push("Al-" + name + " Ibn " + ::MSU.Array.rand(::Const.Strings.SouthernNames));
	}
}

::Const.Strings.SouthernNamesLast = ::MSU.Array.uniques(::Const.Strings.SouthernNamesLast);
::Const.Strings.SouthernOfficerTitles = ::MSU.Array.uniques(::Const.Strings.SouthernOfficerTitles);
