this.rf_oathtakers_take_oaths_in_regular_origins_event <- ::inherit("scripts/events/event", {
	m = {
		TriggerEveryXDays = 15,
		Oathtakers = [],

		// WeightedContainer set up during create function
		__PotentialOaths = null,

	},
	function create()
	{
		this.m.__PotentialOaths = ::MSU.Class.WeightedContainer();
		foreach (path in ::IO.enumerateFiles("scripts/skills/traits"))
		{
			if (split(path, "/").top().find("oath_of") != null)
			{
				this.m.__PotentialOaths.add(path);
			}
		}

		this.m.ID = "event.rf_oathtakers_take_oaths_in_regular_origins";
		this.m.IsSpecial = true;
		this.m.Title = "맹세의 전환";
		this.m.Screens.push({
			ID = "A",
			Text = "",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					// Text set during start function of this screen.
					Text = "",
					function getResult( _event )
					{
						return 0;
					}
				}
			],
			function start( _event )
			{
				if (_event.m.Oathtakers.len() == 1)
				{
					// Text generated and edited by LordMidas using ChatGPT
					this.Text = "[img]gfx/ui/events/event_183.png[/img]{당신은 눈에 띈다 %bro1% 새벽이 되기 전에, 모닥불이 꺼지고 안개가 낮게 드리워진 캠프의 가장자리로 이동했습니다. 오직 그만이 들을 수 있는 심판을 기다리고 있는 것처럼 갑옷을 입고 가만히 서 있는 고독한 인물.\n\n그는 천천히 조심스럽게 흙 속에 무릎을 꿇었습니다. 기도가 없습니다. 속삭이지 마세요. 그가 작은 토큰을 내려놓을 때 건틀릿이 땅을 스치는 소리만 들렸습니다. 계속해서 다루다 보니 얇아지는 철제 부적. 당신은 마치 그가 할당한 무게가 여전히 남아 있는지 확인하는 것처럼 전투 후에 그가 그것을 만지는 것을 보았습니다. 이제 그는 마침내 그 목적을 달성한 것처럼 주저 없이 그것을 남겨둔다.\n\n잠시 후 그는 허리띠에 있는 주머니에서 또 다른 물건을 꺼냅니다. 희미한 빛 속에서는 그것을 식별할 수 없습니다. 아마도 조각된 나무 조각일 수도 있고, 노끈으로 묶인 천 조각일 수도 있습니다. 그는 경건하지도 부주의하지도 않은 동작으로 그것을 마구에 묶습니다. 전투 전에 끈을 조이고 그에 따른 부담을 받아들이는 군인과 비슷합니다.\n\n마침내 그가 일어서자 그의 얼굴은 아무것도 드러내지 않습니다. 그러나 그의 태도에는 미묘한 변화가 있는데, 그것은 당신이 남자 옆에서 여러 날 동안 행진한 후에만 드러나는 종류입니다. 새로운 긴장감. 새로운 조용함. 새로운 결심. 맹세자는 옛 맹세를 버리고 새로운 맹세를 했습니다. 그가 차갑고 어둠 속에서 결정한 것이 무엇이든 그와 당신을 위한 앞으로의 전투를 결정하게 될 것입니다.}";

					this.Options[0].Text = "나는 그를 결코 이해하지 못할 것입니다.";
				}
				else
				{
					// Text generated and edited by LordMidas using ChatGPT
					this.Text = "[img]gfx/ui/events/event_183.png[/img]{당신은 움직임의 낮은 중얼거림에 작은 시간에 깨어납니다. 갑옷이 바뀌고, 부츠가 흙을 긁는 소리, 캠프를 깨우지 않으려는 사람들의 조용한 달가닥거리는 소리. Oathtakers는 깨어 있습니다... 항상 정상적인 판매 검보다 먼저 깨어 있습니다.\n\n그들은 진영 가장자리에 모여 마치 의식보다는 형벌을 준비하는 사람들처럼 빽빽한 원을 이룬다. 고개를 숙였다. 당신은 그들이 이런 짓을 하는 것을 본 적이 있지만, 그것이 자백과 비슷한지 아니면 군인이 자신의 장비에 대해 냉담하게 평가하는 것과 비슷한지 아직 결정하지 못했습니다. 아마도 Oathtakers에게는 차이가 없을 것입니다.\n\n얼마 후 %bro1% 땀과 시간으로 긁힌 쇠부적인 증표를 꺼내어 흙바닥에 떨어뜨린다. %bro2% 피가 말라붙은 천 조각을 내려놓으니, 누가 자신의 것인지 다른 사람의 것인지 알 수 있습니다. 이것은 그들이 이전에 행했던 맹세의 잔재입니다. 부담을 지고, 작업을 완료하고, 서약을 어기거나 완료했습니다. 그들이 유물을 버리는 방식에 대해서는 아무것도 알려주지 않습니다.\n\n당신은 다음과 같이 시청합니다 %bro1% 그 사람에게서 다른 토큰을 검색합니다. 다른 사람들은 방패에 새로운 홈을 새기거나 손목에 끈을 묶습니다. %bro2% 마치 자신의 가슴에 판결을 내리듯이 가죽 조각에 못을 박아 마구에 고정합니다. 이러한 제스처의 의미가 무엇이든 그것은 당신을 위한 것이 아닙니다. 당신은 새로운 약속이 취해졌음을 이해합니다.\n\n원이 무너지면 남자들은 냉혹한 결의에 가까운 확고함을 가지고 제자리로 돌아갑니다. 그들의 얼굴에는 피를 흘리기를 기대하고 목적을 가지고 피를 흘리려는 남자의 공허한 평온함이 있습니다. 그들의 상징이 무엇을 나타내든, 그들은 세상 자체가 그들의 선택에 따라 결정된다고 믿는 사람들의 확신을 가지고 그것을 지닙니다.\n\n낮은 들판에서 기어 올라오는 안개처럼 처음에는 고요하다가 나중에는 부인할 수 없게 되는 그들의 의식의 무게가 캠프 위에 자리잡는 것을 느낍니다. Oathtakers는 오래된 서약을 버리고 새로운 서약을 했습니다. 그들이 차갑고 어둠 속에서 결정한 것이 무엇이든 그들과 여러분을 위한 앞으로의 전투를 결정하게 될 것입니다.}";

					this.Options[0].Text = "나는 결코 그들을 이해하지 못할 것입니다.";
				}

				this.List = [];

				foreach (bro in _event.m.Oathtakers)
				{
					local currentOath;
					local currentOathScript;
					foreach (s in bro.getSkills().m.Skills)
					{
						if (!s.isType(::Const.SkillType.Trait))
							continue;

						local script = ::IO.scriptFilenameByHash(s.ClassNameHash);
						if (_event.m.__PotentialOaths.contains(script))
						{
							currentOathScript = script;
							currentOath = s;
							break;
						}
					}

					if (currentOath != null)
					{
						bro.getSkills().remove(currentOath);
					}

					local newOath = ::new(_event.m.__PotentialOaths.roll(currentOathScript == null ? null : [currentOathScript]));
					bro.getSkills().add(newOath);

					this.List.push({
						id = 16,
						icon = newOath.getIcon(),
						text = format("%s%s%s",
								bro.getName(),
								currentOath != null ? " completes " + currentOath.getName() + " and" : "",
								" takes " + newOath.getName())
					});
				}
			}
		});
	}

	function isValid()
	{
		if (::World.Assets.getOrigin().getID() == "scenario.paladins")
		{
			return false;
		}

		local currentDay = ::World.getTime().Days;
		if (currentDay % this.m.TriggerEveryXDays != 0)
		{
			return false;
		}

		local flagID = this.m.ID + "_LastDay";

		if (::World.Flags.has(flagID) && currentDay == ::World.Flags.get(flagID))
		{
			return false;
		}

		foreach (bro in ::World.getPlayerRoster().getAll())
		{
			if (bro.getBackground().getID() == "background.paladin")
			{
				::World.Flags.set(flagID, currentDay);
				return true;
			}
		}

		return false;
	}

	function onPrepare()
	{
		this.m.Oathtakers = ::World.getPlayerRoster().getAll().filter(@(_, _bro) _bro.getBackground().getID() == "background.paladin");
	}

	function onPrepareVariables( _vars )
	{
		local bros = clone this.m.Oathtakers;

		_vars.push([
			"bro1",
			bros.remove(::Math.rand(0, bros.len() - 1)).getName()
		]);

		if (bros.len() != 0)
		{
			_vars.push([
				"bro2",
				bros.remove(::Math.rand(0, bros.len() - 1)).getName()
			]);
		}
	}

	function onClear()
	{
		this.m.Oathtakers.clear();
	}
});
