// All event text written by ThePlahunter
this.rf_old_swordmaster_scenario_old_age_event_1 <- this.inherit("scripts/events/event", {
	m = {
		Swordmaster = null
	},
	function create()
	{
		this.m.ID = "event.rf_old_swordmaster_scenario_old_age_1";
		this.m.IsSpecial = true;
		this.m.Screens.push({
			ID = "A",
			Text = "[img]gfx/ui/events/event_17.png[/img]{%SPEECH_START%스트라이크! 지키다! 역추진! 적을 노출시켜 쓰러뜨릴 수 있도록 하세요!%SPEECH_OFF%당신은 와드를 향해 명령을 내리며, 와드가 완벽하게 조합을 마스터할 때까지 생생한 훈련을 반복합니다. 당신의 병동을 보면 가슴이 뿌듯해집니다. %randombrother%, 대각선 슬래시를 완벽하게 실행한 후 가드를 뒤로 당기고 반격을 날려버립니다. 공격을 위쪽으로 밀고 블레이드를 밀어 파트너의 가슴에 바로 밀어 넣습니다. 그는 당신의 시선을 만날 때까지 여러 다른 파트너와 함께 동작을 여러 번 반복합니다.%SPEECH_ON%주인! 아마도 내가 당신에게 그 조합을 시험해보는 것을 허락해 주시겠습니까? 나는 그것을 마스터했다고 믿습니다!%SPEECH_OFF%당신은 웃으며 고개를 끄덕이고 앞으로 나아갑니다. 다른 학생의 페더슈베르트(Federschwert)를 받아 올바른 위치에 몸을 고정하세요. 두 팔을 머리 위로 들어올려 하이 가드 자세를 취합니다. 삐걱거리는 무릎을 구부리고 참을성 있게 공격을 기다립니다. 잠시 기다린 후 그는 공격합니다. 그는 나무 칼날을 들고 런지와 함께 무기를 당신의 가슴에 박으려고 합니다. 이에 대응하여 당신은 재빨리 경비병을 쓰러뜨리고 무기를 옆으로 치며 앞으로 밀고 자신만의 추력을 시도합니다. %randombrother% 무기를 들어올리고 페더를 공중으로 쳐서 잠시 동안 취약하게 만듭니다. 놀랍게도 뒷무릎이 자신의 무게로 인해 휘어지기 시작합니다!\n\n반격이 시작되기 직전에 당신은 오프라인 상태에서 빠른 반달 모양의 절단으로 일격을 날려버립니다. 뭉툭한 금속으로 칼날과 와드의 노출된 무기 손을 모두칩니다. 손목을 교차시켜 아주 깔끔하게 따라갑니다. 즉시 당신의 활기찬 와드는 뒤로 물러나서 웃으며 파업 지역을 때리고 다음과 같이 선언합니다. %SPEECH_START%히트!%SPEECH_OFF%이 표시가 끝나면 호흡이 폐에 들어가려고 노력합니다. 그런 단순한 움직임에도 불구하고 팔에 피로감이 스며 듭니다. 이전에도 땀 한 방울 흘리지 않고 여러 번 연습해 본 것. 피로를 감추려는 손짓 %randombrother% 더 가까이 가서 나무 그루터기에 앉아 장검 휘두르기를 더 잘 방어하는 방법을 알려줍니다.}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "아직 갖고 있어요!",
					function getResult( _event )
					{
						_event.m.Swordmaster.getSkills().removeByID("perk.rf_swordmaster_juggernaut");
						return 0;
					}
				}
			],
			function start( _event )
			{
				this.Characters.push(_event.m.Swordmaster.getImagePath());
				this.List = [
					{
						id = 16,
						icon = "ui/backgrounds/ptr_old_swordmaster_background.png",
						text = _event.m.Swordmaster.getName() + " 나이가 들다"
					},
					{
						id = 16,
						icon = ::Const.Perks.findById("perk.rf_swordmaster_juggernaut").Icon,
						text = _event.m.Swordmaster.getName() + " 저거너트 특성을 잃습니다."
					},
					{
						id = 16,
						icon = "ui/backgrounds/ptr_old_swordmaster_background.png",
						text = _event.m.Swordmaster.getName() + " 시간이 지남에 따라 약해지고 피로도, 체력 및 주도권을 잃습니다."
					}
				];
			}
		});
	}

	function onPrepare()
	{
		this.m.Title = "간단한 동작";
		foreach (bro in ::World.getPlayerRoster().getAll())
		{
			if (bro.getSkills().hasSkill("effects.rf_old_swordmaster_scenario_avatar"))
			{
				this.m.Swordmaster = bro;
				break;
			}
		}
	}

	function onClear()
	{
		this.m.Swordmaster = null;
	}
});
