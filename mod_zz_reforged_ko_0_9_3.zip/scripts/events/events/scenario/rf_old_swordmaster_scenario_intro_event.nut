this.rf_old_swordmaster_scenario_intro_event <- ::inherit("scripts/events/event", {
	m = {},
	function create()
	{
		this.m.ID = "event.rf_old_swordmaster_scenario_intro";
		this.m.IsSpecial = true;
		this.m.Screens.push({
			ID = "A",
			// Text generated and edited by LordMidas using ChatGPT
			Text = "[img]gfx/ui/events/event_17.png[/img]초풍이 불어오는 바람에 흔들리며 오두막의 거칠게 깎은 벽에 긴 그림자를 드리웠습니다. 야생의 숲 가장자리에 자리 잡은 이곳은 수십 년 동안 여러분의 안식처였습니다. 여기에서 당신은 몸을 무기로 만들고 마음을 숫돌로 만들면서 기술을 연마했습니다. 검은 당신의 유일한 동반자였습니다. 전투에서 침묵의 파트너가 싸워 승리를 거두었습니다. 그러나 이제 인생의 황혼이 다가오고 있는 지금, 당신은 전쟁이나 승리에 대해 생각하지 않고 침묵에 대해 생각하고 있는 자신을 발견합니다... 당신이 떠날 때 당신을 따라갈 침묵.\n\n특이한 점은 시간이 지나간다는 것입니다. 한때 완강했던 팔의 힘이 이제 약해졌습니다. 한때 안정되었던 당신의 손은 떨리고 있지만, 그 안에 있는 영혼은 여전히 ​​불타고 있습니다. 그리고 이 오래된 뼈가 삐걱거릴 때마다 공유하지 않으면 아침 안개처럼 사라질 평생 지식의 무게를 느끼게 됩니다. 검술은 단지 강철의 춤이 아닙니다. 그것은 철학이자 규율이자 세상을 보는 방식입니다. 그것은 혼돈 속의 호흡의 리듬이고, 폭풍의 중심에 있는 고요함이다. 그것이 당신을 형성했지만, 그것이 다른 사람을 형성하지 않는다면 그것은 무슨 가치가 있습니까?\n\n밖에 누군가가 있어야합니다. 구도자, 방랑자, 어쩌면 바보일 수도 있습니다. 이 기술에 합당한 사람. 처음 검을 잡았을 때 느꼈던 경이로움과 설렘, 매 수업마다 발견의 스릴, 그리고 배울 것이 얼마나 많은지 깨닫는 경외감을 다시 생각해 보세요. 그와 같은 불꽃이 지금 누군가에게도 존재해야 합니다. 당신이 평생을 바쳐 마스터한 것을 가져가서 앞으로 나아가고, 다듬고, 생활하고, 가르칠 수 있는 사람이 있어야 합니다.\n\n그래서 당신은 가르치기로 결심합니다. 이름은 덧없기 때문에 당신의 이름을 보존하기 위해서가 아니라, 이 지식에 당신 자신의 것 이상의 삶을 주기 위해서입니다. 칼의 길은 너희가 지킬 것이 아니다. 그것은 한 손에서 다른 손으로 흐르는 강입니다. 배우려는 의지가 있는 사람을 찾을 것입니다. 당신이 남기게 될 침묵은 비어 있는 것이 아니라, 강철과 강철의 메아리, 스승에서 제자에게 전달되는 지혜의 메아리로 가득 차게 될 것입니다.\n\n촛불은 약하게 타오르지만 그 빛은 당신을 인도하기에 충분합니다. 그리고 오랜 친구처럼 검을 벽에 기대고 일어서면서 이상한 희망을 느낍니다. 당신의 삶은 더 이상 당신 자신의 것이 아닙니다. 그것은 뒤따를 자들을 위한 다리이다. 그들이 오게 해주세요. 당신은 그들에게 당신이 아는 모든 것을 가르칠 것입니다.",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "시간이다...",
					function getResult( _event )
					{
						return "B";
					}

				}
			],
			function start( _event )
			{
				foreach (l in ::World.EntityManager.getLocations())
				{
					if (l.getTypeID() == "location.fountain_of_youth")
					{
						::logInfo("Removing the Fountain of Youth (Grotesque Tree) location");
						l.fadeOutAndDie();
						break;
					}
				}
			}
		});

		this.m.Screens.push({
			ID = "B",
			Text = "",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "알았어",
					function getResult( _event )
					{
						return 0;
					}

				}
			],
			function start( _event )
			{
				_event.m.Title = "원산지 설명";

				local avatarEffect = ::new("scripts/skills/effects/rf_old_swordmaster_scenario_avatar_effect");
				local recruitEffect = ::new("scripts/skills/effects/rf_old_swordmaster_scenario_recruit_effect");
				local origin = ::World.Assets.getOrigin();

				this.Text = "%OOC%이 출처의 작동 방식:%OOC_OFF%\n- 학생들을 가르치는 것이 전부입니다. 지출하면 게임이 종료됩니다 " + avatarEffect.m.DaysWithoutRecruitsMax + " 최소한 없이 총 일수 " + (avatarEffect.m.NumRecruitsRequired - 1) + " 다른 신병.\n- 신병은 검을 사용할 때 특별한 보너스를 부여하고 레벨이 높아질수록 더욱 강해지는 '소드마스터의 훈련' 효과를 얻습니다.\n- 검 특전 그룹에 접근할 수 있는 신병은 " + recruitEffect.m.FreePerkChancePerLevel + "레벨 업 시 무료 검 특전을 얻을 확률이 %입니다.\n- 검 특전 그룹에 접근할 수 있는 신병은 다른 모든 무기 특전 그룹을 잃고 다양한 전문화와 전투 스타일을 허용하는 검투와 관련된 특별 특전이 있는 소드마스터 특전 그룹에 접근할 수 있습니다.\n- 검, 깃발, 원거리 무기를 제외한 어떤 무기도 장착할 수 없습니다.\n- 캐릭터에 대한 '소드마스터의 훈련' 또는 '소드마스터의 기교' 효과에 대한 툴팁을 확인하여 보너스(및 해당되는 경우 페널티)에 관한 중요한 정보를 확인하십시오.\n- 제한됨 " + origin.m.BrothersMax + " 총 문자 및 최대 " + origin.m.BrothersMaxInCombat + " 전투 중.\n- 주인공은 전투가 끝날 때마다 지쳐 전투 상태로 돌아가는 데 며칠이 걸립니다. 그는 또한 시간이 지남에 따라 나이가 들고 다양한 처벌을 받게 됩니다.\n- 재능이 뛰어난 신병은 정착지에서 소드마스터에게 도전할 수 있으며, 성공하면 강력한 보너스를 얻을 수 있습니다.\n- 근접 전투 능력이 뛰어난 캐릭터 배경은 모집할 수 없습니다.\n- 세상은 당신의 강철을 아무런 제약 없이 시험합니다. 이 기원에서는 평소보다 전투 난이도가 더 빠르게 확장되어 계약이 더욱 치명적이 됩니다.\n- 이 근원지에는 젊음의 샘(괴기나무) 위치가 존재하지 않습니다.\n- 특정 위치에서 드롭되는 명명된 무기는 검일 가능성이 더 높습니다."
			}
		});
	}

	function onUpdateScore()
	{
		return;
	}

	function onPrepare()
	{
		this.m.Title = "마지막 교훈";
	}

	function onPrepareVariables( _vars )
	{
		_vars.push([
			"home",
			::World.Flags.get("HomeVillage")
		]);
	}

	function onClear()
	{
	}
});
