// All event text written by ThePlahunter
this.rf_old_swordmaster_scenario_student_local_duel_event <- ::inherit("scripts/events/event", {
	m = {		
		Candidates = [],		
		Champion = null,
		Partner = null,
		RandomBro = null,
		RandomBro2 = null,
		Flags = null,
		Town = null	
	},
	function create()
	{
		this.m.ID = "event.rf_old_swordmaster_scenario_student_local_duel";
		this.m.Title = "다가가면서...";
		this.m.Cooldown = 60.0 * ::World.getTime().SecondsPerDay;
		this.m.Screens.push({
			ID = "A",
			Text = "[img]gfx/ui/events/event_50.png[/img]{당신의 학생, %champion%, 최근 들어 상당히 불안해 보였습니다. 훈련 중 그의 스윙은 '친절한' 스파링을 훨씬 뛰어넘는 힘을 발휘합니다. 이미 그는 두 개의 나무 훈련용 칼날을 부수고 파편을 날려 다른 학생에게 거의 부상을 입힐 뻔했습니다! 마지막으로, 당신은 목격 %champion% 그리고 %partner% 매우 격렬한 스파링 중입니다. 페더들이 서로 충돌하며 불꽃을 튀깁니다! %champion% 계속해서 때린다 %partner%그의 '적'은 간신히 버틸 수 있는 반면. 마찬가지로 %partner% 경비병을 떨어뜨리고, %champion% 그의 두개골을 박살내는 것을 목표로 머리 위로 공격을 가합니다!\n\n당신은 적시에 반응하여 자신의 검을 앞으로 밀어내고 치명적인 공격을 막아냅니다! 즉시 당신은 그의 어깨를 잡고 그를 옆으로 끌어당겨 그의 담즙 분노에 대한 설명을 요구합니다. %SPEECH_ON%소드마스터라는 말을 들은 적이 있다. %townname%, 선생님. 지역 영주의 수행원 중 최고 중 한 명. 나는 준비가 되었다고 믿습니다. 나는 그를 이기고 그의 역할을 맡을 수 있습니다! 당신의 존경받는 가르침과 나의 기술로 나는 영광을 얻을 수 있습니다!%SPEECH_OFF%그의 말 한마디에서 열정이 스며 나오며, 당신의 망설임과 얼굴을 찡그린 모습을 보며 그는 즉시 계속합니다.%SPEECH_ON%나는 조합을 마스터했습니다. 나는 당신의 이름으로 많은 사람을 죽였습니다, 주인님! 귀하의 서비스 내에서 단 한 명의 학생도 나를 능가할 수 없습니다! 어떤- 어떤 늙은이가 어떻게--%SPEECH_OFF%그는 잠시 멈추고 당신을 바라보며 고개를 숙였습니다. 당신은 눈썹을 치켜올립니다.%SPEECH_ON%기분 나쁘게 하려는 건 아닙니다, 주인님. 하지만... 제가 그 사람을 데려갈 수는 있어요. 약속해요.%SPEECH_OFF%그는 자신의 기술에 대한 에너지와 자신감으로 가득 차 있습니다… 하지만 아시다시피, 당신은 자신의 도전자들과 맞서야 했습니다. 그리고 이 결투를 끝내는 방법은 오직 한 가지뿐입니다: 죽음입니다. 이것이 전통입니다... 한 번의 실수, 한 번의 잘못된 판단으로 당신의 제자는 한 순간에 쓰러질 것입니다. 그는 정말 그런 도전에 응할 준비가 되어 있는 걸까요?%SPEECH_ON%아직은 망설이고 있어요…%SPEECH_OFF%당신은 대답합니다. 시들고 주름진 얼굴에는 여전히 찡그린 얼굴이 남아 있습니다.%SPEECH_ON%제발. 나에게 이번 한번의 기회를 주십시오. 나는 당신의 훈련을 낭비하고 싶지 않습니다! 이것은 영광의 기회입니다! 우리 모두에게 영광을!%SPEECH_OFF%}",
			Image = "",
			List = [],
			Characters = [],
			Options = [],
			function start( _event )
			{
				_event.m.Title = "탕자 와드";			
				_event.m.Flags.set("EnemyChampionName", ::Const.Strings.CharacterNames[::Math.rand(0, ::Const.Strings.CharacterNames.len() - 1)] + " " + ::Const.Strings.SwordmasterTitles[::Math.rand(0, ::Const.Strings.SwordmasterTitles.len() - 1)]);

				this.Options.push({
					Text = "내 축복을 가지고 가라. %champion%!",
					function getResult( _event )
					{
						return "N";
					}
				});

				this.Options.push({
					Text = "아직 준비가 안 됐어요!",
					function getResult( _event )
					{
						if (::Math.rand(1, 100) > 80)
						{
							return "StudentInsists";
						}
						else
						{
							return "StudentBacksOff";
						}
					}
				});

				this.Characters.push(_event.m.Champion.getImagePath());
			}
		});
		this.m.Screens.push({
			ID = "StudentBacksOff",
			Text = "[img]gfx/ui/events/event_82.png[/img]{실망감이 퍼져 %champion%거의 즉시 의 얼굴이 떠오릅니다. 그가 잠시 동안 당신의 말을 곰곰이 생각하는 엄숙하고 침울한 표정입니다. 혀를 이빨 위로 훑고 머리를 아래로 떨어뜨립니다.%SPEECH_ON%저… 알겠습니다, 스승님. 만약 당신이-%SPEECH_OFF%그는 잠시 멈춰서 훌쩍거린다.%SPEECH_ON%내가 준비되지 않았다고 생각한다면. 마음을 바꿀 수는 없습니다... 본연의 임무로 돌아가겠습니다. 감사합니다.%SPEECH_OFF%그는 몸을 돌려 일상 업무로 돌아가기 시작합니다. 어깨는 아래로 처지고 얼굴은 깊게 찌푸려졌습니다. 안타깝지만 이토록 엄혹한 진실이 가슴 깊은 곳을 찔렀습니다. 물론 인생에서 많은 실망을 겪었던 당신에게는 그러한 감정이 낯설지 않지만, 적어도 그것은 당신의 모든 학생들에게 훌륭한 교훈이 됩니다. 모든 전투가 한꺼번에 승리할 수는 없습니다. 일부 기술은 성숙하는 데 시간이 걸립니다. 그리고 당신의 지혜로는 당신은 생각하지 않습니다 %champion% 아직은 성숙했어요.\n\n학생들 사이에 몇 가지 불확실한 표정이 공유되지만 누구도 감히 당신의 결정에 의문을 제기하지 않습니다.}",
			Image = "",
			List = [],
			Characters = [],
			Options = [],
			function start( _event )
			{
				_event.m.Title = "실망";
				_event.m.Cooldown = 30.0 * ::World.getTime().SecondsPerDay;

				_event.m.Champion.worsenMood(1.5, "대규모 결투에 참여하지 못하게 되었습니다.");

				if (_event.m.Champion.getMoodState() < ::Const.MoodState.Neutral)
				{
					this.List.push({
						id = 10,
						icon = ::Const.MoodStateIcon[_event.m.Champion.getMoodState()],
						text = _event.m.Champion.getName() + ::Const.MoodStateEvent[_event.m.Champion.getMoodState()]
					});
				}

				this.Options.push({
					Text = "인내는 달콤한 열매를 맺는다... 당신의 때가 올 것이다. %champion%!",
					function getResult( _event )
					{
						return 0;
					}
				});				
			}
		});
		this.m.Screens.push({
			ID = "StudentInsists",
			Text = "[img]gfx/ui/events/event_64.png[/img]{%champion%/의 입술은 혐오스러운 으르렁거림으로 위로 말려 올라가고, 그의 눈은 가늘어진다. 오른쪽 다리가 공중으로 솟아오르고, 뛰어난 학생이라기보다는 울화통을 터뜨리는 어린아이처럼 갑자기 쿵쿵거리며 내려앉는다. 그는 주먹을 꽉 쥐기도 하고, 분노에 차 있을 것 같은 표정을 짓고 있고, 눈가에는 눈물이 고인다. 곧 비명을 지를 것 같은 순간, 그의 입이 열리고, %champion% 말한다 – 그의 목소리는 떨리고 그의 턱은 하늘을 향하고 있다.%SPEECH_ON%나는… 당신이 틀렸다는 것을 증명할 것입니다. 나는 그런 식으로 모욕을 당하지 않을 것이다. 나의 주인님, 나만의 -아이돌-까지! 나는 갈 것이다. 나- 나는 이 비참한 놈을 죽여버릴 것이다! 그리고 내가 이것을 할 수 있다는 것을 보여주세요!%SPEECH_OFF%그는 당신의 학생 중 한 사람이 그토록 대담하게 미성숙함을 드러냈을 때 당신이 반응을 보이기도 전에 훌쩍이며 돌아섰습니다. 그는 즉시 달려가서 물건을 모으기 시작하고 이전에는 본 적이 없는 속도로 칼날을 쥐고 갑옷을 입습니다. 부츠 끈을 조이고 다시 일어나 가능한 한 높이 서 있습니다.%SPEECH_ON%원하시면 저를 따르세요. 상관없습니다. 당신은 위대함을 목격하게 될 것입니다! 나는 단 한 번의 칼날로 이 악당을 쓰러뜨릴 것이다. 스승님이 가르쳐주신 것 때문이 아니라, 제가 스승님의 한계를 넘어섰기 때문입니다! 표시. 나의. 단어.%SPEECH_OFF%그는 더 이상 아무 말도 없이 진영에서 뛰쳐나와 그 방향으로 달려갔다. %townname%. 당신의 학생들은 당신을 경계하는 눈빛을 보내고, 놀라서 중얼거리는 등 엇갈린 감정을 느끼며, 그러한 뻔뻔스러운 무례함을 무시하고, 미묘하게 결과에 대해 서로 내기를 합니다. 상황을 해결하기 위해 당신은 두 명의 학생을 가리키며 함께 가라고 명령합니다. %champion% 그리고 그가 어리석은 짓을 하지 않도록 하세요. 그들은 즉시 그를 따르며 돌아서서 조깅합니다.}",
			Image = "",
			List = [],
			Characters = [],
			Options = [],
			function start( _event )
			{
				_event.m.Title = "계속해서 버림받음";

				this.Options.push({
					Text = "행운을 빕니다!",
					function getResult( _event )
					{
						_event.startCombat(_event);
						return 0;
					}
				});
			}
		});
		this.m.Screens.push({
			ID = "N",
			Text = "[img]gfx/ui/events/event_35.png[/img]{%champion%당신의 선언에 의 눈은 기쁨으로 반짝입니다! 그는 고개를 깊이 숙이고 가슴 위에 손을 얹는다. 그는 확신에 찬 목소리로 말한다. %SPEECH_ON%실망시키지 않겠습니다, 주인님. 나는 동료들과 함께, 아니면 그들의 어깨 위에 올라타 돌아올 것이다. 이것만은 약속해요. 내가 검을 휘두르며 소위 '검의 달인'을 처치하는 동안 음유시인들이 우리에 대한 이야기를 들려줄 것입니다!%SPEECH_OFF%그는 고개를 들어 바라본다. %randombro% 그리고 %randombro2%.%SPEECH_ON%당신! 자, 나와 함께 가세요! 우리는 가야한다 %townname%! 즉시!%SPEECH_OFF%머뭇거리며 둘은 함께 갈 준비를 한다 %champion%, 그들의 얼굴에는 불안함과 당신을 향한 걱정의 눈빛이 있습니다. 그런데 의외로, %partner% 접근하다 %champion% 어깨에 팔을 두르고, 걸쇠가 포옹으로 바뀌자 얼굴에 미소가 번졌습니다.%SPEECH_ON%나는 당신을 믿습니다, 친구. 우리 모두에게 영광을 돌려주세요! 내가 가장 먼저 당신의 와인을 따르고 당신의 승리 이야기를 듣겠습니다!%SPEECH_OFF%%champion% 포용하다 %partner% 그리고 고개를 끄덕인다. 끌어당겨 그를 향해 미소를 지었다.%SPEECH_ON%그럴게요! 걱정하지 마세요 친구여. 머지않아 우리는 이 영광을 함께 누리게 될 것입니다!%SPEECH_OFF%}",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "",
					function getResult( _event )
					{
						_event.startCombat(_event);						
						return 0;
					}

				}
			],
			function start( _event )
			{
				_event.m.Title = "결투!";

				if (_event.m.Champion.getSkills().hasSkill("effects.rf_old_swordmaster_scenario_avatar"))
				{
					this.Options[0].Text = "죽을 준비를 하세요!";					
				}
				else
				{
					this.Options[0].Text = "나를 자랑스럽게 만들어라, " + _event.m.Champion.getName() + "!";
				}
				
				this.Characters.push(_event.m.Champion.getImagePath());
			}

		});
		this.m.Screens.push({
			ID = "Victory",
			Text = "[img]gfx/ui/events/event_26.png[/img]{그로부터 많은 시간이 지났다 %champion% 당신과 당신의 동료 학생들 모두에게 큰 실망감을 안겨주었습니다. 캠프파이어에는 차가운 스튜 한 그릇과 오래된 빵 덩어리와 함께 세 자리가 무료로 남아 있습니다. 평소 행복하고 활기 넘치는 캠프 위에 불안한 침묵이 어렴풋이 드리워져 있습니다. 단 한 명의 학생도 일찍 잠자리에 들지 않았으며, 사랑하는 친구들이 돌아오기를 기다리며 나중에 보관하기 위해 냄비를 꺼내지도 않았습니다.\n\n그들 중 한 명은 이미 무덤을 파는 것을 고려하고 있습니다. %champion%, 싸움에 대한 소식이 돌아오기도 전에 운명을 받아들였습니다. 또 다른 사람은 길 옆에 앉아 지나가는 여행자에게 다음 소식이 있는지 묻습니다. %townname%. 마침내 해가 수평선 아래로 거의 가라앉을 무렵… 근처 언덕 꼭대기에 세 개의 실루엣이 나타납니다.%SPEECH_ON%그들이 돌아왔다! 그들이 돌아왔다! %champion% 승리했습니다!%SPEECH_OFF%세 사람이 다가가자 조용한 속삭임과 토론은 환호로 바뀌고 지치고 자랑스러운 전투가 시작됩니다. %champion% 그들을 이끌어라! 그의 칼날은 피투성이였고 머리카락은 땀과 피, 진흙으로 뒤덮였지만, 그의 얼굴은 승리의 영광으로 인해 확실히 빛나고 있었습니다. %champion% 무릎을 꿇고 꽤 화려하고 균형이 잘 잡힌 칼날을 들고 즉각적으로 달려옵니다.%SPEECH_ON%정복당한 자의 칼날, 주인님, 제가 당신을 위해 그것을 차지했습니다. 나는 내 원수를 죽였고 당신의 이름으로 영광과 명성을 얻었습니다! 제발… 가져가세요.%SPEECH_OFF%당신은 자랑스러운 미소를 지으며 칼날을 집어 공중으로 들어 올립니다. 주변의 학생들이 환호성을 지르고 있습니다!\n\n%champion% 공중으로 들어올려져 캠프 주위를 행진하며 환상적이고 영광스러운 귀환에 대해 칭찬을 받습니다.\n\n젊은이 %champion% 그는 소드마스터라고 불릴 만큼 실력 있고 가치가 있다는 것을 진정으로 보여주었고, 자신을 당신과 거의 같은 수준으로 끌어올렸습니다.}",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "나는 당신이 자랑스럽습니다. %champion%!",
					function getResult( _event )
					{
						return 0;
					}
				}
			],
			function start( _event )
			{
				_event.m.Title = "전투가 끝난 후...";
				this.Characters.push(_event.m.Champion.getImagePath());
				::World.Assets.addBusinessReputation(50);

				_event.evolveChampion(_event.m.Champion, this);

				_event.m.Champion.improveMood(1.0, "훌륭한 결투에서 승리했습니다");

				if (_event.m.Champion.getMoodState() >= ::Const.MoodState.Neutral)
				{
					this.List.push({
						id = 10,
						icon = ::Const.MoodStateIcon[_event.m.Champion.getMoodState()],
						text = _event.m.Champion.getName() + ::Const.MoodStateEvent[_event.m.Champion.getMoodState()]
					});
				}

				foreach (bro in ::World.getPlayerRoster().getAll())
				{
					if (bro == _event.m.Champion)
						continue;

					bro.improveMood(0.5, "회사의 챔피언이 인상적인 결투에서 승리했습니다.");

					if (bro.getMoodState() >= ::Const.MoodState.Neutral)
					{
						this.List.push({
							id = 10,
							icon = ::Const.MoodStateIcon[bro.getMoodState()],
							text = bro.getName() + ::Const.MoodStateEvent[bro.getMoodState()]
						});
					}
				}
			}
		});
		this.m.Screens.push({
			ID = "Defeat",
			Text = "[img]gfx/ui/events/event_124.png[/img]{불안한 많은 학생들과 함께 당신을 기다리는 동안 시간은 천천히 흐르고 있습니다. %champion%의 복귀. 몇몇 학생들은 언제라도 승리의 트리오를 볼 수 있기를 기대하면서 안절부절 못하고 지평선을 바라보며 서성거립니다. 그러한 직무 유기는 당신에게 약간의 불안을 안겨주지만, 상황을 고려하면 그것이 타당할 가능성이 가장 높다는 것을 당신은 알고 있습니다. 때로는 지평선을 바라보며 학생들이 돌아올 기미를 찾으며 신들에게 좋은 소식과 승리의 와드를 기원하기도 합니다.\n\n뒤에는 이미 무덤이 파여져 있다 %champion%실패가 수반하는 일을 암울하게 상기시켜 주는 텐트입니다. 심지어 개인 소지품을 뒤지고 있는 학생을 붙잡았고, 질문을 받은 후 그가 죽으면 더 이상 소지품이 필요하지 않다고 선언했습니다.\n\n해가 지기 시작하면... 언덕 꼭대기에 방패 꼭대기에 세 번째 인물을 들고 있는 두 인물이 있습니다. 절망의 울부짖음이 솟아오른다. %partner% 그가 그들을 발견했을 때. 상황의 현실이 안정될 때까지 캠프는 혼란에 휩싸입니다. 스스로도 믿기 어려울 정도입니다.\n\n그들이 수용소로 걸어가는 동안, %champion% 이상하게 평화로워 보인다. 빠른 죽음, 단 한 번의 결정타로 싸움이 끝났습니다. 적어도 운 좋게 죽는 방법이죠. 단일 블레이드 스트로크로 인해 너무 많은 고통을 겪지는 않습니다. 당신은 분배에 대해 매우 친숙한 것입니다.\n\n비록 사랑과 존경심이 있기는 하지만 그는 아주 무의식적으로 무덤 속으로 내려갔습니다. %randombro% 눈물로 반짝이는 눈으로 작은 기도서를 들고 다가옵니다. 마음을 진정시키는 몇 마디 말이 낭독되고, 그가 묻히기 전에 그의 친구 중 한 명이 그의 마지막 의식을 낭독합니다. 그의 이름이 조잡하게 새겨진 나무 토템이 땅에 박혀 있습니다. 그렇게 용감한 사람이 마땅히 받아야 할 것보다 훨씬 덜 고귀한 안식처입니다.}",
			Image = "",
			List = [],
			Characters = [],
			Options = [],
			function start( _event )
			{
				_event.m.Title = "전투가 끝난 후...";

				::MSU.Array.removeByValue(_event.m.Candidates, _event.m.Champion);

				foreach (bro in _event.m.Candidates)
				{
					if (bro == _event.m.Partner)
						continue;

					if (_event.canHaveRandomBros(bro, _event.m.Partner))
					{
						this.Options.push({
							Text = "우리의 복수를 해줄 당신이 필요해요 " + bro.getName() + ".",
							function getResult( _event )
							{
								_event.m.Champion = bro;
								_event.setupRandomBros();
								_event.startCombat(_event);
								return 0;
							}
						});
					}
				}

				// this.Options.push({
				// 	Text = "%enemyname%, I will cut you down myself!",
				// 	function getResult( _event )
				// 	{
				// 		foreach (bro in ::World.getPlayerRoster().getAll())
				// 		{
				// 			if (bro.getSkills().hasSkill("effects.rf_old_swordmaster_scenario_avatar"))
				// 			{
				// 				_event.m.Champion = bro;
				// 				break;
				// 			}
				// 		}
						
				// 		_event.startCombat(_event);					
				// 		return 0;
				// 	}
				// });

				this.Options.push({
					Text = "작별 인사 %champion%! 당신은 너무 어린 나이에 죽었습니다!",
					function getResult( _event )
					{
						return 0;
					}
				});
			}
		});		
	}

	function onUpdateScore()
	{
		if (!::World.getTime().IsDaytime || ::World.Assets.getOrigin().getID() != "scenario.rf_old_swordmaster")
		{
			return;
		}

		local bros = ::World.getPlayerRoster().getAll();
		if (bros.len() < 5)
		{
			return;
		}

		local town;
		local playerTile = ::World.State.getPlayer().getTile();

		foreach (t in ::World.EntityManager.getSettlements())
		{
			if (t.getSize() > 2 || (t.getSize() > 1 && t.isMilitary()))
			{
				if (t.getTile().getDistanceTo(playerTile) <= 10 && !t.isIsolated())
				{
					town = t;
					break;
				}
			}
		}

		if (town == null)
		{
			return;
		}

		this.m.Candidates = [];

		local non_canditates = [];

		foreach (bro in bros)
		{
			if (bro.getSkills().hasSkill("effects.rf_old_swordmaster_scenario_avatar"))
			{
				continue;
			}
			if (bro.getCurrentProperties().getMeleeSkill() < 100 || bro.getCurrentProperties().getMeleeDefense() < 45 || bro.getBackground().getID().find("swordmaster") != null || !bro.getPerkTree().hasPerkGroup("pg.rf_swordmaster"))
			{
				non_canditates.push(bro);
			}
			else if (bro.getSkills().getSkillByID("effects.rf_old_swordmaster_scenario_recruit").isEnabled())
			{
				this.m.Candidates.push(bro);
			}
		}

		if (this.m.Candidates.len() == 0)
		{
			return;
		}

		this.m.Town = town;

		this.m.Score = this.m.Candidates.len() * 25;
		
		this.m.Champion = this.m.Candidates.remove(::Math.rand(0, this.m.Candidates.len() - 1));

		non_canditates.extend(this.m.Candidates);

		this.m.Partner = non_canditates.remove(::Math.rand(0, non_canditates.len() - 1));

		this.m.Candidates.sort(@(_a, _b) _a.getXP() <=> _b.getXP());
		this.m.Candidates.reverse();

		this.setupRandomBros();
	}

	function canHaveRandomBros( _champion, _partner )
	{
		local count = 0;
		foreach (bro in ::World.getPlayerRoster().getAll())
		{
			if (bro != _champion && bro != _partner && !bro.getSkills().hasSkill("effects.rf_old_swordmaster_scenario_avatar"))
			{
				count++;
			}
		}

		return count >= 2;
	}

	function setupRandomBros()
	{
		local randomBros = [];
		foreach (bro in ::World.getPlayerRoster().getAll())
		{
			if (this.m.Champion != bro && this.m.Partner != bro && !bro.getSkills().hasSkill("effects.rf_old_swordmaster_scenario_avatar"))
			{
				randomBros.push(bro);
			}
		}

		if (randomBros.len() < 2)
		{
			return false;
		}

		this.m.RandomBro = randomBros.remove(::Math.rand(0, randomBros.len() - 1));
		this.m.RandomBro2 = randomBros.remove(::Math.rand(0, randomBros.len() - 1));

		return true;
	}

	function onPrepare()
	{
		this.m.Flags = ::new("scripts/tools/tag_collection");
	}

	function onPrepareVariables( _vars )
	{
		_vars.push([
			"champion",
			this.m.Champion.getName()
		]);

		_vars.push([
			"partner",
			this.m.Partner.getName()
		]);

		_vars.push([
			"randombro",
			this.m.RandomBro.getName()
		]);

		_vars.push([
			"randombro2",
			this.m.RandomBro2.getName()
		]);
		
		_vars.push([
			"enemyname",
			this.m.Flags.get("EnemyChampionName")
		]);

		_vars.push([
			"townname",
			this.m.Town.getName()
		]);
	}

	function onClear()
	{
		this.m.Candidates.clear();
		this.m.Champion = null;
		this.m.Partner = null;
		this.m.RandomBro = null;
		this.m.RandomBro2 = null;
		this.m.Flags = null;
		this.m.Town = null;
	}

	function startCombat( _event )
	{
		local name = _event.m.Flags.get("EnemyChampionName");
		local properties = ::World.State.getLocalCombatProperties(::World.State.getPlayer().getPos());
		properties.Music = ::Const.Music.NobleTracks;
		properties.Entities = [];

		properties.Entities.push({
			ID = ::Const.EntityType.Swordmaster,
			Variant = 0,
			Row = 0,
			Name = name,
			Script = "scripts/entity/tactical/humans/swordmaster",
			Faction = ::Const.Faction.Enemy,
			function Callback( _entity, _tag )
			{
				_entity.setName(name);
			}
		});

		properties.Players.push(_event.m.Champion);
		properties.IsUsingSetPlayers = true;
		properties.IsFleeingProhibited = true;
		properties.IsAttackingLocation = true;
		properties.BeforeDeploymentCallback = function ()
		{
			local size = ::Tactical.getMapSize();

			for( local x = 0; x < size.X; x++ )
			{
				for( local y = 0; y < size.Y; y++ )
				{
					local tile = ::Tactical.getTileSquare(x, y);
					tile.Level = ::Math.min(1, tile.Level);
				}
			}
		};
		_event.registerToShowAfterCombat("Victory", "Defeat");
		::World.State.startScriptedCombat(properties, false, false, false);
	}

	function evolveChampion( _actor, _screen )
	{
		local currentBackground = _actor.getBackground();
		local oldDesc = currentBackground.m.Description;

		local newBackground = ::new("scripts/skills/backgrounds/rf_renowned_swordmaster_background");
		newBackground.m.IsNew = false;

		_actor.getSkills().removeByID(currentBackground.getID());
		_actor.getSkills().add(newBackground);

		newBackground.m.RawDescription = oldDesc + " 당신의 지도하에, %name% 유명한 소드마스터를 쓰러뜨리고 실력을 입증하며 진정한 검의 달인으로 성장했고, " + this.m.Flags.get("EnemyChampionName") + ", 단일 전투에서!";
		newBackground.buildDescription(true);

		local effect = _actor.getSkills().getSkillByID("effects.rf_old_swordmaster_scenario_recruit");

		foreach (row in ::DynamicPerks.PerkGroups.findById("pg.rf_sword").getTree())
		{
			foreach (perkID in row)
			{
				local perk = _actor.getSkills().getSkillByID(perkID);
				if (perk == null)
				{
					perk = ::Reforged.new(::Const.Perks.findById(perkID).Script);
					_actor.getSkills().add(perk);
				}
				else if (perk.m.IsRefundable)
				{
					_actor.m.PerkPoints++;
					_actor.m.PerkPointsSpent--;
				}

				perk.m.IsRefundable = false;

				if (effect.m.FreePerksGainedIDs.find(perkID) == null)
				{
					effect.m.FreePerksGainedIDs.push(perkID);
				}
			}
		}

		local attributes = {
			MeleeSkill = ::Math.rand(10, 15),
			MeleeDefense = ::Math.rand(10, 15),
			Stamina = ::Math.rand(5, 10),
			Bravery = ::Math.rand(10, 20),
			Initiative = ::Math.rand(10, 20)
		};

		_actor.getBaseProperties().MeleeSkill += attributes.MeleeSkill;
		_actor.getBaseProperties().MeleeDefense += attributes.MeleeDefense;
		_actor.getBaseProperties().Stamina += attributes.Stamina;
		_actor.getBaseProperties().Bravery += attributes.Bravery;
		_actor.getBaseProperties().Initiative += attributes.Initiative;

		_actor.getSkills().update();

		_screen.List = [
			{
				id = 10,
				icon = "ui/backgrounds/background_30.png",
				text = this.m.Champion.getName() + " 지금은 " + this.m.Champion.getBackground().m.Name + "."
			},
			{
				id = 10,
				icon = "ui/icons/perks.png",
				text = this.m.Champion.getName() + " 모든 검 그룹 특전을 얻습니다. 검 특전에 소비된 특전 포인트는 모두 환불됩니다."
			}
		];

		_screen.List.extend([
			{
				id = 10,
				icon = "ui/icons/special.png",
				text = "회사가 명성을 얻었습니다"
			},
			{
				id = 10,
				icon = "ui/icons/melee_skill.png",
				text = this.m.Champion.getName() + " gains " + ::Const.UI.getColorized(attributes.MeleeSkill, ::Const.UI.Color.PositiveEventValue) + " 근접 스킬"
			},
			{
				id = 10,
				icon = "ui/icons/melee_defense.png",
				text = this.m.Champion.getName() + " gains " + ::Const.UI.getColorized(attributes.MeleeDefense, ::Const.UI.Color.PositiveEventValue) + " 근접 방어"
			},
			{
				id = 10,
				icon = "ui/icons/fatigue.png",
				text = this.m.Champion.getName() + " gains " + ::Const.UI.getColorized(attributes.Stamina, ::Const.UI.Color.PositiveEventValue) + " Fatigue"
			},
			{
				id = 10,
				icon = "ui/icons/bravery.png",
				text = this.m.Champion.getName() + " gains " + ::Const.UI.getColorized(attributes.Bravery, ::Const.UI.Color.PositiveEventValue) + " Resolve"
			},
			{
				id = 10,
				icon = "ui/icons/initiative.png",
				text = this.m.Champion.getName() + " gains " + ::Const.UI.getColorized(attributes.Initiative, ::Const.UI.Color.PositiveEventValue) + " Initiative"
			}
		]);
	}
});
