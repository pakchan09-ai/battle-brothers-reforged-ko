// All event text written by ThePlahunter
this.rf_old_swordmaster_scenario_old_age_event_3 <- this.inherit("scripts/events/event", {
	m = {
		Swordmaster = null
	},
	function create()
	{
		this.m.ID = "event.rf_old_swordmaster_scenario_old_age_3";
		this.m.IsSpecial = true;
		this.m.Screens.push({
			ID = "A",
			Text = "[img]gfx/ui/events/event_17.png[/img]학생들이 일상 업무와 엄격한 훈련에 참여하는 동안 여러분은 근처의 바위 위에 앉아 있습니다. 같은 동작, 스텝, 공격을 계속해서 연습합니다. 금속과 금속이 충돌하는 칼날이 공기를 통해 노래하며, 갈라진 입술에 미소를 짓게 만드는 멋진 멜로디입니다. 기술, 속도, 지구력이 이렇게 과시됩니다! 그것은 당신의 것과 거의 일치할 수 있습니다…\n\n하지만 충분히 가깝지 않습니다! 그들은 아직 배울 것이 너무 많습니다! 바위를 밀고 다가가면 %randombrother% 그리고 %randombrother2% 스파링 중에. 그들의 무기가 회전하며 서로를 공격하는 모습을 지켜보는 것은 방어적인 발놀림, 막고, 정확한 타격을 보여줍니다. 그러나 가까이 다가가면 몇 가지 실수를 발견하게 됩니다. 발이 약하고, 손목이 약하며, 의지할 곳 없이 너무 많은 땅을 내어주고 있습니다. 손을 들어 스파링을 멈추고 다음을 바라봅니다. %randombrother% 무기를 가져가려는 몸짓을 합니다. %SPEECH_START%자, 그거 나한테 줘...%SPEECH_OFF%간단히 파악하면 무기와 그의 자리를 차지할 수 있습니다.%SPEECH_ON%당신은 의지하지 않고 너무 많은 근거를 포기합니다. 당신이 너무 방어적이라면, 당신의 적은 단순히 당신을 쪼개버릴 것입니다. 당신을 노출시키고 지치게 만듭니다. 당신이 철의 폐와 강철의 심장을 갖고 있지 않다면, 당신의 상대는 %OOC%의지%OOC_OFF% 당신보다 오래갑니다. 조심하세요, 나는 방어와 동시에 반격을 가할 것입니다!%SPEECH_OFF%그에 따라 그립을 조정하고 오른발로 리드합니다. '상대'를 응시하면서 블레이드를 준비하세요.%SPEECH_ON%엔가르드!%SPEECH_OFF%당신은 거리를 좁히고 손이 닿는 거리에 도달하는 것을 목표로 빠르게 돌진하는 추력으로 먼저 공격합니다. 갑자기 뒤쪽 무릎에 압력이 가해지면서 놀라서 눈이 조여지고, 통증의 충격이 가슴까지 올라옵니다. 추진력을 잃으면 공격에 쉽게 반응할 수 있습니다. %randombrother2% 칼날을 공중에 띄우고 옆으로 조심스럽게 발걸음을 옮깁니다. 그는 무기를 들고 머리 위로 들어올리고, 손을 가슴 가까이 들어 올려 당신의 손을 공격하려 합니다. 그런 타격은 쉽게 튕겨 나갈 것입니다... 그래서 당신은 시도합니다. 그런데 갑자기 팔이 축 늘어지는 느낌이 들고, 막으려는 순간-\n\n그는 당신을 공격합니다.\n\n당신의 반사 신경은 너무 느렸고, 그의 나무 칼날은 당신의 가드 바로 아래로 그리고 당신의 갈비뼈까지 미끄러져 들어갔습니다. 고통은 당신의 몸을 다음과 같이 망가뜨린다. %OOC%크랙!%OOC_OFF% 가슴에서 나오는 소리로 인해 뒤로 넘어질 때 숨이 폐에서 빠져나가게 됩니다. 자신을 회복하기 위해 다리를 지탱했지만 무릎이 다시 한 번 빠르게 구부러지는 것을 발견했습니다. 오래된 전투 상처가 마침내 당신을 따라잡아 관절이 허약해지고 몸을 지탱할 수 없게 됩니다. 마침내 당신은 땅바닥에 쓰러지고, 갈고리에 걸린 물고기처럼 몸부림치며 고통에 몸부림칩니다.\n\n통증이 가라앉기까지 몇 분이 몇 시간처럼 지나갑니다. 결국 바람이 쌕쌕거려 다시 폐로 들어옵니다. 그리고 몇 명의 학생의 도움으로 당신은 고통에 신음하며 일어섰습니다. 재빨리 고개를 끄덕이며 %randombrother2%, 당신은 돌아서서 비틀거리며 팔을 감싸고 텐트로 돌아갑니다. %randombrother%어깨.",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "얼마나 더 남았나요?",
					function getResult( _event )
					{
						_event.m.Swordmaster.getSkills().removeByID("perk.rf_swordmaster_precise");
						_event.m.Swordmaster.getSkills().removeByID("perk.rf_swordmaster_blade_dancer");
						return 0;
					}

				}
			],
			function start( _event )
			{
				this.Characters.push(_event.m.Swordmaster.getImagePath());
				local injuries = [
					{
						ID = "injury.fractured_ribs",
						Threshold = 0.25,
						Script = "injury/fractured_ribs_injury"
					}
				];
				if (_event.m.Swordmaster.getSkills().hasSkill("injury.fractured_ribs"))
				{
					injuries = [
						{
							ID = "injury.broken_ribs",
							Threshold = 0.5,
							Script = "injury/broken_ribs_injury"
						}
					];
				}

				local injury = _event.m.Swordmaster.addInjury(injuries);

				this.List = [
					{
						id = 16,
						icon = "ui/backgrounds/rf_old_swordmaster_background.png",
						text = _event.m.Swordmaster.getName() + " 나이가 들다"
					},
					{
						id = 16,
						icon = ::Const.Perks.findById("perk.rf_swordmaster_precise").Icon,
						text = _event.m.Swordmaster.getName() + " 정확한 특성을 잃습니다."
					},
					{
						id = 16,
						icon = ::Const.Perks.findById("perk.rf_swordmaster_blade_dancer").Icon,
						text = _event.m.Swordmaster.getName() + " 블레이드 댄서 특성을 잃습니다."
					},
					{
						id = 16,
						icon = "ui/backgrounds/rf_old_swordmaster_background.png",
						text = _event.m.Swordmaster.getName() + " 시간이 지남에 따라 계속해서 약해지고 피로도, HP 및 주도권을 잃게 됩니다."
					}
				];

				if (injury != null)
				{
					this.List.push({
						id = 16,
						icon = injury.getIcon(),
						text = _event.m.Swordmaster.getName() + " suffers " + injury.getNameOnly()
					});
				}

				_event.m.Swordmaster.addLightInjury();
				this.List.push({
					id = 16,
					icon = "ui/icons/days_wounded.png",
					text = _event.m.Swordmaster.getName() + " 가벼운 상처를 입다"
				});
			}
		});
	}

	function onPrepare()
	{
		this.m.Title = "물고기처럼";
		foreach (bro in ::World.getPlayerRoster().getAll())
		{
			if (bro.getSkills().hasSkill("effects.rf_old_swordmaster_scenario_avatar"))
			{
				this.m.Swordmaster = bro;
				break;
			}
		}
	}

	function onClear()
	{
		this.m.Swordmaster = null;
	}
});
