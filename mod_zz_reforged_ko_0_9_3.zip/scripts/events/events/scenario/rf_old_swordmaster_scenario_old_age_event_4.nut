// All event text written by ThePlahunter
this.rf_old_swordmaster_scenario_old_age_event_4 <- this.inherit("scripts/events/event", {
	m = {
		Swordmaster = null
	},
	function create()
	{
		this.m.ID = "event.rf_old_swordmaster_scenario_old_age_4";
		this.m.IsSpecial = true;
		this.m.Screens.push({
			ID = "A",
			Text = "[img]gfx/ui/events/event_17.png[/img]오늘은 학생들이 잠을 자는 동안, 당신은 새벽에 회사를 빠져나와 혼자만의 시간을 보내고 싶어합니다. 떠오르는 태양 아래 앉아 생각에 잠겨 있으면 많은 질문이 마음속에 스쳐 지나갑니다. 당신의 전성기는 오래 전에 지나갔지만 당신은 여기에 남아 있습니다. 손에 칼을 쥐고 이마에 땀을 흘리며 숨결이 폐를 채웁니다. 전투 중에 싸우고, 짐승, 사람, 그린스킨을 모두 죽이는 일이 있지만… 하지만 여기에는 대가가 따릅니다. 한때는 단순한 성가심이었던 오래된 전투 흉터가 이제는 거칠게 맥동하고 발걸음을 옮길 때마다 고통의 충격을 보냅니다. 스윙을 할 때마다 침대에 누워있을 정도로 통증이 발생합니다...\n\n이전 동료 중 상당수가 이미 전사했거나 평화롭게 은퇴했습니다. 마지막으로 들은 것은 당신의 전쟁 중사입니다. %randomname%, 기사작위를 받았고, 배후지에서 꽤 넉넉한 재산을 받았습니다. %randomtown%. 이제 그의 아들이 늙고 허약한 나이에 집안일을 돌보고 있습니다. 그러나 시도된 서신을 읽어보면 응답이 거의 없습니다. 대부분은 가까운 친족이며, 옛 동맹이 질병, 전쟁, 살인으로 인해 사망했다고 설명합니다. 다른 사람들은 완전히 실종되었지만 물론 죽은 것으로 추정됩니다.\n\n도적 떼에 의해 쓰러진 스파링 파트너, 역병으로 죽어가는 옛 강사, 심지어 수년 전에 사랑을 찾고 이어가던 어린 시절의 열광까지. 많은 자녀와 사랑하는 배우자로 둘러싸여 있습니다. 당신을 포함하여 많은 사람들에게 나이가 들었습니다. 이 사실을 알아차린 사람은 당신뿐만이 아닙니다. 당신의 학생 중 몇 명, %randombrother% 그리고 %randombrother2% 특히 몸이 점점 약해지기 때문에 걱정스러운 눈초리를 보내세요. 당신은 우아한 펜싱 선수의 발걸음으로 덜 걷고, 더욱 말라서 절뚝거리게 됩니다. 식기를 사용하는 동안 손이 약간 흔들리고, 식사하기가 점점 더 어려워집니다.\n\n당신의 검술 실력은 여전히 ​​학생들을 놀라게 하지만, 당신의 몸은 날이 갈수록 점점 더 스스로를 지탱할 수 없게 됩니다. 각 스파링이 끝나면 폐로 숨을 다시 가져오기가 더 어려워지고 똑바로 서 있는 것이 거의 불가능해집니다.\n\n해가 지는 것을 바라보면서 당신은 하루 종일 당신의 삶과 당신의 길을 건너온 모든 사람들의 삶에 대해 고민하며 보냈다는 것을 깨닫게 됩니다. 피처럼 붉은 하늘, 지는 해, 길을 잃은 새들이 집으로 돌아가는 애도의 소리... 당신은 차가운 한숨을 내쉬며 캠프를 향해 다시 걷기 시작합니다. 금속이 금속에 부딪히는 감미로운 소리로 돌아갑니다.",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "언젠가는 어떤 상승이 이루어져야 할까요...",
					function getResult( _event )
					{
						return 0;
					}

				}
			],
			function start( _event )
			{
				this.Characters.push(_event.m.Swordmaster.getImagePath());
				this.List = [
					{
						id = 16,
						icon = "ui/backgrounds/rf_old_swordmaster_background.png",
						text = _event.m.Swordmaster.getName() + " 나이가 들다"
					},
					{
						id = 16,
						icon = "ui/backgrounds/rf_old_swordmaster_background.png",
						text = _event.m.Swordmaster.getName() + " 시간이 지남에 따라 계속해서 약해지고 피로도, HP 및 주도권을 잃게 됩니다."
					}
				];
			}
		});
	}

	function onPrepare()
	{
		this.m.Title = "황혼";
		foreach (bro in this.World.getPlayerRoster().getAll())
		{
			if (bro.getSkills().hasSkill("effects.rf_old_swordmaster_scenario_avatar"))
			{
				this.m.Swordmaster = bro;
				break;
			}
		}
	}

	function onClear()
	{
		this.m.Swordmaster = null;
	}
});
