this.rf_random_trio_scenario_intro_event <- ::inherit("scripts/events/event", {
	m = {},
	function create()
	{
		this.m.ID = "event.rf_random_trio_scenario_intro";
		this.m.IsSpecial = true;
		this.m.Title = "3명의 회사";
		this.m.Screens.push({
			ID = "A",
			// Text generated and edited by LordMidas using ChatGPT
			Text = "[img]gfx/ui/events/event_80.png[/img]길가에 있는 이름 없는 여관의 폐허 사이로 바람이 휘몰아치고 있으며, 구덩이 속에서는 어젯밤 불이 아직도 희미하게 빛나고 있습니다. 세 사람은 추운 아침에 앉아 아픈 몸과 지친 마음을 간호하고 있습니다. 당신이 낯선 사람이 된 것은 그리 오래되지 않았습니다. 운명, 상황, 어쩌면 약간의 불운으로 인해 모였습니다.\n\n며칠 전만 해도 도로는 충분히 안전했다고 당신은 생각했습니다. 하지만 그것이 도적이든, 짐승이든, 아니면 그보다 더 나쁜 일이든 재난이 닥쳤습니다. 어쩌면 당신의 캐러밴이 매복 공격을 받았을 수도 있고, 당신의 영주가 배신당했을 수도 있고, 당신의 농장이 불탔을 수도 있고, 당신의 이전 회사가 와해될 수도 있습니다. 어떤 식으로든 당신은 세상에서 혼자이고 필사적이며 당신의 재치와 당신이 수집할 수 있는 강철 외에는 거의 무장하지 않은 자신을 발견했습니다.\n\n당신이 그 두꺼운 가운데 연속적으로 서 있는 것을 본 것은 신뢰가 아니라 필요였습니다. 하지만 먼지가 가라앉았을 때에도 당신은 여전히 ​​서 있었고, 거기에는 뭔가가 있었습니다.\n\n침묵은 이렇게 깨졌다 %bro1% 긴 숨을 내쉰다.%SPEECH_ON%도로는 불을 바라보는 데 더 이상 시간이 걸리지 않을 것입니다.%SPEECH_OFF%그는 갑옷의 마지막 끈을 조였습니다. %bro2%, 칼날을 갈며 웃는다.%SPEECH_ON%처음부터 갈 길은 많지 않습니다. 단지 많은 흙과 다음 도시가 이전 도시보다 더 나을 것이라는 약속이 있을 뿐입니다.%SPEECH_OFF%%bro3%, 더 늙었거나 아마도 더 지쳤을 수도 있고, 여관의 잔해를 가리키는 손짓입니다.%SPEECH_ON%글쎄요, 이곳은 약속이 별 의미가 없다는 증거입니다. 하지만 동전은 그렇습니다. 우리는 싸우는 방법을 알고 있으며 항상 기꺼이 돈을 지불할 누군가가 있습니다.%SPEECH_OFF%그것은 단순한 진실이다. 돌아갈 집도 없고, 봉사할 주인도 남지 않았습니다. 세 사람, 소수의 무기, 그리고 열린 길뿐입니다. 미래가 있다면 강철로 깎고 피로 사야 한다. 결정을 내려야 합니다.%SPEECH_ON%그러면 해결되었습니다. 우리는 동전을 위해 싸우고, 서로를 위해 싸우며 이런 혼란스러운 일을 만들어냅니다.%SPEECH_OFF%팡파르도 없고, 웅장한 선언도 없습니다. 운명에 묶인 세 영혼만이 전쟁의 길을 걷는다. 당신이 이전에 무엇이었든 더 이상 중요하지 않습니다. 오늘부터 당신은 용병입니다. 전투중인 형제들. 그리고 세상은 당신의 이름을 알게 될 것입니다.",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "동전과 영광을 위해!",
					function getResult( _event )
					{
						return 0;
					}

				}
			],
			function start( _event )
			{
				this.Banner = "ui/banners/" + ::World.Assets.getBanner() + "s.png";
			}

		});
	}

	function onPrepareVariables( _vars )
	{
		foreach (i, bro in ::World.getPlayerRoster().getAll())
		{
			_vars.push([
				"bro" + (i+1),
				bro.getNameOnly()
			]);
		}
	}
});
