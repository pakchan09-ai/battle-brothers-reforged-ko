// All event text written by ThePlahunter
this.rf_old_swordmaster_scenario_old_age_event_2 <- this.inherit("scripts/events/event", {
	m = {
		Swordmaster = null
	},
	function create()
	{
		this.m.ID = "event.rf_old_swordmaster_scenario_old_age_2";
		this.m.IsSpecial = true;
		this.m.Screens.push({
			ID = "A",
			Text = "[img]gfx/ui/events/event_17.png[/img]{당신은 하루를 준비하는 분주한 학생들의 초라한 텐트 안에서 다시 한 번 깨어납니다. 야생 뿌리, 사냥감 고기, 출처가 의심스러운 기타 식품으로 갓 만든 스튜 냄새가 마비된 코를 타고 퍼집니다. 처음에는 여느 평범한 날처럼 보이지만 침대에서 일어나면 상황이 빠르게 변합니다. 일어서려고 애쓰는 동안 밝은 빛이 시야를 가로질러 번쩍이고, 평상시에는 능숙하고 빠른 발 위에서 앞뒤로 흔들릴 때 현기증이 당신을 사로잡습니다. 하지만 이 느낌은 온 것만큼이나 빠르게 사라지고, 당신은 밝은 아침 햇살 속으로 걸어나오는데…\n\n몇몇 학생들은 이미 그날에 전념하고 있습니다. 스트레칭, 리프팅, 달리기, 심지어 훈련까지. 서로 웃고 농담하는 동안 끝없는 에너지와 체력이 그들의 몸을 가득 채운다. 여러분의 지도와 리더십 아래 그들 사이에는 긴밀한 동지애가 있습니다. %randombrother% 당신을 바라보며 환한 미소를 지으며 모닥불 위에 위태롭게 걸려 있는 쇠솥 가까이로 당신을 가리킵니다.%SPEECH_ON%주인! 좋은 아침입니다! 자, 우리와 함께 앉으세요!%SPEECH_OFF%당신은 작은 미소를 지으며 언제나처럼 활기차게 다가가 자리에 앉습니다. 학생들의 소란과 대화에 몰입해보세요.%SPEECH_ON%당신을 만나서 반갑습니다. 우리 중 일부는 당신이 전혀 일어날지 궁금해했습니다!%SPEECH_OFF%%randombrother2% 야유, 장난스럽게 당신을 쿡쿡 찌르는군요. 당신은 혀를 찰칵 소리를 내며, 음식 한 그릇을 가져가는 도중에 잠시 멈추고, 고개를 돌려 눈썹을 치켜세웁니다.%SPEECH_ON%무슨 뜻이에요?%SPEECH_OFF%그는 잠시 말을 멈추고 어깨를 으쓱하며 신중하게 단어를 선택했습니다.%SPEECH_ON%글쎄… ​​당신은 보통 우리보다 먼저 일어납니다. 우리는 당신이 깊은 잠에 빠진 것은 아닌지 걱정했습니다.%SPEECH_OFF%그는 자신이 앉아 있는 통나무 위에서 꿈틀거리며 머뭇거리며 말합니다.\n\n비웃으면서 당신은 고개를 저었습니다.%SPEECH_ON%난 그렇게 늙지 않았어, 혀 조심해. 나는 여러분의 나머지 사람들만큼 활기차고 활발합니다. 그리고 잊지 마세요!%SPEECH_OFF%당신은 주먹을 흔들고 스튜 한 국자를 떠서 나무 그릇에 담고 조용히 먹기 시작합니다. 마음속 깊은 곳에서 당신은 학생의 가벼운 농담 뒤에 숨은 암울한 진실에 대해 고민하고 있는 자신을 발견하게 됩니다.}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "시간이 많이 걸리네요...",
					function getResult( _event )
					{
						_event.m.Swordmaster.getSkills().removeByID("perk.rf_swordmaster_reaper");
						return 0;
					}

				}
			],
			function start( _event )
			{
				this.Characters.push(_event.m.Swordmaster.getImagePath());
				this.List = [
					{
						id = 16,
						icon = "ui/backgrounds/rf_old_swordmaster_background.png",
						text = _event.m.Swordmaster.getName() + " 나이가 들다"
					},
					{
						id = 16,
						icon = ::Const.Perks.findById("perk.rf_swordmaster_reaper").Icon,
						text = _event.m.Swordmaster.getName() + " 사신 특권을 잃습니다."
					},
					{
						id = 16,
						icon = "ui/backgrounds/rf_old_swordmaster_background.png",
						text = _event.m.Swordmaster.getName() + " 시간이 지남에 따라 계속해서 약해지고 피로도, HP 및 주도권을 잃게 됩니다."
					}
				];
			}
		});
	}

	function onPrepare()
	{
		this.m.Title = "가벼운 농담";
		foreach (bro in ::World.getPlayerRoster().getAll())
		{
			if (bro.getSkills().hasSkill("effects.rf_old_swordmaster_scenario_avatar"))
			{
				this.m.Swordmaster = bro;
				break;
			}
		}
	}

	function onClear()
	{
		this.m.Swordmaster = null;
	}
});
