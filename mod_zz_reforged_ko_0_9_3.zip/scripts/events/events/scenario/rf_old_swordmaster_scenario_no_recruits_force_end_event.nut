// All event text written by ThePlahunter
this.rf_old_swordmaster_scenario_no_recruits_force_end_event <- ::inherit("scripts/events/event", {
	m = {
		Swordmaster = null
	},
	function create()
	{
		this.m.ID = "event.rf_old_swordmaster_scenario_no_recruits_force_end";
		this.m.IsSpecial = true;
		this.m.Screens.push({
			ID = "A",
			Text = "[img]gfx/ui/events/event_17.png[/img]나이는 끊임없는 유령처럼 당신을 따라다니며 모든 발걸음을 지켜보고 기다리는 것 같습니다. 당신은 이 여행을 떠났습니다. %OOC%왜냐하면%OOC_OFF% 당신의 강사가 당신에게 전수한 지식을 낭비하고 싶지 않습니다. 하지만 밤에는 미래의 전사로 성장할 수 있는 초보자가 하나도 없다는 사실을 알게 되었습니다. 새로운 '학교'의 자손들이 계속해서 뛰어난 검술로 명성을 얻으세요. 남을 가르치기 위한 것이 아니라면 이 모든 것이 무엇을 위한 것인가..?\n\n자신의 실패를 깨달은 당신은 다시 한 번 칼날을 한쪽으로 치워두고 돌아서서 당신의 빈약한 땅으로 돌아갑니다. 아마도 이것은 모두 시간 낭비이자 외로움과 무모한 방랑벽에 대한 교훈이었을 것입니다. 지도하고 유산을 이어갈 학생이 몇 명 있었다면… 아쉽게도 그것은 이제 지나가 버렸습니다. 당신은 약한 노인으로 죽을 것이며 당신의 지식을 무덤까지 가져갈 것입니다.",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "내가 왜 시작했을까... (캠페인 종료)",
					function getResult( _event )
					{
						this.World.State.getMenuStack().pop(true);
						this.World.State.showGameFinishScreen(true);
						return 0;
					}

				}
			],
			function start( _event )
			{
				this.World.Combat.abortAll();
				this.Characters.push(_event.m.Swordmaster.getImagePath());
				this.List = [
					{
						id = 16,
						icon = "ui/backgrounds/rf_old_swordmaster_background.png",
						text = _event.m.Swordmaster.getName() + " 자신의 지식을 전수하려는 꿈을 포기하다"
					}
				];
			}
		});
	}

	function onPrepare()
	{
		this.m.Title = "실패";
		foreach (bro in this.World.getPlayerRoster().getAll())
		{
			if (bro.getSkills().hasSkill("effects.rf_old_swordmaster_scenario_avatar"))
			{
				this.m.Swordmaster = bro;
				break;
			}
		}
	}

	function onClear()
	{
		this.m.Swordmaster = null;
	}
});
