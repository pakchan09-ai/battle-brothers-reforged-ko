this.rf_brigandine_armor <- ::inherit("scripts/items/armor/armor", {
	m = {},
	function create()
	{
		this.armor.create();
		this.m.ID = "armor.body.rf_brigandine_armor";
		this.m.Name = "브리건딘 갑옷";
		this.m.Description = "긴 메일 셔츠 위에 입는 판이 박혀 있고 리벳이 박혀 있으며 겹쳐진 천 셔츠입니다. 적당한 이동성 손실만으로 뛰어난 보호 기능을 제공합니다.";
		this.m.SlotType = ::Const.ItemSlot.Body;
		this.m.IsDroppedAsLoot = true;
		this.m.ShowOnCharacter = true;
		this.m.Variant = 1;
		this.m.VariantString = "rf_brigandine_armor"
		this.updateVariant();
		this.m.ImpactSound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.InventorySound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.Value = 4600;
		this.m.Condition = 230;
		this.m.ConditionMax = 230;
		this.m.StaminaModifier = -26;
	}
});
