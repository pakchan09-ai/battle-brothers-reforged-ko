this.rf_brigandine_shirt <- ::inherit("scripts/items/armor/armor", {
	m = {},
	function create()
	{
		this.armor.create();
		this.m.ID = "armor.body.rf_brigandine_shirt";
		this.m.Name = "브리건딘 셔츠";
		this.m.Description = "린넨과 아케톤 위에 입혀진 판이 박혀 있고 리벳이 박혀 있고 겹쳐진 천 셔츠입니다. 이동성 손실을 최소화하면서 우수한 보호 기능을 제공합니다.";
		this.m.SlotType = ::Const.ItemSlot.Body;
		this.m.IsDroppedAsLoot = true;
		this.m.ShowOnCharacter = true;
		this.m.Variant = ::Math.rand(1, 5);
		this.m.VariantString = "rf_brigandine_shirt"
		this.updateVariant();
		this.m.ImpactSound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.InventorySound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.Value = 3000;
		this.m.Condition = 190;
		this.m.ConditionMax = 190;
		this.m.StaminaModifier = -21;
	}
});
