this.rf_vampire_lord_armor <- ::inherit("scripts/items/armor/armor", {
	m = {},
	function create()
	{
		this.armor.create();
		this.m.ID = "armor.body.rf_vampire_lord_armor";
		this.m.Name = "강령술사 군주 가슴보호구";
		this.m.Description = "네크로서번트 로드가 착용하는 장식된 가슴보호구입니다. 일부 보호 기능을 제공합니다.";
		this.m.SlotType = ::Const.ItemSlot.Body;
		this.m.ShowOnCharacter = true;
		this.m.VariantString = "rf_vampire_lord_armor";
		this.m.Variant = 1;
		this.updateVariant();
		this.m.ImpactSound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.InventorySound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.Value = 1000;
		this.m.Condition = 70;
		this.m.ConditionMax = 70;
		this.m.StaminaModifier = -5;
	}
});
