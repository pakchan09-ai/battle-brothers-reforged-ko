this.rf_kastenbrust_plate_harness <- ::inherit("scripts/items/armor/armor", {
	m = {},
	function create()
	{
		this.armor.create();
		this.m.ID = "armor.body.rf_kastenbrust_plate_harness";
		this.m.Name = "Kastenbrust 플레이트 하네스";
		this.m.Description = "사슬 갑옷 위에 상자 모양의 흉갑이 달린 판금 갑옷 풀 세트입니다. 가장 비싼 갑옷 왕관 중 일부를 구입할 수 있습니다.";
		this.m.SlotType = ::Const.ItemSlot.Body;
		this.m.IsDroppedAsLoot = true;
		this.m.ShowOnCharacter = true;
		this.m.Variant = 1;
		this.m.VariantString = "rf_kastenbrust_plate_harness"
		this.updateVariant();
		this.m.ImpactSound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.InventorySound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.Value = 10000;
		this.m.Condition = 360;
		this.m.ConditionMax = 360;
		this.m.StaminaModifier = -50;
	}
});
