this.rf_draugr_runic_metal_armor <- ::inherit("scripts/items/armor/armor", {
	m = {},
	function create()
	{
		this.armor.create();
		this.m.ID = "armor.body.rf_draugr_runic_metal_armor";
		this.m.Name = "배로우킨 룬문자 금속 갑옷";
		this.m.Description = "두껍고 투박하며 룬 문자가 새겨진 겹쳐진 금속판은 이 가죽 하네스에 합리적이면서도 무게 있는 보호 기능을 추가합니다.";
		this.m.SlotType = ::Const.ItemSlot.Body;
		this.m.IsDroppedAsLoot = false;
		this.m.ShowOnCharacter = true;
		this.m.Variant = 1;
		this.m.VariantString = "rf_draugr_armor_12";
		this.updateVariant();
		this.m.ImpactSound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.InventorySound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.Value = 550;
		this.m.Condition = 105;
		this.m.ConditionMax = 105;
		this.m.StaminaModifier = -12;
	}
});
