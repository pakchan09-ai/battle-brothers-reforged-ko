this.rf_heavy_plate_harness <- ::inherit("scripts/items/armor/armor", {
	m = {},
	function create()
	{
		this.armor.create();
		this.m.ID = "armor.body.rf_heavy_plate_harness";
		this.m.Name = "헤비 플레이트 하네스";
		this.m.Description = "이 무거운 플레이트 하네스는 약간의 이동성 손실과 함께 거의 탁월한 보호 기능을 제공합니다. 가장 비싼 갑옷 왕관 중 일부를 구입할 수 있습니다.";
		this.m.SlotType = ::Const.ItemSlot.Body;
		this.m.IsDroppedAsLoot = true;
		this.m.ShowOnCharacter = true;
		this.m.Variant = 1;
		this.m.VariantString = "rf_heavy_plate_harness"
		this.updateVariant();
		this.m.ImpactSound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.InventorySound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.Value = 15000;
		this.m.Condition = 380;
		this.m.ConditionMax = 380;
		this.m.StaminaModifier = -50;
	}
});
