this.rf_foreign_plate_harness <- ::inherit("scripts/items/armor/armor", {
	m = {},
	function create()
	{
		this.armor.create();
		this.m.ID = "armor.body.rf_foreign_plate_harness";
		this.m.Name = "외국 플레이트 하네스";
		this.m.Description = "국내 디자인보다 더 나은 이동성을 제공하는 외국 땅의 뛰어난 플레이트 하네스입니다. 가장 비싼 갑옷 왕관 중 일부를 구입할 수 있습니다.";
		this.m.SlotType = ::Const.ItemSlot.Body;
		this.m.IsDroppedAsLoot = true;
		this.m.ShowOnCharacter = true;
		this.m.Variant = 1;
		this.m.VariantString = "rf_foreign_plate_harness"
		this.updateVariant();
		this.m.ImpactSound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.InventorySound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.Value = 12000;
		this.m.Condition = 360;
		this.m.ConditionMax = 360;
		this.m.StaminaModifier = -46;
	}
});
