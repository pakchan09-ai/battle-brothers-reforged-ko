this.rf_warmth_potion_item <- ::inherit("scripts/items/item", {
	m = {},
	function create()
	{
		this.item.create();
		this.m.ID = "accessory.rf_warmth_potion";
		this.m.Name = "불피 강장제";
		this.m.Description = "삼키면 목을 문지르지만 지금까지 먹어본 어떤 것과도 비교할 수 없는 활력을 주는 불 같은 혼합물입니다. 다음 전투까지 지속됩니다.";
		this.m.SlotType = ::Const.ItemSlot.None;
		this.m.ItemType = ::Const.Items.ItemType.Usable;
		this.m.IsDroppedAsLoot = true;
		this.m.IsAllowedInBag = false;
		this.m.IsUsable = true;
		this.m.IconLarge = "";
		this.m.Icon = "consumables/rf_warmth_potion_item.png";
		this.m.Value = 550;
	}

	function getTooltip()
	{
		local ret = this.item.getTooltip();

		local effect = ::new("scripts/skills/effects/rf_warmth_potion_effect");
		ret.extend(effect.getTooltip().slice(2)) // slice 2 to remove name and description

		ret.push({
			id = 65,
			type = "text",
			text = "마시려면 현재 선택한 캐릭터를 마우스 오른쪽 버튼으로 클릭하거나 드래그하세요. 이 아이템은 이 과정에서 소모됩니다."
		});
		ret.push({
			id = 65,
			type = "hint",
			icon = "ui/tooltips/warning.png",
			text = "지나친 방종은 질병을 유발할 수 있다"
		});
		return ret;
	}

	function playInventorySound( _eventType )
	{
		::Sound.play("sounds/bottle_01.wav", ::Const.Sound.Volume.Inventory);
	}

	function onUse( _actor, _item = null )
	{
		::Sound.play("sounds/combat/drink_0" + ::Math.rand(1, 3) + ".wav", ::Const.Sound.Volume.Inventory);
		_actor.getSkills().add(::new("scripts/skills/effects/rf_warmth_potion_effect"));
		::Const.Tactical.Common.checkDrugEffect(_actor);
		return true;
	}
});
