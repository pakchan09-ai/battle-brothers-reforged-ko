this.rf_banshee_potion_item <- ::inherit("scripts/items/misc/anatomist/rf_anatomist_potion_item", {
	m = {},
	function create()
	{
		this.rf_anatomist_potion_item.create();
		this.m.ID = "misc.rf_banshee_potion";
		this.m.Name = "평온의 물약";
		local entityName = ::Const.Strings.EntityName[::Const.EntityType.RF_Banshee];
		entityName = ::Const.Strings.getArticle(entityName) + entityName;
		// Text generated and edited by LordMidas using Gemini
		this.m.Description = "스펙트럼 잔류물로부터 정제된 묽고 반짝이는 증류액입니다. " + entityName + ". 이 액체는 믿을 수 없을 정도로 가볍고, 손에 쥐었을 때 거의 무게가 느껴지지 않으며, 날카로운 쏘는 듯한 향이 납니다. 임상 시험에 따르면 맥주는 대상의 기분을 안정시켜 그들의 기질을 지속적인 긍정 상태로 조정합니다. 이는 술꾼이 공포나 슬픔에 대해 더 탄력적일 뿐만 아니라 영감받은 자신감의 상태로 올라갈 가능성도 더 높아진다는 것을 보장합니다. 피험자들은 섭취 후 며칠 동안 귀에서 지속적이고 유령 같은 울림이 발생했다고 보고했는데, 이는 시간이 지나면서 가라앉았으나 전혀 사라지지 않았습니다.";
		this.m.Icon = "consumables/rf_banshee_potion_item.png";
	}
});
