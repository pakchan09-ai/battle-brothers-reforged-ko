// Base abstract class for anatomist potion items. Automatically adds tooltip from the relevant
// effect based on Reforged.Items.AnatomistPotions.Infos and adds the effect during onUse.
this.rf_anatomist_potion_item <- ::inherit("scripts/items/misc/anatomist/anatomist_potion_item", {
	m = {},
	function create()
	{
		this.anatomist_potion_item.create();
		this.m.Value = 0;
	}

	function getTooltip()
	{
		local ret = this.anatomist_potion_item.getTooltip();

		local path = ::IO.scriptFilenameByHash(this.ClassNameHash);
		foreach (info in ::Reforged.Items.AnatomistPotions.Infos)
		{
			if (info.ItemScript == path)
			{
				ret.extend(::new(info.EffectScript).getTooltip().slice(2)); // slice 2 to remove name and description
			}
		}

		ret.push({
			id = 65,
			type = "text",
			text = "마시려면 현재 선택한 캐릭터를 마우스 오른쪽 버튼으로 클릭하거나 드래그하세요. 이 아이템은 이 과정에서 소모됩니다."
		});
		ret.push({
			id = 65,
			type = "hint",
			icon = "ui/tooltips/warning.png",
			text = "신체에 돌연변이를 일으켜 질병을 일으킴"
		});
		return ret;
	}

	function onUse( _actor, _item = null )
	{
		local path = ::IO.scriptFilenameByHash(this.ClassNameHash);
		foreach (info in ::Reforged.Items.AnatomistPotions.Infos)
		{
			if (info.ItemScript == path)
			{
				_actor.getSkills().add(::new(info.EffectScript));
			}
		}
		return this.anatomist_potion_item.onUse(_actor, _item);
	}
});

