this.named_rf_battle_axe <- ::inherit("scripts/items/weapons/named/named_weapon", {
	m = {},
	function create()
	{
		this.named_weapon.create();
		this.m.Variant = 1;
		this.updateVariant();
		this.m.ID = "weapon.named_rf_battle_axe";
		this.m.NameList = ::Const.Strings.AxeNames;
		this.m.Description = "숙련된 대장장이는 이 도끼가 휘두를 때 소리를 내도록 하고 그에 걸맞은 깨끗한 마감 처리를 보장했습니다.";
		this.m.Value = 4000
		this.m.BaseItemScript = "scripts/items/weapons/rf_battle_axe";
		this.randomizeValues();
	}

	function updateVariant()
	{
		this.m.IconLarge = "weapons/melee/rf_battle_axe_named_0" + this.m.Variant + ".png";
		this.m.Icon = "weapons/melee/rf_battle_axe_named_0" + this.m.Variant + "_70x70.png";
		this.m.ArmamentIcon = "icon_rf_battle_axe_named_0" + this.m.Variant;
	}

	// No need to define onEquip because skills are copied from base weapon definition due to BaseItemScript
});
