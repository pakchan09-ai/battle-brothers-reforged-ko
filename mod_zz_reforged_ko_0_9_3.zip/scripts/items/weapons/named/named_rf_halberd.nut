this.named_rf_halberd <- ::inherit("scripts/items/weapons/named/named_weapon", {
	m = {},
	function create()
	{
		this.named_weapon.create();
		this.m.Variant = ::Math.rand(1, 3);
		this.updateVariant();
		this.m.ID = "weapon.named_rf_halberd";
		this.m.NameList = ::Const.Strings.AxeNames;
		this.m.Description = "훌륭하게 제작된 이 할버드는 전쟁을 위해 제작된 칼날을 갖추고 있으며, 전투를 빠르게 끝내기 위해 만들어진 무기의 무게로 공격합니다.";
		this.m.Value = 4600;
		this.m.BaseItemScript = "scripts/items/weapons/rf_halberd";
		this.randomizeValues();
	}

	function updateVariant()
	{
		this.m.IconLarge = "weapons/melee/rf_halberd_named_0" + this.m.Variant + ".png";
		this.m.Icon = "weapons/melee/rf_halberd_named_0" + this.m.Variant + "_70x70.png";
		this.m.ArmamentIcon = "icon_rf_halberd_named_0" + this.m.Variant;
	}

	// No need to define onEquip because skills are copied from base weapon definition due to BaseItemScript
});
