this.named_rf_poleaxe <- ::inherit("scripts/items/weapons/named/named_weapon", {
	m = {},
	function create()
	{
		this.named_weapon.create();
		this.m.Variant = 1;
		this.updateVariant();
		this.m.ID = "weapon.named_rf_poleaxe";
		this.m.NameList = ::Const.Strings.SpetumNames;
		this.m.Description = "이 정밀한 극도끼는 우편물을 뚫고 헬멧을 굴려 굴복하기 위해 제작되었습니다. 그것은 전투의 요구를 잘 아는 장인의 작품입니다.";
		this.m.Value = 4200;
		this.m.BaseItemScript = "scripts/items/weapons/rf_poleaxe";
		this.randomizeValues();
	}

	function updateVariant()
	{
		this.m.IconLarge = "weapons/melee/rf_poleaxe_named_0" + this.m.Variant + ".png";
		this.m.Icon = "weapons/melee/rf_poleaxe_named_0" + this.m.Variant + "_70x70.png";
		this.m.ArmamentIcon = "icon_rf_poleaxe_named_0" + this.m.Variant;
	}

	// No need to define onEquip because skills are copied from base weapon definition due to BaseItemScript
});
