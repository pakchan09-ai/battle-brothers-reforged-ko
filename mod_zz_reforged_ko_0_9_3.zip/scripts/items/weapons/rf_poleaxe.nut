this.rf_poleaxe <- ::inherit("scripts/items/weapons/weapon", {
	m = {},
	function create()
	{
		this.weapon.create();
		this.m.ID = "weapon.rf_poleaxe";
		this.m.Name = "폴액스";
		this.m.Description = "긴 자루, 도끼 머리, 창끝을 갖춘 다재다능하고 강력한 무기로 근거리 및 원거리 근접 전투에 이상적인 선택입니다.";
		this.m.Categories = "도끼, 양손무기";
		this.m.IconLarge = "weapons/melee/rf_poleaxe_01.png";
		this.m.Icon = "weapons/melee/rf_poleaxe_01_70x70.png";
		this.m.SlotType = ::Const.ItemSlot.Mainhand;
		this.m.BlockedSlotType = ::Const.ItemSlot.Offhand;
		this.m.ItemType = ::Const.Items.ItemType.Weapon | ::Const.Items.ItemType.MeleeWeapon | ::Const.Items.ItemType.TwoHanded;
		this.m.ArmamentIcon = "icon_rf_poleaxe_01";
		this.m.Value = 2800;
		this.m.ShieldDamage = 0;
		this.m.Condition = 84.0;
		this.m.ConditionMax = 84.0;
		this.m.StaminaModifier = -16;
		this.m.RangeMin = 1;
		this.m.RangeMax = 2;
		this.m.RangeIdeal = 2;
		this.m.RegularDamage = 75;
		this.m.RegularDamageMax = 100;
		this.m.ArmorDamageMult = 1.3;
		this.m.DirectDamageMult = 0.3;
		this.m.ChanceToHitHead = 5;
		this.m.Reach = 6;
	}

	function onEquip()
	{
		this.weapon.onEquip();

		this.addSkill(::Reforged.new("scripts/skills/actives/rf_hew_skill"));

		this.addSkill(::Reforged.new("scripts/skills/actives/strike_skill", function(o) {
			o.setApplyAxeMastery(true);
			o.m.Icon = "skills/rf_poleaxe_strike_skill.png";
			o.m.IconDisabled = "skills/rf_poleaxe_strike_skill_sw.png";
			o.m.Overlay = "rf_poleaxe_strike_skill";
			o.m.IsIgnoredAsAOO = true;
		}));

		this.addSkill(::Reforged.new("scripts/skills/actives/impale", function(o) {
			o.m.Icon = "skills/rf_poleaxe_impale_skill.png";
			o.m.IconDisabled = "skills/rf_poleaxe_impale_skill_sw.png";
			o.m.Overlay = "rf_poleaxe_impale_skill";
			o.m.IsIgnoredAsAOO = true;
		}));
	}
});
