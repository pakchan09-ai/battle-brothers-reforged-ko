this.rf_sallet_helmet_with_bevor <- ::inherit("scripts/items/helmets/helmet", {
	m = {},
	function create()
	{
		this.helmet.create();
		this.m.ID = "armor.head.rf_sallet_helmet_with_bevor";
		this.m.Name = "Bevor가 장착된 샐릿 헬멧";
		this.m.Description = "정교하게 제작된 베버와 짝을 이루는 잘 만들어진 샐릿 헬멧입니다. 뛰어난 보호 기능을 제공하는 값비싼 제품입니다.";
		this.m.ShowOnCharacter = true;
		this.m.IsDroppedAsLoot = true;
		this.m.HideHair = true;
		this.m.HideBeard = true;
		this.m.Variant = 1;
		this.m.VariantString = "rf_sallet_helmet_with_bevor"
		this.updateVariant();
		this.m.ImpactSound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.InventorySound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.Value = 3500;
		this.m.Condition = 275;
		this.m.ConditionMax = 275;
		this.m.StaminaModifier = -17;
		this.m.Vision = -2;
	}
});
