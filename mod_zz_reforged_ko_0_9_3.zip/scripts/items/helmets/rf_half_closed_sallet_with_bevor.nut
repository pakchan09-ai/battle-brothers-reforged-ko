this.rf_half_closed_sallet_with_bevor <- ::inherit("scripts/items/helmets/helmet", {
	m = {},
	function create()
	{
		this.helmet.create();
		this.m.ID = "armor.head.rf_half_closed_sallet_with_bevor";
		this.m.Name = "Bevor가 포함된 반 폐쇄형 샐렛";
		this.m.Description = "정교하게 제작된 반폐쇄 샐릿 헬멧은 똑같이 정교하게 제작된 베버와 짝을 이룹니다. 가장 부유한 사람들에게서만 볼 수 있는 값비싼 작품입니다.";
		this.m.ShowOnCharacter = true;
		this.m.IsDroppedAsLoot = true;
		this.m.HideHair = true;
		this.m.HideBeard = true;
		this.m.Variant = 1;
		this.m.VariantString = "rf_half_closed_sallet_with_bevor"
		this.updateVariant();
		this.m.ImpactSound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.InventorySound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.Value = 5000;
		this.m.Condition = 315;
		this.m.ConditionMax = 315;
		this.m.StaminaModifier = -20;
		this.m.Vision = -3;
	}
});
