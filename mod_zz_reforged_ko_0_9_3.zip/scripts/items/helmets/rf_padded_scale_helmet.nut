this.rf_padded_scale_helmet <- ::inherit("scripts/items/helmets/helmet", {
	m = {},
	function create()
	{
		this.helmet.create();
		this.m.ID = "armor.head.rf_padded_scale_helmet";
		this.m.Name = "패딩 처리된 비늘 헬멧";
		this.m.Description = "아케톤 캡 위에 철 비늘을 겹쳐서 만든 헬멧입니다. 무게에 비해 평범한 수준의 보호 기능을 제공합니다.";
		this.m.ShowOnCharacter = true;
		this.m.IsDroppedAsLoot = true;
		this.m.HideHair = true;
		this.m.HideBeard = false;
		this.m.Variant = 1;
		this.m.VariantString = "rf_padded_scale_helmet"
		this.updateVariant();
		this.m.ImpactSound = ::Const.Sound.ArmorChainmailImpact;
		this.m.InventorySound = ::Const.Sound.ArmorChainmailImpact;
		this.m.Value = 375;
		this.m.Condition = 115;
		this.m.ConditionMax = 115;
		this.m.StaminaModifier = -7;
		this.m.Vision = -1;
	}
});
