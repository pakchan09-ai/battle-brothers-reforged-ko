this.rf_padded_sallet_helmet <- ::inherit("scripts/items/helmets/helmet", {
	m = {},
	function create()
	{
		this.helmet.create();
		this.m.ID = "armor.head.rf_padded_sallet_helmet";
		this.m.Name = "패딩 샐릿 헬멧";
		this.m.Description = "아케톤 패딩 위에 잘 만들어진 샐릿 헬멧입니다. 많은 무게 없이도 뛰어난 보호 기능을 제공합니다.";
		this.m.ShowOnCharacter = true;
		this.m.IsDroppedAsLoot = true;
		this.m.HideHair = true;
		this.m.HideBeard = false;
		this.m.Variant = 1;
		this.m.VariantString = "rf_padded_sallet_helmet"
		this.updateVariant();
		this.m.ImpactSound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.InventorySound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.Value = 2000;
		this.m.Condition = 180;
		this.m.ConditionMax = 180;
		this.m.StaminaModifier = -9;
		this.m.Vision = -1;
	}
});
