this.rf_snubnose_bascinet_with_mail <- ::inherit("scripts/items/helmets/helmet", {
	m = {},
	function create()
	{
		this.helmet.create();
		this.m.ID = "armor.head.rf_snubnose_bascinet_with_mail";
		this.m.Name = "메일이 포함된 Snubnose Bascinet";
		this.m.Description = "스너노즈 바이저가 장착된 이 바시넷은 놀라운 방어력과 커버력을 제공합니다. 최고의 보호 크라운 중 일부를 구입할 수 있습니다.";
		this.m.ShowOnCharacter = true;
		this.m.IsDroppedAsLoot = true;
		this.m.HideHair = true;
		this.m.HideBeard = true;
		this.m.Variant = 1;
		this.m.VariantString = "rf_snubnose_bascinet_with_mail"
		this.updateVariant();
		this.m.ImpactSound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.InventorySound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.Value = 5500;
		this.m.Condition = 330;
		this.m.ConditionMax = 330;
		this.m.StaminaModifier = -21;
		this.m.Vision = -3;
	}
});
