this.rf_draugr_antler_helmet <- ::inherit("scripts/items/helmets/helmet", {
	m = {},
	function create()
	{
		this.helmet.create();
		this.m.ID = "armor.head.rf_draugr_antler_helmet";
		this.m.Name = "무덤야생 뿔 투구";
		this.m.Description = "이 잘 제작된 고대 투구에는 어둡고 폭풍우가 치는 밤에 무서운 모습을 드러낼 수 있는 한 쌍의 커다란 뿔이 달려 있습니다.";
		this.m.ShowOnCharacter = true;
		this.m.IsDroppedAsLoot = false;
		this.m.HideHair = true;
		this.m.HideBeard = false;
		this.m.Variant = ::Math.rand(1, 2);
		this.m.VariantString = "rf_draugr_helmet_01";
		this.updateVariant();
		this.m.ImpactSound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.InventorySound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.Value = 1000;
		this.m.Condition = 180;
		this.m.ConditionMax = 180;
		this.m.StaminaModifier = -16;
		this.m.Vision = -2;
	}
});
