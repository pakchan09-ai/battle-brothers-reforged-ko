this.rf_draugr_skull_headdress <- ::inherit("scripts/items/helmets/helmet", {
	m = {},
	function create()
	{
		this.helmet.create();
		this.m.ID = "armor.head.rf_draugr_skull_headdress";
		this.m.Name = "배로우킨 해골 머리장식";
		this.m.Description = "머리 장식에 숫양의 두개골이 내장되어 있으며, 일부 영적 지도자가 사용했을 가능성이 높습니다.";
		this.m.ShowOnCharacter = true;
		this.m.IsDroppedAsLoot = false;
		this.m.HideHair = true;
		this.m.HideBeard = false;
		this.m.Variant = ::Math.rand(1, 2);
		this.m.VariantString = "rf_draugr_helmet_09";
		this.updateVariant();
		this.m.ImpactSound = ::Const.Sound.ArmorBoneImpact;
		this.m.InventorySound = ::Const.Sound.ClothEquip;
		this.m.Value = 250;
		this.m.Condition = 70;
		this.m.ConditionMax = 70;
		this.m.StaminaModifier = -5;
		this.m.Vision = -1;
	}
});
