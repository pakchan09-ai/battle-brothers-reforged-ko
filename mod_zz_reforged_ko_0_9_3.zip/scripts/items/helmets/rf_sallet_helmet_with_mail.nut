this.rf_sallet_helmet_with_mail <- ::inherit("scripts/items/helmets/helmet", {
	m = {},
	function create()
	{
		this.helmet.create();
		this.m.ID = "armor.head.rf_sallet_helmet_with_mail";
		this.m.Name = "메일이 달린 샐릿 헬멧";
		this.m.Description = "사슬 코이프 위에 잘 만들어진 샐릿 헬멧입니다. 모든 군인에게 전반적으로 뛰어난 보호 기능을 제공합니다.";
		this.m.ShowOnCharacter = true;
		this.m.IsDroppedAsLoot = true;
		this.m.HideHair = true;
		this.m.HideBeard = false;
		this.m.Variant = 1;
		this.m.VariantString = "rf_sallet_helmet_with_mail"
		this.updateVariant();
		this.m.ImpactSound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.InventorySound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.Value = 2500;
		this.m.Condition = 240;
		this.m.ConditionMax = 240;
		this.m.StaminaModifier = -14;
		this.m.Vision = -2;
	}
});
