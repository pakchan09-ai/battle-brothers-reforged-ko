this.rf_padded_conical_billed_helmet <- ::inherit("scripts/items/helmets/helmet", {
	m = {},
	function create()
	{
		this.helmet.create();
		this.m.ID = "armor.head.rf_padded_conical_billed_helmet";
		this.m.Name = "패딩 처리된 원추형 빌 헬멧";
		this.m.Description = "아케톤 패딩 위에 외국 스타일의 헬멧인 빌 바이저는 전체 금속을 덜 사용하여 얼굴을 더 많이 덮습니다.";
		this.m.ShowOnCharacter = true;
		this.m.IsDroppedAsLoot = true;
		this.m.HideHair = true;
		this.m.HideBeard = true;
		this.m.Variant = 1;
		this.m.VariantString = "rf_padded_conical_billed_helmet"
		this.updateVariant();
		this.m.ImpactSound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.InventorySound = ::Const.Sound.ArmorHalfplateImpact;
		this.m.Value = 2900;
		this.m.Condition = 245;
		this.m.ConditionMax = 245;
		this.m.StaminaModifier = -14;
		this.m.Vision = -2;
	}
});
