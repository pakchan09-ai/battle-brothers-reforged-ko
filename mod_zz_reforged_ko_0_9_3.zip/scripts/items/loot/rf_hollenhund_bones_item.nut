this.rf_hollenhund_bones_item <- ::inherit("scripts/items/item", {
	m = {},
	function create()
	{
		this.item.create();
		this.m.ID = "misc.rf_hollenhund_bones";
		this.m.Name = "홀렌훈트 본즈";
		this.m.Description = "당신은 이 뼈들이 어떻게 단단해졌는지를 모릅니다. 왜냐하면 그것들이 나온 생물체는 확실히 단단하지 않았기 때문입니다. 그들은 영의 영역에서 나오는 힘을 어느 정도 담고 있어야 합니다.";
		this.m.Icon = "loot/rf_hollenhund_bones.png";
		this.m.SlotType = ::Const.ItemSlot.None;
		this.m.ItemType = ::Const.Items.ItemType.Misc | ::Const.Items.ItemType.Crafting;
		this.m.IsDroppedAsLoot = true;
		this.m.Value = 1000;
	}

	function playInventorySound( _eventType )
	{
		::Sound.play("sounds/combat/armor_leather_impact_03.wav", ::Const.Sound.Volume.Inventory);
	}

	function getSellPriceMult()
	{
		return ::World.State.getCurrentTown().getBeastPartsPriceMult();
	}

	function getBuyPriceMult()
	{
		return ::World.State.getCurrentTown().getBeastPartsPriceMult();
	}
});
