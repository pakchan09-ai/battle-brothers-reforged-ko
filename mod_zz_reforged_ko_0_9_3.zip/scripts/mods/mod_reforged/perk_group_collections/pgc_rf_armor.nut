this.pgc_rf_armor <- ::inherit(::DynamicPerks.Class.PerkGroupCollection, {
	m = {},
	function create()
	{
		this.m.ID = "pgc.rf_armor";
		this.m.Name = "방어구";
		this.m.OrderOfAssignment = 4;
		this.m.Min = 2;
		this.m.Groups = [
			"pg.rf_light_armor",
			"pg.rf_medium_armor",
			"pg.rf_heavy_armor"
		];
	}
});
