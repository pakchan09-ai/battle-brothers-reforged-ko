this.rf_between_the_eyes_effect <- ::inherit("scripts/skills/skill", {
	m = {
		MeleeSkillToHeadshotChancePct = 0.5,
		HeadshotDamageMult = 1.5
	},
	function create()
	{
		this.m.ID = "effects.rf_between_the_eyes";
		this.m.Name = "미간 조준";
		this.m.Description = "이 캐릭터는 대상의 눈 사이에 다음 공격을 가할 준비가 되어 있습니다.";
		this.m.Icon = "ui/perks//perk_rf_between_the_eyes.png";
		this.m.Overlay = "rf_between_the_eyes_effect";
		this.m.Type = ::Const.SkillType.StatusEffect;
		this.m.IsRemovedAfterBattle = true;
	}

	function getTooltip()
	{
		local ret = this.skill.getTooltip();
		local chanceStr;
		if (::MSU.isEqual(this.getContainer().getActor(), ::MSU.getDummyPlayer()))
		{
			chanceStr = "기회는 다음과 같다 " + ::MSU.Text.colorizePct(this.m.MeleeSkillToHeadshotChancePct) + " 의 [근접 공격|Concept.MeleeSkill]"
		}
		else
		{
			chanceStr = ::MSU.Text.colorizeValue(this.getHeadshotChanceAdd(), {AddSign = true, AddPercent = true}) + " chance"
		}
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/chance_to_hit_head.png",
			text = ::Reforged.Mod.Tooltips.parseString("다음 근접 공격에는 " + chanceStr + " 머리를 치고 거래하다 " + ::MSU.Text.colorizeMultWithText(this.m.HeadshotDamageMult) + " 그러한 타격에 대한 피해")
		});

		ret.push({
			id = 20,
			type = "text",
			icon = "ui/icons/warning.png",
			text = ::Reforged.Mod.Tooltips.parseString("만료일: [대기|Concept.Wait] 또는 당신의 종료 [턴|Concept.Turn]")
		});

		return ret;
	}

	function onAnySkillUsed( _skill, _targetEntity, _properties )
	{
		if (this.isSkillValid(_skill))
		{
			_properties.HitChance[::Const.BodyPart.Head] += this.getHeadshotChanceAdd();
			_properties.DamageAgainstMult[::Const.BodyPart.Head] *= this.getHeadshotDamageMult();
		}
	}

	function onTargetMissed( _skill, _targetEntity )
	{
		this.removeSelf();
	}

	function onTargetHit( _skill, _targetEntity, _bodyPart, _damageInflictedHitpoints, _damageInflictedArmor )
	{
		this.removeSelf();
	}

	function onTurnEnd()
	{
		this.removeSelf();
	}

	function onWaitTurn()
	{
		this.removeSelf();
	}

	function getHeadshotChanceAdd()
	{
		return ::Math.max(0, this.getContainer().getActor().getCurrentProperties().getMeleeSkill() * this.m.MeleeSkillToHeadshotChancePct);
	}

	function getHeadshotDamageMult()
	{
		return this.m.HeadshotDamageMult;
	}

	function isSkillValid( _skill )
	{
		return _skill.isAttack() && !_skill.isRanged();
	}
});
