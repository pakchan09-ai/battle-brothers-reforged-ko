this.rf_dismantled_effect <- ::inherit("scripts/skills/skill", {
	m = {
		DamageIncrease = 20,
		BodyHitCount = 0,
		HeadHitCount = 0
	},
	function create()
	{
		this.m.ID = "effects.rf_dismantled";
		this.m.Name = "해체된 갑옷";
		this.m.Description = "이 캐릭터의 갑옷이 부서져 나머지 전투 동안 갑옷을 통과하는 피해가 증가합니다.";
		this.m.Icon = "skills/rf_dismantled_effect.png";
		this.m.IconMini = "rf_dismantled_effect_mini";
		this.m.Overlay = "rf_dismantled_effect";
		this.m.Type = ::Const.SkillType.StatusEffect;
		this.m.IsRemovedAfterBattle = true;
	}

	function getName()
	{
		if ((this.m.BodyHitCount + this.m.HeadHitCount) <= 1)
		{
			return this.m.Name;
		}
		else
		{
			return this.m.Name + " (x" + (this.m.BodyHitCount + this.m.HeadHitCount) + ")";
		}
	}

	function getTooltip()
	{
		local ret = this.skill.getTooltip();

		if (this.m.HeadHitCount > 0)
		{
			ret.push({
				id = 10,
				type = "text",
				icon = "ui/icons/direct_damage.png",
				text = ::MSU.Text.colorNegative((this.m.HeadHitCount * this.m.DamageIncrease) + "%") + " 머리 방어구를 통해 받는 피해가 더 커졌습니다."
			});
		}

		if (this.m.BodyHitCount > 0)
		{
			ret.push({
				id = 11,
				type = "text",
				icon = "ui/icons/direct_damage.png",
				text = ::MSU.Text.colorNegative((this.m.BodyHitCount * this.m.DamageIncrease) + "%") + " 방탄복을 통해 받는 피해가 더 커졌습니다."
			});
		}

		return ret;
	}

	function onRefresh()
	{
		this.spawnIcon("rf_dismantled_effect", this.getContainer().getActor().getTile());
	}

	function onBeforeDamageReceived( _attacker, _skill, _hitInfo, _properties )
	{
		if (_skill == null || !_skill.isAttack() || _attacker == null || _attacker.getID() == this.getContainer().getActor().getID())
		{
			return;
		}

		local count = _hitInfo.BodyPart == ::Const.BodyPart.Body ? this.m.BodyHitCount : this.m.HeadHitCount;

		_properties.DamageReceivedDirectMult *= 1.0 + (count * this.m.DamageIncrease * 0.01);
	}
});
