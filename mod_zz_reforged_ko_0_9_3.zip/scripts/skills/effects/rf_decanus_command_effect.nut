this.rf_decanus_command_effect <- ::inherit("scripts/skills/skill", {
	m = {},
	function create()
	{
		this.m.ID = "effects.rf_decanus_command";
		this.m.Name = "십인대장의 명령";
		this.m.Description = "이 캐릭터는 데카누스 앞에 있습니다.";
		this.m.Type = ::Const.SkillType.StatusEffect;
		this.m.Icon = "skills/rf_decanus_command_effect.png";
		this.m.IconMini = "rf_decanus_command_effect_mini";
		this.m.IsSerialized = false;
	}

	function getTooltip()
	{
		local ret = this.skill.getTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/action_points.png",
			text = ::Reforged.Mod.Tooltips.parseString("사용할 수 있다 [$ $|Skill+shieldwall] 아니 [행동력|Concept.ActionPoints]")
		});

		return ret;
	}

	function onAfterUpdate( _properties )
	{
		this.m.IsHidden = true;

		local actor = this.getContainer().getActor();
		if (!actor.isPlacedOnMap())
			return;

		local shieldwall = this.getContainer().getSkillByID("actives.shieldwall");
		if (shieldwall == null)
			return;

		local myTile = actor.getTile();
		foreach (ally in ::Tactical.Entities.getAlliedActors(actor.getFaction(), myTile, 4))
		{
			if (ally.getSkills().hasSkill("perk.rf_decanus"))
			{
				this.m.IsHidden = false;
				shieldwall.m.ActionPointCost = 0;
				break;
			}
		}
	}
});
