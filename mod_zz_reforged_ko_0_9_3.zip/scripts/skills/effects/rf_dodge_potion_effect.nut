this.rf_dodge_potion_effect <- this.inherit("scripts/skills/skill", {
	m = {
		MeleeDefenseAdd = 5,
		RangedDefenseAdd = 10
	},
	function create()
	{
		this.m.ID = "effects.rf_dodge_potion";
		this.m.Name = "망령의 물약";
		this.m.Description = "영혼의 정수로 준비된 드래프트 덕분에 이 캐릭터는 다가오는 공격을 더 쉽게 빠르게 피할 수 있습니다."
		this.m.Icon = "skills/rf_dodge_potion_effect.png";
		this.m.IconMini = "rf_dodge_potion_effect_mini";
		this.m.Overlay = "rf_dodge_potion_effect";
		this.m.Type = ::Const.SkillType.StatusEffect | ::Const.SkillType.DrugEffect;
		this.m.Order = ::Const.SkillOrder.Perk;
		this.m.IsActive = false;
		this.m.IsRemovedAfterBattle = true;
		this.m.IsSerialized = true;
	}

	function getTooltip()
	{
		local ret = this.skill.getTooltip();

		if (this.m.MeleeDefenseAdd != 0)
		{
			ret.push({
				id = 11,	type = "text",	icon = "ui/icons/melee_defense.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorizeValue(this.m.MeleeDefenseAdd, {AddSign = true}) + " [근접 방어|Concept.MeleeDefense]")
			});
		}
		if (this.m.MeleeDefenseAdd != 0)
		{
			ret.push({
				id = 12,	type = "text",	icon = "ui/icons/ranged_defense.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorizeValue(this.m.RangedDefenseAdd, {AddSign = true}) + " [원거리 방어|Concept.RangeDefense]")
			});
		}
		ret.push({
			id = 7,	type = "hint",	icon = "ui/icons/action_points.png",
			text = "1번의 전투 후에 사라집니다"
		});

		return ret;
	}

	function onUpdate( _properties )
	{
		_properties.MeleeDefense += this.m.MeleeDefenseAdd;
		_properties.RangedDefense += this.m.RangedDefenseAdd;
	}
});
