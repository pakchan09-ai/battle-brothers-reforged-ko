this.rf_banshee_potion_effect <- ::inherit("scripts/skills/effects/rf_anatomist_potion_effect", {
	m = {
		RerollMoraleChance = 50
	},
	function create()
	{
		this.rf_anatomist_potion_effect.create();
		this.m.ID = "effects.rf_banshee_potion";
		this.m.Name = "평온한 마음";
		// Text generated and edited by LordMidas using Gemini
		this.m.Description = "이 캐릭터의 유머는 매우 안정적이어서 마음이 긍정적인 감정에 고도로 적응하면서 두려움이나 슬픔에 반사적으로 저항할 수 있습니다. 때때로 그들은 두개골에서 희미한 울림에 사로잡혀 멍한 상태로 머리를 기울이는 모습이 관찰됩니다.";
		this.m.Icon = "skills/rf_banshee_potion_effect.png";
		this.m.Overlay = "rf_banshee_potion_effect";
	}

	function getTooltip()
	{
		local ret = this.skill.getTooltip();
		ret.extend([
			{
				id = 10,	type = "text",	icon = "ui/icons/bravery.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorizeValue(this.m.RerollMoraleChance, {AddSign = true, AddPercent = true}) + " 다시 굴릴 기회가 실패했습니다 [사기 판정|Concept.Morale]")
			},
			{
				id = 11,	type = "text",	icon = "ui/icons/bravery.png",
				text = ::Reforged.Mod.Tooltips.parseString("자신감 도달을 방해하는 모든 효과에 대응합니다. [사기|Concept.Morale]")
			},
			{
				id = 12,	type = "text",	icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("제거하다 [$ $|Skill+dastard_trait] 그리고 [$ $|Skill+insecure_trait]")
			}
		]);
		return ret;
	}

	function onAdded()
	{
		this.getContainer().removeByID("trait.dastard");
		this.getContainer().removeByID("trait.insecure");
	}

	function onUpdate( _properties )
	{
		_properties.RerollMoraleChance += 50;
	}

	function onAfterUpdate( _properties )
	{
		for (local i = _properties.MV_ForbiddenMoraleStates.len() - 1; i >= 0; i--)
		{
			if (_properties.MV_ForbiddenMoraleStates[i] == ::Const.MoraleState.Confident)
			{
				_properties.MV_ForbiddenMoraleStates.remove(i);
			}
		}
	}
});
