this.rf_barrow_chant_effect <- ::inherit("scripts/skills/skill", {
	m = {
		RestlessnessChance = 50
	},
	function create()
	{
		this.m.ID = "effects.rf_barrow_chant";
		this.m.Name = "고분의 주문";
		this.m.Description = "죽은 자를 달래지만 산 자의 영혼을 질질 끌며 솟아오르는 자신감을 질식시키는 낮고 무서운 성가입니다.";
		// TODO: Placeholder icons
		this.m.Icon = "ui/perks/perk_32.png";
		// this.m.IconMini = "TODO";
		// this.m.Overlay = "TODO";
		this.m.Type = ::Const.SkillType.StatusEffect;
		this.m.IsRemovedAfterBattle = true;
	}

	function getTooltip()
	{
		local ret = this.skill.getTooltip();

		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("전장의 적들은 [자신만만|Concept.Morale]")
		});

		local debuff = ::new("scripts/skills/effects/rf_barrow_chant_debuff_effect");
		if (debuff.m.DamageMultPerMoraleStateAdd != 0)
		{
			ret.push({
				id = 11,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("영향을 받은 적의 거래 " + ::MSU.Text.colorizeMultWithText(1.0 + debuff.m.DamageMultPerMoraleStateAdd) + " 아래 각 사기 상태에 따른 피해 [자신만만|Concept.Morale]")
			});
		}

		ret.push({
			id = 12,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("당신이 죽으면 각 동맹 Barrowkin은 개인을 갖습니다. " + ::MSU.Text.colorizeValue(this.m.RestlessnessChance, {AddPercent = true}) + " 될 기회 [$ $|Skill+rf_draugr_restless_effect]")
		});

		return ret;
	}

	function onDeath( _fatalityType )
	{
		local actor = this.getContainer().getActor();
		foreach (a in ::Tactical.Entities.getAllInstancesAsArray())
		{
			a.getSkills().removeByID("effects.rf_barrow_chant_debuff");

			if (a.isAlliedWith(actor) && ::MSU.isKindOf(a, "rf_draugr") && ::Math.rand(1, 100) <= this.m.RestlessnessChance)
			{
				a.getSkills().add(::new("scripts/skills/effects/rf_draugr_restless_effect"));
			}
		}
	}

	function onActorSpawned( _actor )
	{
		if (::MSU.isEqual(_actor, this.getContainer().getActor()))
		{
			foreach (a in ::Tactical.Entities.getAllInstancesAsArray())
			{
				a.getSkills().add(::new("scripts/skills/effects/rf_barrow_chant_debuff_effect"));
			}
		}
		else
		{
			_actor.getSkills().add(::new("scripts/skills/effects/rf_barrow_chant_debuff_effect"));
		}
	}
});
