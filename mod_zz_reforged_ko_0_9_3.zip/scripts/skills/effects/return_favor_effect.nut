// No rf_ prefix because this filename and skill ID are used in vanilla code but the effect file doesn't exist in vanilla
this.return_favor_effect <- ::inherit("scripts/skills/skill", {
	m = {
		StunChance = 10,
		DazeChance = 50,
		StaggerChance = 75
	},
	function create()
	{
		// No rf_ prefix because this filename and skill ID are used in vanilla code but the effect file doesn't exist in vanilla
		this.m.ID = "effects.return_favor";
		this.m.Name = "보답";
		this.m.Description = "이 캐릭터는 인접한 공격자의 놓친 근접 공격을 충격적인 강타로 되돌립니다.";
		this.m.Icon = "skills/rf_return_favor_effect.png";
		this.m.IconMini = "rf_return_favor_effect_mini";
		this.m.Overlay = "rf_return_favor_effect";
		this.m.Type = ::Const.SkillType.StatusEffect;
		this.m.IsRemovedAfterBattle = true;
	}

	function getTooltip()
	{
		local ret = this.skill.getTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("이 캐릭터에 대한 근접 공격을 놓친 인접한 공격자는 " + ::MSU.Text.colorPositive(this.m.StunChance + "%") + " 될 기회 [$ $|Skill+stunned_effect], " + ::MSU.Text.colorPositive(this.m.DazeChance + "%") + " 될 기회 [$ $|Skill+dazed_effect] 그리고 " + ::MSU.Text.colorPositive(this.m.StaggerChance + "%") + " 될 기회 [$ $|Skill+staggered_effect]")
		});

		local weapon = this.getContainer().getActor().getMainhandItem();
		if (weapon != null && !weapon.isItemType(::Const.Items.ItemType.MeleeWeapon))
		{
			ret.push({
				id = 20,
				type = "text",
				icon = "ui/icons/warning.png",
				text = ::MSU.Text.colorNegative("비무장이거나 근접 무기로 무장해야 함")
			});
		}

		return ret;
	}

	function onMissed( _attacker, _skill )
	{
		if (!_skill.isRanged())
		{
			local actor = this.getContainer().getActor();
			local weapon = actor.getMainhandItem();
			if (weapon != null && !weapon.isItemType(::Const.Items.ItemType.MeleeWeapon)) return;

			local distance = _attacker.getTile().getDistanceTo(actor.getTile());
			if (distance == 1 || (weapon != null && weapon.getRangeMax() >= distance))
			{
				local r = ::Math.rand(1, 100);

				if (r <= this.m.StunChance && !_attacker.getCurrentProperties().IsImmuneToStun)
				{
					local effect = ::new("scripts/skills/effects/stunned_effect");
					effect.addTurns(1);
					_attacker.getSkills().add(effect);
					if (!actor.isHiddenToPlayer() && _attacker.getTile().IsVisibleForPlayer)
					{
						::Tactical.EventLog.log(::Const.UI.getColorizedEntityName(actor) + " 기절시켰다 " + ::Const.UI.getColorizedEntityName(_attacker) + " 한 턴 동안");
					}
				}
				else if (r <= this.m.DazeChance && !_attacker.getCurrentProperties().IsImmuneToDaze)
				{
					_attacker.getSkills().add(::new("scripts/skills/effects/dazed_effect"));
					if (!actor.isHiddenToPlayer() && _attacker.getTile().IsVisibleForPlayer)
					{
						::Tactical.EventLog.log(::Const.UI.getColorizedEntityName(actor) + " 멍해졌어 " + ::Const.UI.getColorizedEntityName(_attacker) + " 한 턴 동안");
					}
				}
				else if (r <= this.m.StaggerChance)
				{
					_attacker.getSkills().add(::new("scripts/skills/effects/staggered_effect"));
					if (!actor.isHiddenToPlayer() && _attacker.getTile().IsVisibleForPlayer)
					{
						::Tactical.EventLog.log(::Const.UI.getColorizedEntityName(actor) + " 비틀거렸다 " + ::Const.UI.getColorizedEntityName(_attacker) + " 한 턴 동안");
					}
				}
			}
		}
	}

	function onTurnStart()
	{
		this.removeSelf();
	}
});
