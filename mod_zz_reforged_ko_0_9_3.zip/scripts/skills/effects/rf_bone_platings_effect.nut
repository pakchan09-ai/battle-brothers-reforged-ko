this.rf_bone_platings_effect <- ::inherit("scripts/skills/skill", {
	m = {},
	function create()
	{
		this.m.ID = "effects.rf_bone_platings";
		this.m.Name = "뼈 장갑";
		this.m.Description = "방어구를 무시하지 않고 신체에 대한 다음 타격을 완전히 흡수합니다.";
		this.m.Icon = "skills/rf_bone_platings_effect.png";
		this.m.IconMini = "rf_bone_platings_effect_mini";
		this.m.Type = ::Const.SkillType.StatusEffect;
		this.m.IsRemovedAfterBattle = true;
	}

	function onBeforeDamageReceived( _attacker, _skill, _hitInfo, _properties )
	{
		if (_hitInfo.BodyPart == ::Const.BodyPart.Body && _hitInfo.DamageDirect < 1.0)
		{
			_properties.DamageReceivedTotalMult = 0.0;
			::Tactical.EventLog.logEx("모든 피해가 흡수되었습니다 (" + this.getName() + ")");
			::Sound.play(::MSU.Array.rand(::Const.Sound.ArmorBoneImpact), ::Const.Sound.Volume.Skill, this.getContainer().getActor().getPos());
			this.removeSelf();
		}
	}
});
