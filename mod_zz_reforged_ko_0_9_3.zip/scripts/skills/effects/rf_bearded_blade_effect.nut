this.rf_bearded_blade_effect <- ::inherit("scripts/skills/skill", {
	m = {},
	function create()
	{
		this.m.ID = "effects.rf_bearded_blade";
		this.m.Name = "수염난 칼날";
		this.m.Description = "이 캐릭터는 도끼의 수염날을 사용하여 상대를 무장 해제할 준비가 되어 있습니다.";
		this.m.Icon = "skills/rf_bearded_blade_effect.png";
		this.m.IconMini = "rf_bearded_blade_effect_mini";
		this.m.Overlay = "rf_bearded_blade_effect";
		this.m.Type = ::Const.SkillType.StatusEffect;
		this.m.IsRemovedAfterBattle = true;
	}

	function getTooltip()
	{
		local ret = this.skill.getTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("다음 공격의 확률은 적중 확률과 동일합니다. [무장해제|Skill+disarmed_effect] 상대방")
		});
		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("다음까지 [턴|Concept.Turn], 당신에 대한 모든 공격이 실패할 확률이 있습니다. [무장해제|Skill+disarmed_effect] 공격자는 실패 확률과 동일")
		});
		ret.push({
			id = 20,
			type = "text",
			icon = "ui/icons/warning.png",
			text = ::Reforged.Mod.Tooltips.parseString("공격하거나 성공하면 만료됩니다. [무장 해제|Skill+disarmed_effect] 상대 또는 무기 교체")
		});

		return ret;
	}

	function onUpdate( _properties )
	{
		if (_properties.IsStunned || this.getContainer().getActor().getMoraleState() == ::Const.MoraleState.Fleeing)
			this.removeSelf();
	}

	function onTurnStart()
	{
		this.removeSelf();
	}

	function onTargetMissed( _skill, _targetEntity )
	{
		this.__onTargetAttacked(_targetEntity);
	}

	function onTargetHit( _skill, _targetEntity, _bodyPart, _damageInflictedHitpoints, _damageInflictedArmor )
	{
		this.__onTargetAttacked(_targetEntity);
	}

	function onMissed( _attacker, _skill )
	{
		if (_skill.isRanged() || !_attacker.isAlive() || _attacker.isAlliedWith(this.getContainer().getActor()) || ::MSU.isNull(::Tactical.State.MV_getCurrentAttackInfo()) || ::Math.rand(1, 100) <= ::Tactical.State.MV_getCurrentAttackInfo().ChanceToHit)
			return;

		local weapon = _attacker.getMainhandItem();
		if (weapon == null)
			return;

		this.removeSelf();
		this.__disarmEntity(_attacker);
	}

	function __onTargetAttacked( _targetEntity )
	{
		this.removeSelf();

		if (!_targetEntity.isAlive() || ::MSU.isNull(::Tactical.State.MV_getCurrentAttackInfo()) || ::Math.rand(1, 100) > ::Tactical.State.MV_getCurrentAttackInfo().ChanceToHit || _targetEntity.getMainhandItem() == null)
			return;

		this.__disarmEntity(_targetEntity);
	}

	function __disarmEntity( _entity )
	{
		local effect = ::new("scripts/skills/effects/disarmed_effect");
		_entity.getSkills().add(effect);
		if (!effect.isGarbage() && ::Tactical.TurnSequenceBar.isActiveEntity(_entity))
		{
			// When disarming an attacker on their turn, we need to disarm for 2 turns so that the disarm
			// doesn't immediately end when the attacker ends their turn.
			// We need to call addTurns instead of setTurns because setTurns is affected by Resilient perk.
			effect.addTurns(1);
		}

		if (!this.getContainer().getActor().isHiddenToPlayer() && _entity.getTile().IsVisibleForPlayer)
		{
			::Tactical.EventLog.log(::Const.UI.getColorizedEntityName(this.getContainer().getActor()) + " 무장해제했다 " + ::Const.UI.getColorizedEntityName(_entity) + " for " + effect.m.TurnsLeft + " 턴");
		}
	}
});
