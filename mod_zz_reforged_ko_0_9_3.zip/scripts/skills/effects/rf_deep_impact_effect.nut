this.rf_deep_impact_effect <- ::inherit("scripts/skills/skill", {
	m = {
		// Both of these need to be set externally when the effect is added
		SkillMult = 1.0
		DamageTotalMult = 1.0,

		MultMin = 0.5
	},
	function create()
	{
		this.m.ID = "effects.rf_deep_impact";
		this.m.Name = "강력한 충격";
		this.m.Description = "이 캐릭터는 매우 큰 타격을 받아 전투 효율성이 크게 저하되었습니다.";
		this.m.Icon = "ui/perks/perk_rf_deep_impact.png";
		this.m.Overlay = "rf_deep_impact_effect";
		this.m.IconMini = "rf_deep_impact_effect_mini";
		this.m.Type = ::Const.SkillType.StatusEffect;
		this.m.IsRemovedAfterBattle = true;
	}

	function setDamageTotalMult( _d )
	{
		this.m.DamageTotalMult = ::Math.minf(this.m.DamageTotalMult, ::Math.maxf(this.m.MultMin, _d));
	}

	function setSkillMult( _m )
	{
		this.m.SkillMult = ::Math.minf(this.m.SkillMult, ::Math.maxf(this.m.MultMin, _m));
	}

	function getTooltip()
	{
		local ret = this.skill.getTooltip();

		if (this.getContainer().getActor().getID() == ::MSU.getDummyPlayer().getID())
		{
			ret.push({
				id = 10,
				type = "text",
				icon = "ui/icons/regular_damage.png",
				text = ::Reforged.Mod.Tooltips.parseString("피해를 입혔습니다. [근접 공격|Concept.MeleeSkill], [근접 방어|Concept.MeleeDefense], [원거리 공격|Concept.RangeSkill] 그리고 [원거리 방어|Concept.RangeDefense] 비율과 동일한 비율로 감소됩니다. [체력|Concept.Hitpoints] 현재까지 받은 피해 [체력,|Concept.Hitpoints] 최대 " + ::MSU.Text.colorizeMult(this.m.MultMin))
			});
		}
		else
		{
			if (this.m.DamageTotalMult != 1.0)
			{
				ret.push({
					id = 10,
					type = "text",
					icon = "ui/icons/regular_damage.png",
					text = ::MSU.Text.colorizeMultWithText(this.m.DamageTotalMult) + " 피해를 입혔다"
				});
			}

			if (this.m.SkillMult != 1.0)
			{
				ret.push({
					id = 11,
					type = "text",
					icon = "ui/icons/melee_skill.png",
					text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorizeMultWithText(this.m.SkillMult) + " [근접 공격|Concept.MeleeSkill]")
				});
				ret.push({
					id = 12,
					type = "text",
					icon = "ui/icons/melee_defense.png",
					text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorizeMultWithText(this.m.SkillMult) + " [근접 방어|Concept.MeleeDefense]")
				});
				ret.push({
					id = 13,
					type = "text",
					icon = "ui/icons/ranged_skill.png",
					text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorizeMultWithText(this.m.SkillMult) + " [원거리 공격|Concept.RangeSkill]")
				});
				ret.push({
					id = 14,
					type = "text",
					icon = "ui/icons/ranged_defense.png",
					text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorizeMultWithText(this.m.SkillMult) + " [원거리 방어|Concept.RangeDefense]")
				});
			}
		}

		return ret;
	}

	function onUpdate( _properties )
	{
		_properties.DamageTotalMult *= this.m.DamageTotalMult;
		_properties.MeleeSkillMult *= this.m.SkillMult;
		_properties.MeleeDefenseMult *= this.m.SkillMult;
		_properties.RangedSkillMult *= this.m.SkillMult;
		_properties.RangedDefenseMult *= this.m.SkillMult;
	}

	function onTurnEnd()
	{
		this.removeSelf();
	}
});
