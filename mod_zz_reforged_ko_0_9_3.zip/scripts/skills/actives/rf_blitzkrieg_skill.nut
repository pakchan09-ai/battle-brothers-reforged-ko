this.rf_blitzkrieg_skill <- ::inherit("scripts/skills/skill", {
	m = {
		IsSpent = false
	},
	function create()
	{
		this.m.ID = "actives.rf_blitzkrieg";
		this.m.Name = "전격전";
		this.m.Description = "가능한 한 빨리 공격하도록 부하들에게 명령하십시오!"
		this.m.Icon = "skills/rf_blitzkrieg_skill.png";
		this.m.IconDisabled = "skills/rf_blitzkrieg_skill_sw.png";
		this.m.Overlay = "rf_blitzkrieg_skill";
		this.m.SoundOnUse = [
			"sounds/combat/rf_blitzkrieg_skill_1.wav",
			"sounds/combat/rf_blitzkrieg_skill_2.wav"
			"sounds/combat/rf_blitzkrieg_skill_3.wav"
		];
		this.m.Type = ::Const.SkillType.Active;
		this.m.Order = ::Const.SkillOrder.Any;
		this.m.IsSerialized = false;
		this.m.IsActive = true;
		this.m.IsIgnoredAsAOO = true;
		this.m.ActionPointCost = 7;
		this.m.FatigueCost = 30;
		this.m.AIBehaviorID = ::Const.AI.Behavior.ID.RF_Blitzkrieg;
	}

	function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();

		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("당신과 당신 세력의 동맹국 " + ::MSU.Text.colorPositive("4") + " 최소한의 타일 " + ::MSU.Text.colorNegative("10") + " [피로|Concept.Fatigue] 남은 이득 [$ $|Skill+adrenaline_effect] 효과와 빌드 " + ::MSU.Text.colorNegative("10") + " [피로|Concept.Fatigue]")
		});

		ret.push({
			id = 20,
			type = "text",
			icon = "ui/icons/warning.png",
			text = ::Reforged.Mod.Tooltips.parseString("다음과 같은 동맹국에는 영향을 미치지 않습니다. [도주 중|Concept.Morale], [$ $|Skill+stunned_effect], 또는 [$ $|Skill+sleeping_effect]")
		});

		ret.push({
			id = 21,
			type = "text",
			icon = "ui/icons/warning.png",
			text = "1일 1회 이상 사용 불가(전사)"
		});

		if (this.m.IsSpent)
		{
			ret.push({
				id = 22,
				type = "text",
				icon = "ui/icons/warning.png",
				text = ::MSU.Text.colorNegative("오늘 회사에서 이미 사용했습니다.")
			});
		}

		return ret;
	}

	function isUsable()
	{
		return !this.m.IsSpent && this.skill.isUsable();
	}

	function onUse( _user, _targetTile )
	{
		this.m.IsSpent = true;

		if (_user.isPlayerControlled())
		{
			local rosterBros = ::World.getPlayerRoster().getAll();
			foreach (bro in rosterBros)
			{
				local skill = bro.getSkills().getSkillByID("actives.rf_blitzkrieg");
				if (skill != null) skill.m.IsSpent = true;
			}
		}

		local myTile = _user.getTile();

		foreach (ally in ::Tactical.Entities.getInstancesOfFaction(_user.getFaction()))
		{
			if (ally.getMoraleState() == ::Const.MoraleState.Fleeing || ally.getCurrentProperties().IsStunned || ally.isNonCombatant())
			{
				continue;
			}

			if (ally.getID() == _user.getID())
			{
				this.getContainer().add(::new("scripts/skills/effects/adrenaline_effect"));
			}
			else
			{
				if (ally.getTile().getDistanceTo(myTile) <= 4 && ally.getFatigueMax() - ally.getFatigue() >= 10)
				{
					ally.setFatigue(ally.getFatigue() + 10);
					local effect = ::new("scripts/skills/effects/adrenaline_effect");
					if (!ally.isTurnStarted() && !ally.isTurnDone())
					{
						effect.m.TurnsLeft++;
					}
					ally.getSkills().add(effect);
				}
			}
		}

		return true;
	}

	function onNewMorning()
	{
		this.m.IsSpent = false;
	}
});
