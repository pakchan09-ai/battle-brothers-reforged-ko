this.rf_shield_bash_skill <- ::inherit("scripts/skills/skill", {
	m = {
		MeleeSkillAdd = 25
	},
	function create()
	{
		this.m.ID = "actives.rf_shield_bash";
		this.m.Name = "방패 강타";
		this.m.Description = "방패를 상대에게 강타하여 상대의 균형을 무너뜨리고 방향 감각을 잃게 합니다.";
		this.m.Icon = "skills/rf_shield_bash_skill.png";
		this.m.IconDisabled = "skills/rf_shield_bash_skill_sw.png";
		this.m.Overlay = "rf_shield_bash_skill";
		this.m.SoundOnUse = [
			"sounds/combat/knockback_01.wav",
			"sounds/combat/knockback_02.wav",
			"sounds/combat/knockback_03.wav"
		];
		this.m.SoundOnHit = [
			"sounds/combat/knockback_hit_01.wav",
			"sounds/combat/knockback_hit_02.wav",
			"sounds/combat/knockback_hit_03.wav"
		];
		this.m.Type = ::Const.SkillType.Active;
		this.m.Order = ::Const.SkillOrder.UtilityTargeted;
		this.m.IsSerialized = false;
		this.m.IsActive = true;
		this.m.IsTargeted = true;
		this.m.IsAttack = true;
		// this.m.HitChanceBonus = 25; // set to 0 by Modular Vanilla
		this.m.IsIgnoredAsAOO = true;
		this.m.ActionPointCost = 4;
		this.m.FatigueCost = 15;
		this.m.MinRange = 1;
		this.m.MaxRange = 1;
		this.m.AIBehaviorID = ::Const.AI.Behavior.ID.Distract;
	}

	function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();

		if (this.m.MeleeSkillAdd != 0)
		{
			ret.push({
				id = 10,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("Has " + ::MSU.Text.colorizeValue(this.m.MeleeSkillAdd, {AddSign = true, AddPercent = true}) + " 칠 기회")
			});
		}

		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("윌 [멍해짐|Skill+dazed_effect] 명중한 대상")
		});

		return ret;
	}

	function onVerifyTarget( _originTile, _targetTile )
	{
		return this.skill.onVerifyTarget(_originTile, _targetTile) && !_targetTile.getEntity().getCurrentProperties().IsImmuneToDaze;
	}

	function onUse( _user, _targetTile )
	{
		local targetEntity = _targetTile.getEntity();

		this.spawnAttackEffect(_targetTile, ::Const.Tactical.AttackEffectImpale);
		if (!this.attackEntity(_user, targetEntity))
			return false;

		targetEntity.getSkills().add(::new("scripts/skills/effects/dazed_effect"));

		if (!_user.isHiddenToPlayer() || _targetTile.IsVisibleForPlayer)
		{
			::Tactical.EventLog.log(::Const.UI.getColorizedEntityName(_user) + " 멍해졌어 " + ::Const.UI.getColorizedEntityName(targetEntity));
		}

		::Sound.play(::MSU.Array.rand(this.m.SoundOnHit), ::Const.Sound.Volume.Skill, targetEntity.getPos());

		return true;
	}

	function onAfterUpdate( _properties )
	{
		if (_properties.IsProficientWithShieldSkills)
		{
			this.m.FatigueCostMult *= ::Const.Combat.WeaponSpecFatigueMult;
		}
	}

	function onAnySkillUsed( _skill, _targetEntity, _properties )
	{
		if (_skill == this)
		{
			_properties.DamageTotalMult = 0.0;
			_properties.MeleeSkill += this.m.MeleeSkillAdd;
			// this.m.HitChanceBonus is set by Modular Vanilla based on changes to _properties.MeleeSkill
		}
	}
});

