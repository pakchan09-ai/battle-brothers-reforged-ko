this.rf_swordmaster_stance_half_swording_skill <- ::inherit("scripts/skills/actives/rf_swordmaster_stance_abstract_skill", {
	m = {},
	function create()
	{
		this.rf_swordmaster_stance_abstract_skill.create();
		this.m.ID = "actives.rf_swordmaster_stance_half_swording";
		this.m.Name = "자세 - 하프소딩";
		this.m.Description = "대상의 갑옷을 관통하는 정확한 관통 공격을 허용하려면 반검 그립으로 전환하세요.";
		this.m.Icon = "skills/rf_swordmaster_stance_half_swording_skill.png";
		this.m.IconDisabled = "skills/rf_swordmaster_stance_half_swording_skill_sw.png";
		this.m.Overlay = "rf_swordmaster_stance_half_swording_skill";
		this.m.SoundOnUse = [
			"sounds/combat/riposte_01.wav",
			"sounds/combat/riposte_02.wav",
			"sounds/combat/riposte_03.wav"
		];
	}

	function getTooltip()
	{
		local ret = this.rf_swordmaster_stance_abstract_skill.getTooltip();

		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorNegative("Removes") + " 현재 장착하고 있는 검의 모든 공격 스킬에 [$ $|Skill+stab] 그리고 [$ $|Skill+puncture] 기술. Stab 스킬 거래 " + ::MSU.Text.colorNegative("50%") + " 피해 감소")
		});

		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/rf_reach.png",
			text = ::Reforged.Mod.Tooltips.parseString("Lose " + ::MSU.Text.colorNegative("half") + " 당신의 무기 중 [리치|Concept.Reach]")
		});

		if (!this.getContainer().getActor().isArmedWithTwoHandedWeapon() && !this.getContainer().getActor().getItems().hasEmptySlot(::Const.ItemSlot.Offhand))
		{
			ret.push({
				id = 20,
				type = "text",
				icon = "ui/icons/warning.png",
				text = ::MSU.Text.colorNegative("양손 검 또는 보조 손이 자유로운 한손 검이 필요합니다.")
			});
		}

		this.addEnabledTooltip(ret);

		return ret;
	}

	function onUpdate( _properties )
	{
		if (!this.m.IsOn) return;

		local weapon = this.getContainer().getActor().getMainhandItem();
		if (weapon != null)	_properties.Reach -= ::Math.floor(weapon.getReach() * 0.5);
	}

	function isUsable()
	{
		return this.rf_swordmaster_stance_abstract_skill.isUsable() && (this.getContainer().getActor().isArmedWithTwoHandedWeapon() || this.getContainer().getActor().getItems().hasEmptySlot(::Const.ItemSlot.Offhand));
	}

	function onAnySkillUsed( _skill, _targetEntity, _properties )
	{
		if (this.m.IsOn && _skill.getID() == "actives.stab")
		{
			_properties.DamageTotalMult *= 0.5;
		}
	}

	function onUnequip( _item )
	{
		if (this.m.IsOn && _item.getSlotType() == ::Const.ItemSlot.Mainhand)
			this.toggleOff();
	}

	function toggleOn()
	{
		if (this.m.IsOn)
			return;

		this.rf_swordmaster_stance_abstract_skill.toggleOn();
		local weapon = this.getContainer().getActor().getMainhandItem();

		// Remove all active skills but keep non-attack ones in a local array.
		// Then later add the new attack skills to this array, sort it, and re-add
		// the skills to the weapon. This helps preserve skill order
		// e.g. showing Riposte after attack skills.
		local skills = [];
		foreach (s in weapon.getSkills())
		{
			if (!s.isActive())
				continue;

			if (!s.isAttack())
			{
				skills.push(s);
			}
			weapon.removeSkill(s);
		}

		skills.push(::Reforged.new("scripts/skills/actives/stab", function(o) {
			o.m.DirectDamageMult = weapon.m.DirectDamageMult;
		}));
		skills.push(::Reforged.new("scripts/skills/actives/puncture", function(o) {
			o.m.Order += 1; // So it appears after Stab
		}));

		skills.sort(@(_a, _b) _a.getOrder() <=> _b.getOrder());
		foreach (s in skills)
		{
			weapon.addSkill(s);
		}
	}

	function onCombatFinished()
	{
		this.rf_swordmaster_stance_abstract_skill.onCombatFinished();
		this.toggleOff();
	}
});
