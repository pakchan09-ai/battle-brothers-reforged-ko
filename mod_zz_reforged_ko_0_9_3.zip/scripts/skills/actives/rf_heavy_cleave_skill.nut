this.rf_heavy_cleave_skill <- ::inherit("scripts/skills/actives/cleave", {
	m = {},
	function create()
	{
		this.cleave.create();
		this.m.ID = "actives.rf_heavy_cleave";
		this.m.Name = "묵직한 참격";
		this.m.Description = ::Reforged.Mod.Tooltips.parseString("피해를 입힐 수 있는 대규모 오버헤드 클리빙 공격 [$ $|Skill+bleeding_effect] 타격을 흡수하는 갑옷이 없고 대상이 출혈을 전혀 할 수 없는 경우 상처를 입습니다.");
		this.m.Icon = "skills/active_182.png"; // Taken from vanilla Rusty Warblade Cleave
		this.m.IconDisabled = "skills/active_182_sw.png";
		this.m.Overlay = "active_182";
		this.m.SoundOnUse = [
			"sounds/combat/overhead_strike_01.wav",
			"sounds/combat/overhead_strike_02.wav",
			"sounds/combat/overhead_strike_03.wav"
		];
		this.m.SoundOnHit = [
			"sounds/combat/overhead_strike_hit_01.wav",
			"sounds/combat/overhead_strike_hit_02.wav",
			"sounds/combat/overhead_strike_hit_03.wav"
		];
		this.m.ActionPointCost = 6;
		this.m.FatigueCost = 15;
		this.m.AIBehaviorID = ::Const.AI.Behavior.ID.AttackDefault;
		this.m.ChanceDecapitate = 99;
		this.m.ChanceDisembowel = 66;
	}

	function getTooltip()
	{
		local ret = this.cleave.getTooltip();
		foreach (entry in ret)
		{
			if (entry.id == 8)
			{
				entry.text = ::Reforged.Mod.Tooltips.parseString("2중첩을 입힙니다. [$ $|Skill+bleeding_effect]")
				break;
			}
		}
		return ret;
	}

	function onTargetHit( _skill, _targetEntity, _bodyPart, _damageInflictedHitpoints, _damageInflictedArmor )
	{
		// Apply 1 more stack of bleeding. The first one is applied by vanilla cleave.onUse.
		if (_skill == this && _targetEntity.isAlive() && !_targetEntity.getCurrentProperties().IsImmuneToBleeding && _damageInflictedHitpoints >= ::Const.Combat.MinDamageToApplyBleeding)
		{
			local effect = ::new("scripts/skills/effects/bleeding_effect");
			effect.setDamage(this.getContainer().getActor().getCurrentProperties().IsSpecializedInCleavers ? 10 : 5);
			_targetEntity.getSkills().add(effect);
		}
	}
});
