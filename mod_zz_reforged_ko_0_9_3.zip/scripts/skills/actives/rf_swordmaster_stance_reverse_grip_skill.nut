this.rf_swordmaster_stance_reverse_grip_skill <- ::inherit("scripts/skills/actives/rf_swordmaster_stance_abstract_skill", {
	m = {
		IsMaceWeaponTypeAdded = false
	},
	function create()
	{
		this.rf_swordmaster_stance_abstract_skill.create();
		this.m.ID = "actives.rf_swordmaster_stance_reverse_grip";
		this.m.Name = "자세 - 역수";
		this.m.Description = "검을 반대 방향으로 잡아 메이스처럼 사용하세요.";
		this.m.Icon = "skills/rf_swordmaster_stance_reverse_grip_skill.png";
		this.m.IconDisabled = "skills/rf_swordmaster_stance_reverse_grip_skill_sw.png";
		this.m.Overlay = "rf_swordmaster_stance_reverse_grip_skill";
		this.m.SoundOnUse = [
			"sounds/combat/riposte_01.wav",
			"sounds/combat/riposte_02.wav",
			"sounds/combat/riposte_03.wav"
		];
	}

	function getTooltip()
	{
		local ret = this.rf_swordmaster_stance_abstract_skill.getTooltip();

		if (::MSU.isEqual(this.getContainer().getActor(), ::MSU.getDummyPlayer()))
		{
			ret.push({
				id = 10,
				type = "text",
				icon = "ui/icons/special.png"
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorNegative("Removes") + " 현재 장착하고 있는 검의 모든 스킬과 " + ::MSU.Text.colorPositive("adds") + " 는 [$ $|Skill+bash] 그리고 [$ $|Skill+knock_out] 또는 [$ $|Skill+cudgel_skill] 그리고 [$ $|Skill+strike_down_skill] 한손검과 양손검 각각의 스킬")
			});
		}
		else
		{
			local skillsString = this.getContainer().getActor().getMainhandItem().isItemType(::Const.Items.ItemType.TwoHanded) ? "[$ $|Skill+cudgel_skill] 그리고 [$ $|Skill+strike_down_skill]" : "[$ $|Skill+bash] 그리고 [$ $|Skill+knock_out]";
			ret.push({
				id = 10,
				type = "text",
				icon = "ui/icons/special.png"
				text = ::MSU.Text.colorNegative("Removes") + " 현재 장착하고 있는 검의 모든 스킬에 " + ::Reforged.Mod.Tooltips.parseString(skillsString) + " skills"
			});
		}

		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("이득 [$ $|Perk+perk_rf_concussive_strikes] 특권")
		});

		ret.push({
			id = 12,
			type = "text",
			icon = "ui/icons/rf_reach.png",
			text = ::Reforged.Mod.Tooltips.parseString("Lose " + ::MSU.Text.colorNegative("one-third") + " 당신의 무기 중 [리치|Concept.Reach]")
		});

		if (!this.getContainer().getActor().isArmedWithTwoHandedWeapon() && !this.getContainer().getActor().getItems().hasEmptySlot(::Const.ItemSlot.Offhand))
		{
			ret.push({
				id = 20,
				type = "text",
				icon = "ui/icons/warning.png",
				text = ::MSU.Text.colorNegative("양손 검 또는 보조 손이 자유로운 한손 검이 필요합니다.")
			});
		}

		this.addEnabledTooltip(ret);

		return ret;
	}

	function onUpdate( _properties )
	{
		if (!this.m.IsOn) return;

		local weapon = this.getContainer().getActor().getMainhandItem();
		if (weapon != null) _properties.Reach -= ::Math.floor(weapon.getReach() * 0.3);
	}

	function isUsable()
	{
		return this.rf_swordmaster_stance_abstract_skill.isUsable() && (this.getContainer().getActor().isArmedWithTwoHandedWeapon() || this.getContainer().getActor().getItems().hasEmptySlot(::Const.ItemSlot.Offhand));
	}

	function toggleOn()
	{
		if (this.m.IsOn)
			return;

		this.rf_swordmaster_stance_abstract_skill.toggleOn();
		local weapon = this.getContainer().getActor().getMainhandItem();

		if (!weapon.isWeaponType(::Const.Items.WeaponType.Mace))
		{
			weapon.m.WeaponType = weapon.m.WeaponType | ::Const.Items.WeaponType.Mace;
			this.m.IsMaceWeaponTypeAdded = true;
		}

		this.getContainer().add(::Reforged.new("scripts/skills/perks/perk_rf_concussive_strikes", function(o) {
			o.m.IsRefundable = false;
			o.m.IsSerialized = false;
		}));

		// Remove all active skills but keep non-attack ones in a local array.
		// Then later add the new attack skills to this array, sort it, and re-add
		// the skills to the weapon. This helps preserve skill order
		// e.g. showing Riposte after attack skills.
		local skills = [];
		foreach (s in weapon.getSkills())
		{
			if (!s.isActive())
				continue;

			if (!s.isAttack())
			{
				skills.push(s);
			}
			weapon.removeSkill(s);
		}

		if (weapon.isItemType(::Const.Items.ItemType.TwoHanded))
		{
			skills.push(::Reforged.new("scripts/skills/actives/cudgel_skill", function(o) {
				o.m.DirectDamageMult = weapon.m.DirectDamageMult;
			}));
			skills.push(::Reforged.new("scripts/skills/actives/strike_down_skill", function(o) {
				o.m.DirectDamageMult = weapon.m.DirectDamageMult;
				o.m.Order += 1; // So it appears after Cudgel
			}));
		}
		else
		{
			skills.push(::Reforged.new("scripts/skills/actives/bash", function(o) {
				o.m.DirectDamageMult = weapon.m.DirectDamageMult;
			}));
			skills.push(::Reforged.new("scripts/skills/actives/knock_out", function(o) {
				o.m.DirectDamageMult = weapon.m.DirectDamageMult;
				o.m.Order += 1; // So it appears after Bash
			}));
		}

		skills.sort(@(_a, _b) _a.getOrder() <=> _b.getOrder());
		foreach (s in skills)
		{
			weapon.addSkill(s);
		}
	}

	function onUnequip( _item )
	{
		if (this.m.IsOn && _item.getSlotType() == ::Const.ItemSlot.Mainhand)
			this.toggleOff();
	}

	function toggleOff()
	{
		if (!this.m.IsOn)
			return;

		this.rf_swordmaster_stance_abstract_skill.toggleOff();
		this.getContainer().removeByStackByID("perk.rf_concussive_strikes");
		if (this.m.IsMaceWeaponTypeAdded)
		{
			local weapon = this.getContainer().getActor().getMainhandItem();
			if (weapon != null)
			{
				weapon.m.WeaponType -= ::Const.Items.WeaponType.Mace;
				this.m.IsMaceWeaponTypeAdded = false;
			}
		}
	}

	function onCombatFinished()
	{
		this.rf_swordmaster_stance_abstract_skill.onCombatFinished();
		this.toggleOff();
	}
});
