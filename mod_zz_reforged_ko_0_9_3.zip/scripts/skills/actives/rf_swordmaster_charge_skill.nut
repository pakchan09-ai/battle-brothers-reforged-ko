this.rf_swordmaster_charge_skill <- ::inherit("scripts/skills/actives/rf_swordmaster_active_abstract", {
	m = {
		IsCharging = false,
		DamageMultBonus = 0.5
	},
	function create()
	{
		this.m.ID = "actives.rf_swordmaster_charge";
		this.m.Name = "거인의 돌진";
		this.m.Description = "저거너트를 풀어보세요! 상대를 향해 달려가서 빠르게 격차를 좁히고 파괴적인 공격을 가하세요.";
		this.m.Icon = "skills/rf_swordmaster_charge_skill.png";
		this.m.IconDisabled = "skills/rf_swordmaster_charge_skill_sw.png";
		this.m.Overlay = "rf_swordmaster_charge_skill";
		this.m.SoundOnUse = [
			"sounds/combat/indomitable_01.wav",
			"sounds/combat/indomitable_02.wav"
		];
		this.m.SoundOnHit = [
			"sounds/combat/knockback_hit_01.wav",
			"sounds/combat/knockback_hit_02.wav",
			"sounds/combat/knockback_hit_03.wav"
		];
		this.m.Type = ::Const.SkillType.Active;
		this.m.Order = ::Const.SkillOrder.UtilityTargeted;
		this.m.IsSerialized = false;
		this.m.IsActive = true;
		this.m.IsTargeted = true;
		this.m.IsTargetingActor = false;
		this.m.IsIgnoredAsAOO = true;
		this.m.IsUsingActorPitch = true;
		this.m.ActionPointCost = 5;
		this.m.FatigueCost = 25;
		this.m.MinRange = 1;
		this.m.MaxRange = 2;
		this.m.MaxLevelDifference = 1;
	}

	function getTooltip()
	{
		local ret = this.getDefaultUtilityTooltip();

		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("즉시 획득 [$ $|Skill+indomitable_effect] 효과")
		});

		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/special.png",
			text = "대상 타일로 이동하여 인접한 무작위 적을 공격합니다. " + ::MSU.Text.colorPositive((this.m.DamageMultBonus * 100) + "%") + " 더 많은 피해"
		});

		ret.push({
			id = 12,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("윌 [비틀거리다|Skill+staggered_effect] 대상 타일에 인접한 모든 적")
		});

		ret.push({
			id = 13,
			type = "text",
			icon = "ui/icons/vision.png",
			text = "다양한 범위를 가지고 있습니다 " + ::MSU.Text.colorPositive(this.getMaxRange()) + " tiles"
		});

		if (!this.isEnabled())
		{
			ret.push({
				id = 20,
				type = "text",
				icon = "ui/icons/warning.png",
				text = ::MSU.Text.colorNegative("펜싱이 아닌 양손 검이 필요합니다.")
			});
		}

		this.addEnabledTooltip(ret);

		if (this.getContainer().getActor().isEngagedInMelee() || ::MSU.isEqual(this.getContainer().getActor(), ::MSU.getDummyPlayer()))
		{
			ret.push({
				id = 21,
				type = "text",
				icon = "ui/icons/warning.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorNegative("다음의 경우에는 사용할 수 없습니다. [교전 중|Concept.ZoneOfControl] 근접전에서"))
			});
		}

		if 	(this.getContainer().getActor().getCurrentProperties().IsRooted)
		{
			ret.push({
				id = 22,
				type = "text",
				icon = "ui/icons/warning.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorNegative("루팅시 사용불가"))
			});
		}

		return ret;
	}

	function isEnabled()
	{
		if (!this.rf_swordmaster_active_abstract.isEnabled()) return false;

		local weapon = this.getContainer().getActor().getMainhandItem();
		if (weapon.isWeaponType(::Const.Items.ItemType.RF_Fencing) || !weapon.isItemType(::Const.Items.ItemType.TwoHanded))
		{
			return false;
		}

		return true;
	}

	function isUsable()
	{
		return this.rf_swordmaster_active_abstract.isUsable() && this.isEnabled() && !this.getContainer().getActor().getCurrentProperties().IsRooted && !this.getContainer().getActor().isEngagedInMelee();
	}

	function onVerifyTarget( _originTile, _targetTile )
	{
		if (!_targetTile.IsEmpty)
		{
			return false;
		}

		if (::Math.abs(_targetTile.Level - _originTile.Level) > this.m.MaxLevelDifference)
		{
			return false;
		}

		local myPos = _originTile.Pos;
		local targetPos = _targetTile.Pos;
		local distance = _originTile.getDistanceTo(_targetTile);
		local Dx = (targetPos.X - myPos.X) / distance;
		local Dy = (targetPos.Y - myPos.Y) / distance;

		for( local i = 0; i < distance; i = ++i )
		{
			local x = myPos.X + Dx * i;
			local y = myPos.Y + Dy * i;
			local tileCoords = ::Tactical.worldToTile(this.createVec(x, y));
			local tile = ::Tactical.getTile(tileCoords);

			if (!tile.IsOccupiedByActor && !tile.IsEmpty)
			{
				return false;
			}

			if (tile.hasZoneOfControlOtherThan(this.getContainer().getActor().getAlliedFactions()) || ::Math.abs(tile.Level - _originTile.Level) > 1)
			{
				return false;
			}
		}

		return true;
	}

	function onUse( _user, _targetTile )
	{
		_user.getSkills().add(::new("scripts/skills/effects/indomitable_effect"));

		local tag = {
			Skill = this,
			User = _user,
			OldTile = _user.getTile(),
			TargetTile = _targetTile,
			OnRepelled = this.onRepelled
		};

		if (tag.OldTile.IsVisibleForPlayer || _targetTile.IsVisibleForPlayer)
		{
			local myPos = _user.getPos();
			local targetPos = _targetTile.Pos;
			local distance = tag.OldTile.getDistanceTo(_targetTile);
			local Dx = (targetPos.X - myPos.X) / distance;
			local Dy = (targetPos.Y - myPos.Y) / distance;

			for( local i = 0; i < distance; i = ++i )
			{
				local x = myPos.X + Dx * i;
				local y = myPos.Y + Dy * i;
				local tile = ::Tactical.worldToTile(this.createVec(x, y));

				if (::Tactical.isValidTile(tile.X, tile.Y) && ::Const.Tactical.DustParticles.len() != 0)
				{
					for( local i = 0; i < ::Const.Tactical.DustParticles.len(); i = ++i )
					{
						::Tactical.spawnParticleEffect(false, ::Const.Tactical.DustParticles[i].Brushes, ::Tactical.getTile(tile), ::Const.Tactical.DustParticles[i].Delay, ::Const.Tactical.DustParticles[i].Quantity * 0.5, ::Const.Tactical.DustParticles[i].LifeTimeQuantity * 0.5, ::Const.Tactical.DustParticles[i].SpawnRate, ::Const.Tactical.DustParticles[i].Stages);
					}
				}
			}
		}

		::Tactical.getNavigator().teleport(_user, _targetTile, this.onTeleportDone, tag, false, 2.0);
		return true;
	}

	function onRepelled( _tag )
	{
		::Tactical.getNavigator().teleport(_tag.User, _tag.TargetTile, null, null, false);
	}

	function onTeleportDone( _entity, _tag )
	{
		local attack = _entity.getSkills().getAttackOfOpportunity();
		local myTile = _entity.getTile();
		local ZOC = [];
		local dirToTarget = _tag.OldTile.getDirectionTo(myTile);

		if (attack != null)
		{
			for (local i = 0; i < 6; i = ++i)
			{
				if (myTile.hasNextTile(i))
				{
					local tile = myTile.getNextTile(i);

					if (tile.IsOccupiedByActor && attack.verifyTargetAndRange(tile, myTile))
					{
						local actor = tile.getEntity();

						if (!actor.isAlliedWith(_entity))
						{
							ZOC.push(actor);
						}
					}
				}
			}
		}

		foreach (actor in ZOC)
		{
			if (!actor.onMovementInZoneOfControl(_entity, true))
			{
				continue;
			}

			if (actor.onAttackOfOpportunity(_entity, true))
			{
				if (_tag.OldTile.IsVisibleForPlayer || myTile.IsVisibleForPlayer)
				{
					::Tactical.EventLog.log(::Const.UI.getColorizedEntityName(_entity) + " 혐의를 받고 격퇴된다");
				}

				if (!_entity.isAlive() || _entity.isDying())
				{
					return;
				}

				local dir = myTile.getDirectionTo(_tag.OldTile);

				if (myTile.hasNextTile(dir))
				{
					local tile = myTile.getNextTile(dir);

					if (tile.IsEmpty && ::Math.abs(tile.Level - myTile.Level) <= 1 && tile.getDistanceTo(actor.getTile()) > 1)
					{
						_tag.TargetTile = tile;
						::Time.scheduleEvent(::TimeUnit.Virtual, 50, _tag.OnRepelled, _tag);
						return;
					}
				}

				for( local i = 0; i != 6; i = ++i )
				{
					if (myTile.hasNextTile(i))
					{
						local tile = myTile.getNextTile(i);

						if (tile.IsEmpty && ::Math.abs(tile.Level - myTile.Level) <= 1)
						{
							if (tile.getZoneOfControlCountOtherThan(_entity.getAlliedFactions()) == 0)
							{
								_tag.TargetTile = tile;
								::Time.scheduleEvent(::TimeUnit.Virtual, 50, _tag.OnRepelled, _tag);
								return;
							}
						}
					}
				}

				_tag.TargetTile = _tag.OldTile;
				::Time.scheduleEvent(::TimeUnit.Virtual, 50, _tag.OnRepelled, _tag);
				return;
			}
		}

		if (ZOC.len() != 0)
		{
			local victim = ::MSU.Array.rand(ZOC);

			if (_tag.Skill.m.SoundOnHit.len() != 0)
			{
				::Sound.play(_tag.Skill.m.SoundOnHit[::Math.rand(0, _tag.Skill.m.SoundOnHit.len() - 1)], ::Const.Sound.Volume.Skill, victim.getPos());
			}

			foreach (enemy in ZOC)
			{
				if (!enemy.isHiddenToPlayer())
				{
					local layers = ::Const.ShakeCharacterLayers[::Const.BodyPart.Body];
					::Tactical.getShaker().shake(enemy, myTile, 2);
				}

				enemy.getSkills().add(::new("scripts/skills/effects/staggered_effect"));
			}

			if (_tag.OldTile.IsVisibleForPlayer || myTile.IsVisibleForPlayer)
			{
				::Tactical.EventLog.log(::Const.UI.getColorizedEntityName(_entity) + " 혐의와 공격 " + ::Const.UI.getColorizedEntityName(victim) + " 인접한 대상을 비틀거리게 하면서");
			}

			_tag.Skill.m.IsCharging = true;
			attack.useForFree(victim.getTile());
			_tag.Skill.m.IsCharging = false;

			return;
		}

		if (_tag.OldTile.IsVisibleForPlayer || myTile.IsVisibleForPlayer)
		{
			::Tactical.EventLog.log(::Const.UI.getColorizedEntityName(_entity) + " charges");
		}
	}

	function onAnySkillUsed( _skill, _targetEntity, _properties )
	{
		if (this.m.IsCharging)
		{
			_properties.DamageTotalMult *= 1.0 + this.m.DamageMultBonus;
		}
	}

	function onAnySkillExecuted( _skill, _targetTile, _targetEntity, _forFree )
	{
		if (this.m.IsCharging) this.m.IsCharging = false;
	}
});
