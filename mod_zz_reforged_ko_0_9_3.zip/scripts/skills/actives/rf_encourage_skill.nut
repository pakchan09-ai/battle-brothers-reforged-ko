this.rf_encourage_skill <- ::inherit("scripts/skills/skill", {
	m = {
		// Config
		EncourageBonusFraction = 0.5,		// This percentage of Resolve is added as a bonus for the morale check

		IsSpent = false
	},

	function create()
	{
		this.m.ID = "actives.rf_encourage";
		this.m.Name = "격려";
		this.m.Description = ::Reforged.Mod.Tooltips.parseString("동맹국이 전류를 높이도록 격려하십시오. [사기|Concept.Morale]. 다음에는 사용할 수 없습니다. [도주 중|Concept.Morale] 또는 [$ $|Skill+stunned_effect] 동맹국.");
		this.m.Icon = "ui/perks/perk_28_active.png";	// unused vanilla artwork
		this.m.IconDisabled = "ui/perks/perk_28_active_sw.png";	// unused vanilla artwork
		this.m.Overlay = "perk_28_active";	// unused vanilla artwork
		this.m.SoundOnUse = [
			"sounds/combat/inspire_01.wav",		// unused vanilla sound. It is a bit too long and overblown but will do for now
			"sounds/combat/inspire_02.wav"
		];
		this.m.Type = ::Const.SkillType.Active;
		this.m.Order = ::Const.SkillOrder.UtilityTargeted;
		this.m.IsSerialized = false;
		this.m.IsActive = true;
		this.m.IsTargeted = true;
		this.m.IsIgnoredAsAOO = true;
		this.m.ActionPointCost = 4;
		this.m.FatigueCost = 15;
		this.m.MinRange = 1;
		this.m.MaxRange = 2;
	}

	function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();

		local actualResolveBonus = "";
		if (this.getContainer().getActor().getID() != ::MSU.getDummyPlayer().getID())
		{
			actualResolveBonus = " (" + ::MSU.Text.colorizeValue(this.getEncourageBonus(), {AddSign = true}) + ")";
		}

		ret.extend([
			{
				id = 10,
				type = "text",
				icon = "ui/icons/bravery.png",
				text = ::Reforged.Mod.Tooltips.parseString(format("긍정적인 반응을 불러일으키세요 [사기 판정|Concept.Morale] 보너스를 받은 대상에 대해 %s%당신의 [의지|Concept.Bravery]", ::MSU.Text.colorizePct(this.m.EncourageBonusFraction), actualResolveBonus))
			},
			{
				id = 15,
				type = "text",
				icon = "ui/icons/vision.png",
				text = "다양한 범위를 가지고 있습니다 " + ::MSU.Text.colorPositive(this.getMaxRange()) + " tiles"
			},
			{
				id = 16,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("자신의 진영에 속한 캐릭터에게만 사용할 수 있습니다. [사기|Concept.Morale] 그들이 떨어져 있는 거리의 타일당 당신보다 낮습니다.")
			}
		]);

		if (this.m.IsSpent)
		{
			ret.push({
				id = 20,
				type = "text",
				icon = "ui/icons/warning.png",
				text = ::Reforged.Mod.Tooltips.parseString("당 1회만 사용할 수 있습니다. [턴|Concept.Turn]")
			});
		}

		return ret;
	}

	function onVerifyTarget( _originTile, _targetTile )
	{
		if (!this.skill.onVerifyTarget(_originTile, _targetTile))
			return false;

		local target = _targetTile.getEntity();
		if (target.getCurrentProperties().IsStunned || target.getMoraleState() == ::Const.MoraleState.Fleeing || target.getMoraleState() >= ::Const.MoraleState.Confident || target.getMoraleState() >= target.m.MaxMoraleState)
			return false;

		local actor = this.getContainer().getActor();
		return actor.getFaction() == target.getFaction() && actor.getMoraleState() - target.getMoraleState() >= actor.getTile().getDistanceTo(target.getTile());
	}

	function isUsable()
	{
		return !this.m.IsSpent && this.skill.isUsable();
	}

	function onUse( _user, _targetTile )
	{
		_targetTile.getEntity().checkMorale(1, this.getEncourageBonus(), ::Const.MoraleCheckType.Default);
		this.m.IsSpent = true;
		return true;
	}

	function onTurnStart()
	{
		this.m.IsSpent = false;
	}

	function onCombatFinished()
	{
		this.skill.onCombatFinished();
		this.m.IsSpent = false;
	}

// New Functions
	function getEncourageBonus()
	{
		local encourageBonus = this.getContainer().getActor().getCurrentProperties().getBravery() * this.m.EncourageBonusFraction;
		return ::Math.max(0, encourageBonus);	// The bonus can never be negative
	}
});
