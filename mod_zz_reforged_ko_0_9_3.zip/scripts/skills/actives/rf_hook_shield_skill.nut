this.rf_hook_shield_skill <- ::inherit("scripts/skills/skill", {
	m = {
		ApplyAxeMastery = true,
		LastTargetID = null,
		IsSpent = false
	},
	function isAxeMasteryApplied()
	{
		return this.m.ApplyAxeMastery;
	}

	function setApplyAxeMastery( _f )
	{
		this.m.ApplyAxeMastery = _f;
	}

	function create()
	{
		this.m.ID = "actives.rf_hook_shield";
		this.m.Name = "방패 걸기";
		this.m.Description = "상대의 방패를 걸기 위한 공격입니다. 방패를 들고 있는 대상에게만 사용할 수 있습니다. 성공하면 대상의 보호막 효과가 감소합니다.";
		this.m.Icon = "skills/rf_hook_shield_skill.png";
		this.m.IconDisabled = "skills/rf_hook_shield_skill_sw.png";
		this.m.Overlay = "rf_hook_shield_skill";
		this.m.SoundOnUse = [
			"sounds/combat/hook_01.wav",
			"sounds/combat/hook_02.wav",
			"sounds/combat/hook_03.wav"
		];
		this.m.SoundOnHit = [
			"sounds/combat/shieldwall_01.wav",
			"sounds/combat/shieldwall_02.wav",
			"sounds/combat/shieldwall_03.wav"
		];
		this.m.Type = ::Const.SkillType.Active;
		this.m.Order = ::Const.SkillOrder.UtilityTargeted;
		this.m.IsShieldRelevant = false;
		this.m.IsSerialized = false;
		this.m.IsActive = true;
		this.m.IsTargeted = true;
		this.m.IsIgnoredAsAOO = true;
		this.m.IsTooCloseShown = true;
		this.m.IsWeaponSkill = true;
		this.m.ActionPointCost = 3;
		this.m.FatigueCost = 25;
		this.m.MinRange = 1;
		this.m.MaxRange = 1;
		this.m.AIBehaviorID = ::Const.AI.Behavior.ID.KnockOut;
	}

	function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();

		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("제거하다 [$ $|Skill+shieldwall_effect] 목표에서. 그렇지 않으면 다음을 적용합니다. [$ $|Skill+rf_hooked_shield_effect] 효과")
		});

		ret.push({
			id = 11,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("당 한 번 [턴|Concept.Turn], 동일한 대상에 대해 두 번째로 성공적으로 사용하면 해당 금액이 모두 환불됩니다. [행동력|Concept.ActionPoints] 비용")
		});

		ret.push({
			id = 12,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("보너스를 무시합니다. [근접 방어|Concept.MeleeDefense] 방패와 [$ $|Skill+shieldwall_effect]")
		});

		ret.push({
			id = 13,
			type = "text",
			icon = "ui/icons/warning.png",
			text = ::Reforged.Mod.Tooltips.parseString("다음을 사용하는 대상에 대해 사용할 수 없습니다. [$ $|Skill+shieldwall_effect] 다음을 사용하는 아군과 인접해 있습니다. [$ $|Skill+shieldwall_effect]")
		});

		if (this.getMaxRange() > 1)
		{
			ret.push({
				id = 8,
				type = "text",
				icon = "ui/icons/vision.png",
				text = "다양한 범위를 가지고 있습니다 " + ::MSU.Text.colorPositive(this.m.MaxRange) + " tiles"
			});
		}

		if (this.getMaxRange() > 1 && !this.getContainer().getActor().getCurrentProperties().IsSpecializedInAxes)
		{
			ret.push({
				id = 6,
				type = "text",
				icon = "ui/icons/hitchance.png",
				text = "있다 " + ::MSU.Text.colorNegative("-15%") + " 무기가 너무 다루기 힘들기 때문에 바로 인접한 대상을 타격할 확률이 높습니다."
			});
		}

		return ret;
	}

	function onAfterUpdate( _properties )
	{
		if (this.isAxeMasteryApplied() && _properties.IsSpecializedInAxes)
		{
			this.m.FatigueCostMult *= ::Const.Combat.WeaponSpecFatigueMult;
		}
	}

	function onVerifyTarget( _originTile, _targetTile )
	{
		if (!_targetTile.IsOccupiedByActor)
			return false;

		local targetEntity = _targetTile.getEntity();
		if (targetEntity.isAlliedWith(this.getContainer().getActor()))
			return false;

		if (!targetEntity.isArmedWithShield() || !this.skill.onVerifyTarget(_originTile, _targetTile) || targetEntity.getSkills().hasSkill("effects.rf_hooked_shield"))
			return false;

		if (targetEntity.getSkills().hasSkill("effects.shieldwall"))
		{
			foreach (ally in ::Tactical.Entities.getAlliedActors(targetEntity.getFaction(), _targetTile, 1, true))
			{
				if (ally.getSkills().hasSkill("effects.shieldwall"))
				{
					return false;
				}
			}
		}

		return true;
	}

	function onUse( _user, _targetTile )
	{
		local targetEntity = _targetTile.getEntity();

		local shield = targetEntity.getOffhandItem();
		if (shield == null)
			return false;

		this.spawnAttackEffect(_targetTile, ::Const.Tactical.AttackEffectSplitShield);
		if (!this.attackEntity(_user, targetEntity))
			return false;

		local shieldWall = targetEntity.getSkills().getSkillByID("effects.shieldwall");
		if (shieldWall != null)
		{
			::Tactical.EventLog.log(::Const.UI.getColorizedEntityName(_user) + " hooks " + ::Const.UI.getColorizedEntityName(targetEntity) + "의 방패가 제거됩니다. " + shieldWall.m.Name);
			targetEntity.getSkills().remove(shieldWall);
		}
		else
		{
			::Tactical.EventLog.log(::Const.UI.getColorizedEntityName(_user) + " hooks " + ::Const.UI.getColorizedEntityName(targetEntity) + "의 방패");
			targetEntity.getSkills().add(::new("scripts/skills/effects/rf_hooked_shield_effect"));
		}
		if (!::Tactical.getNavigator().isTravelling(_targetTile.getEntity()))
		{
			::Tactical.getShaker().shake(targetEntity, _user.getTile(), 5, ::Const.Combat.ShakeEffectSplitShieldColor, ::Const.Combat.ShakeEffectSplitShieldHighlight, ::Const.Combat.ShakeEffectSplitShieldFactor, 1.0, [
				"shield_icon"
			], 1.0);
		}
		::Sound.play(this.m.SoundOnHit[::Math.rand(0, this.m.SoundOnHit.len() - 1)], ::Const.Sound.Volume.Skill, targetEntity.getPos());

		if (!this.m.IsSpent && targetEntity.getID() == this.m.LastTargetID)
		{
			_user.setActionPoints(::Math.min(_user.getActionPointsMax(), _user.getActionPoints() + this.getActionPointCost()));
			this.m.IsSpent = true;
		}

		this.m.LastTargetID = targetEntity.getID();

		return true;
	}

	function onAnySkillUsed( _skill, _targetEntity, _properties )
	{
		if (_skill == this)
		{
			_properties.DamageTotalMult = 0.0;
			if (this.getMaxRange() > 1)
			{
				if (_targetEntity != null && !this.getContainer().getActor().getCurrentProperties().IsSpecializedInAxes && this.getContainer().getActor().getTile().getDistanceTo(_targetEntity.getTile()) == 1)
				{
					_properties.MeleeSkill += -15;
				}
				// this.m.HitChanceBonus is set by Modular Vanilla based on changes to _properties.MeleeSkill
			}
		}
	}

	function onTurnStart()
	{
		this.m.IsSpent = false;
	}

	function onGetHitFactors( _skill, _targetTile, _tooltip )
	{
		if (_skill != this || this.m.IsSpent || !_targetTile.IsOccupiedByActor || _targetTile.getEntity().getID() != this.m.LastTargetID)
			return;

		_tooltip.push({
			icon = "ui/icons/action_points.png",
			text = "적중 시 액션 포인트 환불"
		});
	}
});
