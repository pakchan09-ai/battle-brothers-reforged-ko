this.rf_cheap_trick_skill <- ::inherit("scripts/skills/skill", {
	m = {
		// Config
		HitChanceModifier = 25,
		DamageRegularMult = 0.50,

		// Private
		IsSpent = false
	},
	function create()
	{
		this.m.ID = "actives.rf_cheap_trick";
		this.m.Name = "비열한 수";
		this.m.Description = ::Reforged.Mod.Tooltips.parseString("적을 속이고 정밀하게 공격합니다. 다음 공격에서는 정확성을 위해 힘을 희생합니다. [턴|Concept.Turn].");
		this.m.Icon = "skills/rf_cheap_trick_skill.png";
		this.m.IconDisabled = "skills/rf_cheap_trick_skill_sw.png";
		this.m.Overlay = "rf_cheap_trick_skill";
		this.m.Type = ::Const.SkillType.Active;
		this.m.Order = ::Const.SkillOrder.NonTargeted;
		this.m.IsSerialized = false;
		this.m.IsActive = true;
		this.m.ActionPointCost = 0;
		this.m.FatigueCost = 10;
	}

	function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();

		if (this.m.HitChanceModifier != 0)
		{
			ret.push({
				id = 10,
				type = "text",
				icon = "ui/icons/hitchance.png",
				text = "게인 " + ::MSU.Text.colorizeValue(this.m.HitChanceModifier, {AddSign = true, AddPercent = true}) + " 다음 공격으로 적중할 기회"
			});
		}

		if (this.m.DamageRegularMult != 1.0)
		{
			ret.push({
				id = 11,
				type = "text",
				icon = "ui/icons/regular_damage.png",
				text = ::Reforged.Mod.Tooltips.parseString("Deal " + ::MSU.Text.colorizeMult(this.m.DamageRegularMult ) + " 다음 공격의 피해가 감소합니다")
			});
		}

		if (this.m.IsSpent)
		{
			ret.push({
				id = 20,
				type = "text",
				icon = "ui/icons/warning.png",
				text = ::MSU.Text.colorNegative(::Reforged.Mod.Tooltips.parseString("당 1회만 사용할 수 있습니다. [턴|Concept.Turn]"))
			});
		}

		return ret;
	}

	function isUsable()
	{
		return this.skill.isUsable() && !this.m.IsSpent;
	}

	function onUse( _user, _targetTile )
	{
		local self = this;
		this.getContainer().add(::Reforged.new("scripts/skills/effects/rf_cheap_trick_effect", function(o) {
			o.m.HitChanceModifier = self.m.HitChanceModifier;
			o.m.DamageRegularMult = self.m.DamageRegularMult;
		}));
		this.m.IsSpent = true;

		return true;
	}

	function onTurnStart()
	{
		this.m.IsSpent = false;
	}
});
