this.rf_pocket_sand_skill <- ::inherit("scripts/skills/actives/throw_dirt_skill", {
	m = {
		// Private
		RemainingUses = 0
	},
	function create()
	{
		this.throw_dirt_skill.create();

		this.m.ID = "actives.rf_pocket_sand_skill";
		this.m.Name = "모래 뿌리기";
		this.m.AIBehaviorID = ::Const.AI.Behavior.ID.Distract;
	}

	function getTooltip()
	{
		local ret = this.throw_dirt_skill.getTooltip();

		if (this.getContainer().getActor().isPlacedOnMap())
		{
			if (this.getRemainingUses() == 0)
			{
				ret.push({
					id = 20,
					type = "text",
					icon = "ui/tooltips/warning.png",
					text = "남은 용도: " + ::MSU.Text.colorNegative("0")
				});
			}
			else
			{
				ret.push({
					id = 20,
					type = "text",
					icon = "ui/icons/special.png",
					text = "남은 용도: " + ::MSU.Text.colorPositive(this.getRemainingUses())
				});
			}
		}
		else
		{
			ret.push({
				id = 21,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("비어 있는 것마다 한 번만 사용할 수 있습니다. [가방 칸|Concept.BagSlots] 당신이 전투를 시작하는 것")
			});
		}

		return ret;
	}

	function isUsable()
	{
		return this.throw_dirt_skill.isUsable() && this.m.RemainingUses != 0;
	}

	function onCombatStarted()
	{
		this.throw_dirt_skill.onCombatStarted();

		this.m.RemainingUses = this.getMaximumUses();
	}

	function onUse( _user, _targetTile )
	{
		local ret = this.throw_dirt_skill.onUse(_user, _targetTile);

		this.m.RemainingUses = ::Math.max(0, this.m.RemainingUses - 1);

		return ret;
	}

// New Functions
	function getRemainingUses()
	{
		return this.m.RemainingUses;
	}

	function getMaximumUses()
	{
		local itemContainer = this.getContainer().getActor().getItems();
		return itemContainer.getUnlockedBagSlots() - itemContainer.getAllItemsAtSlot(::Const.ItemSlot.Bag).len();
	}
});
