// This skill is never meant to be added directly to a character. Instead you add another skill to the character
// and call this skill's convertToDeepImpactSkill function to convert that skill to a deep impact skill.
// This is because this skill is meant to be a proxy for the AOO of a weapon, but there is no clean way to achieve that.
this.rf_deep_impact_skill <- ::inherit("scripts/skills/skill", {
	m = {
		TwoHandedAPCostAdd = 2
	},
	function create()
	{
		this.m.ID = "actives.rf_deep_impact";
		this.m.Name = "강력한 충격";
		this.m.Description = "가장 아픈 곳을 때리세요.";
		this.m.Icon = "skills/rf_deep_impact_skill.png";
		this.m.IconDisabled = "skills/rf_deep_impact_skill_sw.png";
		this.m.Overlay = "rf_deep_impact_skill";
		this.m.IsIgnoredAsAOO = true;
		this.m.ActionPointCost = 4;
		this.m.FatigueCost = 25;
		this.m.AIBehaviorID = ::Const.AI.Behavior.ID.KnockOut;
	}

	function getTooltip()
	{
		// Show defaultUtilityTooltip when item is null so we don't show 0% armor effectiveness in tooltip
		local ret = ::MSU.isNull(this.getItem()) ? this.skill.getDefaultUtilityTooltip() : this.skill.getDefaultTooltip();
		ret.extend(this.getDeepImpactTooltip());

		if (this.m.TwoHandedAPCostAdd != 0 && ::MSU.isEqual(this.getContainer().getActor(), ::MSU.getDummyPlayer()))
		{
			ret.push({
				id = 20,
				type = "text",
				icon = "ui/icons/action_points.png",
				text = ::Reforged.Mod.Tooltips.parseString("Costs " + ::MSU.Text.colorizeValue(this.m.TwoHandedAPCostAdd, {AddSign = true, InvertColor = true}) + " [행동력|Concept.ActionPoints] 양손 망치로")
			});
		}

		return ret;
	}

	function getDeepImpactTooltip()
	{
		return [{
			id = 11,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("피해를 입혔을 때 [체력|Concept.Hitpoints] 대상에게 피해를 입힙니다. [딥 임팩트|Skill+rf_deep_impact_effect] 효과")
		}];
	}

	function onItemSet()
	{
		if (this.getItem().isItemType(::Const.Items.ItemType.TwoHanded))
		{
			this.m.ActionPointCost += this.m.TwoHandedAPCostAdd;
		}
	}

	function onAfterUpdate( _properties )
	{
		this.m.FatigueCostMult = _properties.IsSpecializedInHammers ? ::Const.Combat.WeaponSpecFatigueMult : 1.0;
	}

	function onTargetHit( _skill, _targetEntity, _bodyPart, _damageInflictedHitpoints, _damageInflictedArmor )
	{
		if (_skill != this || !_targetEntity.isAlive() || _damageInflictedHitpoints == 0)
			return;

		local effect = _targetEntity.getSkills().getSkillByID("effects.rf_deep_impact");
		if (effect == null)
			effect = ::new("scripts/skills/effects/rf_deep_impact_effect");

		local mult = _damageInflictedHitpoints.tofloat() / _targetEntity.getHitpoints();
		effect.setDamageTotalMult(effect.m.DamageTotalMult - mult);
		effect.setSkillMult(effect.m.SkillMult - mult);
		_targetEntity.getSkills().add(effect);
	}

	// Converts the given skill to a "deep impact" version of it by modifying some `m` fields and some functions.
	// Also changes the ID of that skill to deep impact's id.
	function convertSkill( _skill )
	{
		foreach (field in ["ID", "Name", "Description", "Icon", "IconDisabled", "Overlay", "IsIgnoredAsAOO", "FatigueCost", "AIBehaviorID"])
		{
			_skill.m[field] = this.m[field];
		}

		_skill.m.__RF_DeepImpactSkill <- this;

		local getTooltip = _skill.getTooltip;
		_skill.getTooltip = function()
		{
			local ret = getTooltip();
			ret.extend(this.m.__RF_DeepImpactSkill.getDeepImpactTooltip.call(this));
			return ret;
		}

		local onTargetHit = _skill.onTargetHit;
		_skill.onTargetHit = function( _skill, _targetEntity, _bodyPart, _damageInflictedHitpoints, _damageInflictedArmor )
		{
			onTargetHit( _skill, _targetEntity, _bodyPart, _damageInflictedHitpoints, _damageInflictedArmor );
			this.m.__RF_DeepImpactSkill.onTargetHit.call(this, _skill, _targetEntity, _bodyPart, _damageInflictedHitpoints, _damageInflictedArmor);
		}
	}
});
