this.rf_onslaught_skill <- ::inherit("scripts/skills/skill", {
	m = {
		IsSpent = false,
		AllyDistanceMax = 4
	},
	function create()
	{
		this.m.ID = "actives.rf_onslaught";
		this.m.Name = "맹공";
		this.m.Description = "부하들에게 적진을 돌파하라고 명령하세요!"
		this.m.Icon = "skills/rf_onslaught_skill.png";
		this.m.IconDisabled = "skills/rf_onslaught_skill_sw.png";
		this.m.Overlay = "rf_onslaught_skill";
		this.m.SoundOnUse = [];
		this.m.Type = ::Const.SkillType.Active;
		this.m.Order = ::Const.SkillOrder.Any;
		this.m.IsSerialized = false;
		this.m.IsActive = true;
		this.m.IsIgnoredAsAOO = true;
		this.m.ActionPointCost = 7;
		this.m.FatigueCost = 30;
		this.m.AIBehaviorID = ::Const.AI.Behavior.ID.RF_Onslaught;
	}

	function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();

		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("당신과 당신의 동맹국 " + ::MSU.Text.colorPositive(this.m.AllyDistanceMax) + " 타일은 [$ $|Skill+rf_onslaught_effect] 2에 대한 효과 [라운드|Concept.Round]")
		});

		ret.push({
			id = 20,
			type = "text",
			icon = "ui/icons/warning.png",
			text = ::Reforged.Mod.Tooltips.parseString("다음과 같은 동맹국에는 영향을 미치지 않습니다. [도주 중|Concept.Morale], [$ $|Skill+stunned_effect], 또는 [$ $|Skill+sleeping_effect]")
		});

		ret.push({
			id = 21,
			type = "text",
			icon = "ui/icons/warning.png",
			text = "전투 당 1회 이상 사용할 수 없습니다. (회사 전체)"
		});

		if (this.m.IsSpent)
		{
			ret.push({
				id = 22,
				type = "text",
				icon = "ui/icons/warning.png",
				text = ::MSU.Text.colorNegative("이 전투에서 회사는 이미 사용했습니다.")
			});
		}

		return ret;
	}

	function isUsable()
	{
		return !this.m.IsSpent && this.skill.isUsable();
	}

	function onUse( _user, _targetTile )
	{
		this.m.IsSpent = true;

		if (_user.isPlayerControlled())
		{
			local rosterBros = ::World.getPlayerRoster().getAll();
			foreach (bro in rosterBros)
			{
				local skill = bro.getSkills().getSkillByID("actives.rf_onslaught");
				if (skill != null) skill.m.IsSpent = true;
			}
		}

		local myTile = _user.getTile();

		foreach (ally in ::Tactical.Entities.getInstancesOfFaction(_user.getFaction()))
		{
			if (ally.getMoraleState() == ::Const.MoraleState.Fleeing ||	ally.getCurrentProperties().IsStunned || ally.getTile().getDistanceTo(myTile) > this.m.AllyDistanceMax || ally.isNonCombatant())
			{
				continue;
			}

			ally.getSkills().add(::new("scripts/skills/effects/rf_onslaught_effect"));
		}

		return true;
	}

	function onCombatFinished()
	{
		this.skill.onCombatFinished();
		this.m.IsSpent = false;
	}
});
