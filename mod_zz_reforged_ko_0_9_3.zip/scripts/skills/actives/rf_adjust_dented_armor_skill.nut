this.rf_adjust_dented_armor_skill <- ::inherit("scripts/skills/skill", {
	m = {},
	function create()
	{
		this.m.ID = "actives.rf_adjust_dented_armor";
		this.m.Name = "찌그러진 갑옷 수선";
		this.m.Description = "찌그러진 갑옷을 조정하세요. 이것은 힘들고 시간이 많이 걸리는 작업이지만 이동성을 회복하는 것이 가치가 있을 수 있습니다.";
		this.m.Icon = "skills/rf_adjust_dented_armor_skill.png";
		this.m.IconDisabled = "skills/rf_adjust_dented_armor_skill_sw.png";
		this.m.Overlay = "rf_adjust_dented_armor_skill";
		this.m.SoundOnUse = [
			"sounds/ambience/settlement/fortification_armor_weapons_00.wav",
			"sounds/ambience/settlement/fortification_armor_weapons_01.wav",
			"sounds/ambience/settlement/fortification_armor_weapons_02.wav",
			"sounds/ambience/settlement/fortification_armor_weapons_03.wav",
			"sounds/ambience/settlement/fortification_armor_weapons_04.wav",
			"sounds/ambience/settlement/fortification_armor_weapons_05.wav"
		];
		this.m.Type = ::Const.SkillType.Active;
		this.m.Order = ::Const.SkillOrder.Last;
		this.m.IsSerialized = false;
		this.m.IsActive = true;
		this.m.IsIgnoredAsAOO = true;
		this.m.IsVisibleTileNeeded = false;
		this.m.ActionPointCost = 7;
		this.m.FatigueCost = 30;
		this.m.MinRange = 1;
		this.m.MaxRange = 1;
	}

	function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();

		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = ::Reforged.Mod.Tooltips.parseString("제거합니다 [$ $|Skill+rf_dented_armor_effect] 효과")
		});

		if (this.getContainer().getActor().isEngagedInMelee())
		{
			ret.push({
				id = 20,
				type = "text",
				icon = "ui/tooltips/warning.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorNegative("이 캐릭터는 다음과 같으므로 사용할 수 없습니다. [교전 중|Concept.ZoneOfControl] 근접전에서"))
			});
		}

		return ret;
	}

	function isUsable()
	{
		return this.skill.isUsable() && !this.getContainer().getActor().isEngagedInMelee();
	}

	function onUse( _user, _targetTile )
	{
		this.spawnIcon("rf_adjust_dented_armor_ally_skill", _user.getTile());
		this.getContainer().removeByID("effects.rf_dented_armor");
		_user.setDirty(true);
		return true;
	}
});
