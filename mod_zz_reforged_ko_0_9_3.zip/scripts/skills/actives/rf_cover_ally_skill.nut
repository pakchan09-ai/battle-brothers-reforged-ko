this.rf_cover_ally_skill <- ::inherit("scripts/skills/skill", {
	m = {},
	function create()
	{
		this.m.ID = "actives.rf_cover_ally";
		this.m.Name = "아군 엄호";
		this.m.Description = ::Reforged.Mod.Tooltips.parseString("인접한 아군을 덮어 무시하고 타일 하나를 이동할 수 있도록 합니다. [통제 구역|Concept.ZoneOfControl] 차례대로. 엄폐물을 제공하는 동안 근접 스킬, 근접 방어, 원거리 스킬, 원거리 방어가 감소하며, 기절하거나 속박되거나 더 이상 대상과 인접하지 않으면 엄폐물이 사라집니다.");
		this.m.Icon = "skills/rf_cover_ally_skill.png";
		this.m.IconDisabled = "skills/rf_cover_ally_skill_sw.png";
		this.m.Overlay = "rf_cover_ally_skill";
		this.m.SoundOnHit = [
			"sounds/combat/shieldwall_01.wav",
			"sounds/combat/shieldwall_02.wav",
			"sounds/combat/shieldwall_03.wav"
		];
		this.m.Type = ::Const.SkillType.Active;
		this.m.Order = ::Const.SkillOrder.NonTargeted;
		this.m.IsSerialized = false;
		this.m.IsActive = true;
		this.m.IsTargeted = true;
		this.m.IsIgnoredAsAOO = true;
		this.m.IsUsingHitchance = false;
		this.m.ActionPointCost = 4;
		this.m.FatigueCost = 20;
		this.m.MinRange = 1;
		this.m.MaxRange = 1;
		this.m.AIBehaviorID = ::Const.AI.Behavior.ID.RF_CoverAlly;
	}

	function getTooltip()
	{
		local ret = this.skill.getDefaultUtilityTooltip();

		ret.extend([
			{
				id = 10,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("대상은 다음을 얻습니다. [$ $|Skill+rf_move_under_cover_skill] 이동이 가능한 스킬 " + ::MSU.Text.colorPositive(1) + " 타일 무시 [통제 구역|Concept.ZoneOfControl]")
			},
			{
				id = 11,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("다음에는 목표를 먼저 세우겠습니다. [라운드의|Concept.Round] [턴|Concept.Turn] 당신의 덮개 아래 있는 동안")
			}
		]);

		if (this.getContainer().getActor().getCurrentProperties().IsRooted)
		{
			ret.push({
				id = 20,
				type = "text",
				icon = "ui/icons/warning.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorNegative("동안에는 사용할 수 없습니다. [속박|Concept.Rooted]"))
			});
		}

		if (this.getContainer().hasSkill("effects.rf_covering_ally"))
		{
			ret.push({
				id = 21,
				type = "text",
				icon = "ui/tooltips/warning.png",
				text = ::Reforged.Mod.Tooltips.parseString(::MSU.Text.colorNegative("이미 있을 때는 사용할 수 없습니다. [$ $|Skill+rf_covering_ally_effect] 동맹국에게"))
			});
		}

		return ret;
	}

	function isUsable()
	{
		local actor = this.getContainer().getActor();

		return this.skill.isUsable() && actor.isPlacedOnMap() && !actor.getCurrentProperties().IsRooted && !actor.getCurrentProperties().IsStunned && !this.getContainer().hasSkill("effects.rf_covering_ally") && ::Tactical.Entities.getAlliedActors(actor.getFaction(), actor.getTile(), 1, true).len() != 0;
	}

	function onVerifyTarget( _originTile, _targetTile )
	{
		if (!this.skill.onVerifyTarget(_originTile, _targetTile))
		{
			return false;
		}

		local target = _targetTile.getEntity();

		return this.getContainer().getActor().isAlliedWith(target) && !target.getCurrentProperties().IsStunned && !target.getCurrentProperties().IsRooted && !target.getSkills().hasSkill("effects.rf_covered_by_ally") && !target.getSkills().hasSkill("effects.rf_covering_ally");
	}

	function onUse( _user, _targetTile )
	{
		local target = _targetTile.getEntity();

		if (!_user.isHiddenToPlayer() || _targetTile.IsVisibleForPlayer)
		{
			::Tactical.EventLog.log(::Const.UI.getColorizedEntityName(_user) + " 커버를 제공합니다 " + ::Const.UI.getColorizedEntityName(target));

			if (this.m.SoundOnHit.len() != 0)
			{
				::Sound.play(this.m.SoundOnHit[::Math.rand(0, this.m.SoundOnHit.len() - 1)], ::Const.Sound.Volume.Skill * 1.2, _user.getPos());
			}
		}

		local coveredByAllyEffect = ::new("scripts/skills/effects/rf_covered_by_ally_effect");
		coveredByAllyEffect.setCoverProvider(_user);
		target.getSkills().add(coveredByAllyEffect);

		local coveringAllyEffect = ::new("scripts/skills/effects/rf_covering_ally_effect");
		coveringAllyEffect.setAlly(target);
		_user.getSkills().add(coveringAllyEffect);

		return true;
	}
});
