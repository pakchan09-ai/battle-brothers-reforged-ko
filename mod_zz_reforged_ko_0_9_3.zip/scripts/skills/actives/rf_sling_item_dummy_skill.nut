

// The purpose of this skill is to inform the player that a sling can also be used to sling pots from your bag over the battle field
// By giving it a dummy skill that skill will show up in our nested tooltip

this.rf_sling_item_dummy_skill <- ::inherit("scripts/skills/skill", {
	m = {},
	function create()
	{
		this.m.ID = "actives.rf_sling_item_dummy";
		this.m.Name = "물품 던지기";
		this.m.Description = "가방에서 다용도 품목을 꺼내세요. 슬링을 사용하여 폭탄, 냄비, 플라스크."
		this.m.Type = ::Const.SkillType.Active;	// This type is required so that the weapon tooltip displays ap and fatigue costs for this skill
		this.m.Order = ::Const.SkillOrder.UtilityTargeted;
		this.m.IsHidden = false;

		// These values will show up on the nested tooltip. These will stop being correct as soon as we introduce indiviual costs for the different pots
		this.m.ActionPointCost = 5;
		this.m.FatigueCost = 25;
	}

	function getTooltip()
	{
		local ret = this.getDefaultUtilityTooltip();
		ret.push({
			id = 8,
			type = "text",
			icon = "ui/icons/vision.png",
			text = "장착된 슬링의 범위와 동일한 범위를 가집니다."
		});
		return ret;
	}
});
